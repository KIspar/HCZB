/* global ExcelChatImport, XLSX */
"use strict";

const elements = {
  captureBadge: document.querySelector("#captureBadge"),
  channelId: document.querySelector("#channelId"),
  capturedAt: document.querySelector("#capturedAt"),
  pageUrl: document.querySelector("#pageUrl"),
  protectedParams: document.querySelector("#protectedParams"),
  testButton: document.querySelector("#testButton"),
  socketStatus: document.querySelector("#socketStatus"),
  chatPoolSummary: document.querySelector("#chatPoolSummary"),
  testChatButton: document.querySelector("#testChatButton"),
  chatForm: document.querySelector("#chatForm"),
  chatEnabled: document.querySelector("#chatEnabled"),
  nicknameInput: document.querySelector("#nicknameInput"),
  messageInput: document.querySelector("#messageInput"),
  addNicknameButton: document.querySelector("#addNicknameButton"),
  addMessageButton: document.querySelector("#addMessageButton"),
  nicknameList: document.querySelector("#nicknameList"),
  messageList: document.querySelector("#messageList"),
  nicknameCount: document.querySelector("#nicknameCount"),
  messageCount: document.querySelector("#messageCount"),
  nicknameBulk: document.querySelector("#nicknameBulk"),
  messageBulk: document.querySelector("#messageBulk"),
  chatScheduleForm: document.querySelector("#chatScheduleForm"),
  chatScheduleId: document.querySelector("#chatScheduleId"),
  chatScheduleName: document.querySelector("#chatScheduleName"),
  chatStartAt: document.querySelector("#chatStartAt"),
  chatEndAt: document.querySelector("#chatEndAt"),
  chatTotalRequests: document.querySelector("#chatTotalRequests"),
  chatDistributionPreview: document.querySelector("#chatDistributionPreview"),
  chatScheduleList: document.querySelector("#chatScheduleList"),
  chatFormTitle: document.querySelector("#chatFormTitle"),
  cancelChatEditButton: document.querySelector("#cancelChatEditButton"),
  excelFile: document.querySelector("#excelFile"),
  excelImportMode: document.querySelector("#excelImportMode"),
  importExcelButton: document.querySelector("#importExcelButton"),
  excelImportPreview: document.querySelector("#excelImportPreview"),
  excelTotalCount: document.querySelector("#excelTotalCount"),
  excelPendingCount: document.querySelector("#excelPendingCount"),
  excelSentCount: document.querySelector("#excelSentCount"),
  excelProblemCount: document.querySelector("#excelProblemCount"),
  clearExcelTasksButton: document.querySelector("#clearExcelTasksButton"),
  excelTasksBody: document.querySelector("#excelTasksBody"),
  excelPanelSummary: document.querySelector("#excelPanelSummary"),
  form: document.querySelector("#scheduleForm"),
  scheduleId: document.querySelector("#scheduleId"),
  scheduleName: document.querySelector("#scheduleName"),
  startAt: document.querySelector("#startAt"),
  endAt: document.querySelector("#endAt"),
  totalRequests: document.querySelector("#totalRequests"),
  concurrency: document.querySelector("#concurrency"),
  peakEnabled: document.querySelector("#peakEnabled"),
  peakControls: document.querySelector("#peakControls"),
  peakCanvas: document.querySelector("#peakCanvas"),
  peakWidth: document.querySelector("#peakWidth"),
  peakWidthLabel: document.querySelector("#peakWidthLabel"),
  peakCountLabel: document.querySelector("#peakCountLabel"),
  addPeakButton: document.querySelector("#addPeakButton"),
  deletePeakButton: document.querySelector("#deletePeakButton"),
  peakResults: document.querySelector("#peakResults"),
  peakScheduleResult: document.querySelector("#peakScheduleResult"),
  peakSummary: document.querySelector("#peakSummary"),
  peakRangeLabel: document.querySelector("#peakRangeLabel"),
  distributionPreview: document.querySelector("#distributionPreview"),
  scheduleList: document.querySelector("#scheduleList"),
  formTitle: document.querySelector("#formTitle"),
  cancelEditButton: document.querySelector("#cancelEditButton"),
  logsBody: document.querySelector("#logsBody"),
  clearLogsButton: document.querySelector("#clearLogsButton"),
  toast: document.querySelector("#toast")
};

let currentState = null;
let toastTimer = null;
let chatDraft = { nicknames: [], messages: [] };
let chatDraftDirty = false;
let loadedChatSignature = "";
let pendingExcelImport = null;
let peakDragState = null;
let peakDraft = [];
let activePeakId = null;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", "\"": "&quot;"
  })[character]);
}

function formatDate(timestamp) {
  if (!timestamp) return "-";
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false
  }).format(new Date(timestamp));
}

function toLocalInput(timestamp) {
  const date = new Date(timestamp);
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(timestamp - offset).toISOString().slice(0, 16);
}

function formatCompactDate(timestamp) {
  if (!timestamp) return "-";
  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false
  }).format(new Date(timestamp));
}

function createPeak(centerPercent = 50, strength = 6, widthPercent = 12) {
  return { id: crypto.randomUUID(), centerPercent, strength, widthPercent };
}

function activePeak() {
  return peakDraft.find((peak) => peak.id === activePeakId) || peakDraft[0] || null;
}

function peaksFromForm() {
  return elements.peakEnabled.checked
    ? peakDraft.map(({ id, centerPercent, strength, widthPercent }) => ({
      id, centerPercent, strength, widthPercent
    }))
    : [];
}

function normalizePeakConfig(peak) {
  if (!peak) return null;
  if (Number.isFinite(Number(peak.centerPercent))) {
    return {
      id: peak.id || crypto.randomUUID(),
      centerPercent: Number(peak.centerPercent),
      strength: Number(peak.strength || 0),
      widthPercent: Number(peak.widthPercent || 12)
    };
  }
  const start = Number(peak.startPercent ?? 35);
  const end = Number(peak.endPercent ?? 65);
  return {
    id: peak.id || crypto.randomUUID(),
    centerPercent: (start + end) / 2,
    strength: Math.min(20, Math.max(0.5, Number(peak.share || 60) / Math.max(1, end - start))),
    widthPercent: Math.max(3, Math.min(30, (end - start) / 3))
  };
}

function normalizePeaks(segment) {
  if (Array.isArray(segment?.peaks)) return segment.peaks.map(normalizePeakConfig).filter(Boolean).slice(0, 3);
  if (!segment?.peak?.enabled) return [];
  const peak = normalizePeakConfig(segment?.peak);
  return peak ? [peak] : [];
}

function densityAtPosition(position, peaks = peakDraft) {
  return peaks.reduce((sum, peak) => {
    const center = peak.centerPercent / 100;
    const width = peak.widthPercent / 100;
    return sum + peak.strength * Math.exp(-((position - center) ** 2) / (2 * width ** 2));
  }, 0);
}

function peakMetrics(startAt, endAt, peak) {
  const center = peak.centerPercent / 100;
  const width = peak.widthPercent / 100;
  const duration = endAt - startAt;
  const windowStart = Math.max(0, center - 2 * width);
  const windowEnd = Math.min(1, center + 2 * width);
  return {
    centerAt: startAt + duration * center,
    windowStartAt: startAt + duration * windowStart,
    windowEndAt: startAt + duration * windowEnd,
    durationMinutes: (windowEnd - windowStart) * duration / 60000
  };
}

function mergePeakWindows(results) {
  const windows = results.map(({ index, metrics }) => ({
    startAt: metrics.windowStartAt,
    endAt: metrics.windowEndAt,
    peakNumbers: [index + 1]
  })).sort((left, right) => left.startAt - right.startAt);
  return windows.reduce((merged, window) => {
    const previous = merged[merged.length - 1];
    if (previous && window.startAt <= previous.endAt) {
      previous.endAt = Math.max(previous.endAt, window.endAt);
      previous.peakNumbers.push(...window.peakNumbers);
    } else {
      merged.push({ ...window });
    }
    return merged;
  }, []);
}

function concentrationLabel(strength) {
  if (strength < 3) return "平缓";
  if (strength < 7) return "适中";
  if (strength < 12) return "集中";
  return "高度集中";
}

function plannedSchedulePreview(id, startAt, endAt, count, concurrency, peaks, results) {
  const segment = {
    id,
    startAt,
    endAt,
    totalRequests: count,
    concurrency,
    peaks
  };
  const plannedTimes = Array.from({ length: count }, (_item, index) =>
    window.RequestPlanner.plannedTime(segment, index));
  const windows = mergePeakWindows(results);
  const groups = windows.map((window) => {
    const times = plannedTimes.filter((time) => time >= window.startAt && time <= window.endAt);
    const minuteCounts = new Map();
    for (const time of times) {
      const minute = Math.floor(time / 60000);
      minuteCounts.set(minute, (minuteCounts.get(minute) || 0) + 1);
    }
    return {
      ...window,
      count: times.length,
      maxPerMinute: Math.max(0, ...minuteCounts.values())
    };
  });
  const groupedCount = groups.reduce((sum, group) => sum + group.count, 0);
  return { groups, remainingCount: count - groupedCount };
}

function drawPeakCurve(startAt, endAt, count) {
  const canvas = elements.peakCanvas;
  const context = canvas.getContext("2d");
  const width = canvas.clientWidth || 640;
  const height = canvas.clientHeight || 180;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  context.setTransform(dpr, 0, 0, dpr, 0, 0);
  context.clearRect(0, 0, width, height);
  const selectedPeak = activePeak();
  if (selectedPeak) {
    const rangeStart = Math.max(0, selectedPeak.centerPercent / 100 - 2 * selectedPeak.widthPercent / 100);
    const rangeEnd = Math.min(1, selectedPeak.centerPercent / 100 + 2 * selectedPeak.widthPercent / 100);
    context.fillStyle = "rgba(217, 148, 0, 0.1)";
    context.fillRect(10 + rangeStart * (width - 20), 0, (rangeEnd - rangeStart) * (width - 20), height - 22);
  }
  context.strokeStyle = "#d6dce0";
  context.lineWidth = 1;
  context.beginPath();
  context.moveTo(10, height - 22);
  context.lineTo(width - 10, height - 22);
  context.stroke();
  const baseY = height - 23;
  const points = [];
  for (let index = 0; index <= 120; index += 1) {
    const position = index / 120;
    const density = densityAtPosition(position);
    const y = baseY - 18 - Math.min(height - 45, density * 5);
    points.push([10 + position * (width - 20), y]);
  }
  context.strokeStyle = "#117d72";
  context.lineWidth = 3;
  context.beginPath();
  points.forEach(([x, y], index) => index ? context.lineTo(x, y) : context.moveTo(x, y));
  context.stroke();
  const orderedPeaks = [...peakDraft].sort((left, right) => left.centerPercent - right.centerPercent);
  for (const [index, peak] of orderedPeaks.entries()) {
    const center = peak.centerPercent / 100;
    const handleX = 10 + center * (width - 20);
    const handleY = baseY - 18 - Math.min(height - 45, densityAtPosition(center) * 5);
    context.fillStyle = peak.id === activePeakId ? "#d99400" : "#117d72";
    context.beginPath();
    context.arc(handleX, handleY, peak.id === activePeakId ? 10 : 8, 0, Math.PI * 2);
    context.fill();
    context.fillStyle = "#fff";
    context.font = "bold 10px sans-serif";
    context.textAlign = "center";
    context.fillText(String(index + 1), handleX, handleY + 3.5);
    if (Number.isFinite(startAt) && Number.isFinite(endAt) && endAt > startAt) {
      context.fillStyle = "#17212b";
      context.font = "11px sans-serif";
      context.fillText(formatCompactDate(startAt + (endAt - startAt) * center), handleX, Math.max(12, handleY - 12));
    }
  }
  context.fillStyle = "#65727d";
  context.font = "11px sans-serif";
  context.fillText("开始", 10, height - 6);
  context.fillText("结束", width - 32, height - 6);
  context.textAlign = "start";
}

function updatePeakFromPointer(event) {
  const rect = elements.peakCanvas.getBoundingClientRect();
  const center = Math.max(0, Math.min(100, (event.clientX - rect.left) / rect.width * 100));
  const lift = Math.max(0, Math.min(20, (rect.bottom - event.clientY - 25) / 5));
  const peak = activePeak();
  if (!peak) return;
  peak.centerPercent = Math.round(center);
  const otherDensity = densityAtPosition(center / 100, peakDraft.filter((item) => item.id !== peak.id));
  peak.strength = Math.round(Math.max(0, Math.min(20, lift - otherDensity)) * 10) / 10;
  updatePreview(false);
}

function showToast(message, isError = false) {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.className = `toast visible${isError ? " error" : ""}`;
  toastTimer = setTimeout(() => { elements.toast.className = "toast"; }, 3000);
}

async function sendMessage(type, value) {
  const response = await chrome.runtime.sendMessage({ type, value });
  if (!response?.ok) throw new Error(response?.error || "扩展后台没有响应");
  return response.value;
}

function statusLabel(run, segment) {
  if (!segment.enabled) return ["已停用", ""];
  if (!run) return ["待排程", ""];
  const labels = {
    waiting: "等待开始",
    running: "执行中",
    waiting_for_capture: "等待捕获",
    completed: "已完成",
    expired: "已结束"
  };
  const statusClass = run.status === "running" ? "running" : (run.lastError ? "failed" : "");
  return [labels[run.status] || run.status, statusClass];
}

function renderCapture(captured) {
  const ready = Boolean(captured);
  elements.captureBadge.textContent = ready ? "已捕获请求" : "等待捕获请求";
  elements.captureBadge.className = `status-badge${ready ? " ready" : ""}`;
  elements.testButton.disabled = !ready;
  elements.channelId.textContent = captured?.channelId || "尚未捕获";
  elements.capturedAt.textContent = formatDate(captured?.capturedAt);
  elements.pageUrl.textContent = captured?.pageUrl || "-";
  if (captured?.protectedParams) {
    const { clientVersion, xSessdata, clientId } = captured.protectedParams;
    elements.protectedParams.textContent = `clientVersion=${clientVersion} · xSessdata=${xSessdata} · clientId=${clientId}`;
  } else {
    elements.protectedParams.textContent = "clientVersion / xSessdata / clientId";
  }
}

function renderChat(state) {
  const context = state.socketContext || {};
  const missing = ["roomId", "channelId", "accountId", "sessionId"]
    .filter((key) => !context[key]);
  if (!state.capturedRequest?.protectedParams?.xSessdata) missing.push("xSessdata");
  const socketReady = Boolean(state.socketRequest);
  const ready = socketReady && missing.length === 0;
  const identityLabel = context.sessionIdSource === "captured"
    ? "网页会话身份"
    : "等待网页身份";
  elements.socketStatus.textContent = ready
    ? `套接字已就绪 · ${identityLabel} · 会话 ${context.sessionId}`
    : `${socketReady ? "已捕获套接字" : "尚未捕获套接字"}${missing.length ? ` · 缺少 ${missing.join(", ")}` : ""}`;
  const signature = JSON.stringify([state.settings.chat.nicknames, state.settings.chat.messages]);
  if (!chatDraftDirty && signature !== loadedChatSignature) {
    chatDraft = {
      nicknames: [...state.settings.chat.nicknames],
      messages: [...state.settings.chat.messages]
    };
    loadedChatSignature = signature;
  }
  elements.testChatButton.disabled = !ready || !chatDraft.nicknames.length || !chatDraft.messages.length;
  if (!chatDraftDirty) elements.chatEnabled.checked = state.settings.chat.enabled;
  renderPool("nicknames");
  renderPool("messages");
  updateChatPanelSummary();
}

function updateChatPanelSummary() {
  const enabled = elements.chatEnabled.checked;
  const scheduleCount = currentState?.settings.chat.schedules?.length || 0;
  elements.chatPoolSummary.textContent = `${enabled ? "已启用" : "已停用"} · ${chatDraft.nicknames.length} 个昵称 · ${chatDraft.messages.length} 条消息 · ${scheduleCount} 个时间段`;
}

function renderPool(poolName) {
  const isNickname = poolName === "nicknames";
  const list = isNickname ? elements.nicknameList : elements.messageList;
  const count = isNickname ? elements.nicknameCount : elements.messageCount;
  const items = chatDraft[poolName];
  count.textContent = `${items.length} 项`;
  if (!items.length) {
    list.innerHTML = `<div class="pool-empty">${isNickname ? "还没有昵称" : "还没有预备消息"}</div>`;
    return;
  }
  list.innerHTML = items.map((item, index) => `
    <div class="pool-item">
      <div>
        <input value="${escapeHtml(item)}" maxlength="${isNickname ? 40 : 500}"
          data-pool-input="${poolName}" data-index="${index}" aria-label="${isNickname ? "昵称" : "消息"} ${index + 1}">
        ${isNickname ? "" : `<span class="pool-item-meta">${item.length} 字</span>`}
      </div>
      <button class="pool-delete" type="button" data-delete-pool="${poolName}" data-index="${index}"
        title="删除" aria-label="删除${isNickname ? "昵称" : "消息"}">×</button>
    </div>`).join("");
}

function renderSchedules(
  schedules,
  runs,
  container = elements.scheduleList,
  emptyText = "还没有时间段，请在左侧添加。",
  globallyEnabled = true
) {
  if (schedules.length === 0) {
    container.innerHTML = `<div class="empty-state">${escapeHtml(emptyText)}</div>`;
    return;
  }
  container.innerHTML = schedules
    .slice()
    .sort((a, b) => a.startAt - b.startAt)
    .map((segment) => {
      const run = runs[segment.id];
      const [label, statusClass] = globallyEnabled ? statusLabel(run, segment) : ["聊天已停用", ""];
      const sent = run?.sentCount || 0;
      const success = run?.successCount || 0;
      const failure = run?.failureCount || 0;
      const concurrency = Number(segment.concurrency || 1);
      const peaks = normalizePeaks(segment);
      const peakLabel = peaks.length
        ? `<br>并发 ${concurrency} · ${peaks.length} 个高峰`
        : `<br>并发 ${concurrency} · 均匀分配`;
      return `
        <article class="schedule-item${segment.enabled ? "" : " disabled"}" data-id="${escapeHtml(segment.id)}">
          <div>
            <div class="schedule-header">
              <span class="schedule-name">${escapeHtml(segment.name)}</span>
              <span class="run-status ${statusClass}">${escapeHtml(label)}</span>
            </div>
            <p class="schedule-meta">${formatDate(segment.startAt)} 至 ${formatDate(segment.endAt)}<br>
              进度 ${sent} / ${segment.totalRequests} · 成功 ${success} · 失败 ${failure}${run?.inFlightCount ? ` · 请求中 ${run.inFlightCount}` : ""}${peakLabel}${run?.lastError ? `<br>${escapeHtml(run.lastError)}` : ""}
            </p>
          </div>
          <div class="schedule-actions">
            <label class="toggle" title="启用或停用">
              <input type="checkbox" data-action="toggle" ${segment.enabled ? "checked" : ""} aria-label="启用或停用">
              <span></span>
            </label>
            <button class="text-button" type="button" data-action="edit">编辑</button>
            <button class="text-button danger" type="button" data-action="delete">删除</button>
          </div>
        </article>`;
    }).join("");
}

function renderExcelTasks(tasks) {
  const counts = tasks.reduce((result, task) => {
    result[task.status] = (result[task.status] || 0) + 1;
    return result;
  }, {});
  elements.excelTotalCount.textContent = String(tasks.length);
  elements.excelPendingCount.textContent = String(counts.pending || 0);
  elements.excelSentCount.textContent = String(counts.sent || 0);
  elements.excelProblemCount.textContent = String((counts.failed || 0) + (counts.missed || 0));
  elements.excelPanelSummary.textContent = `全部 ${tasks.length} · 待发送 ${counts.pending || 0} · 已发送 ${counts.sent || 0} · 异常 ${(counts.failed || 0) + (counts.missed || 0)}`;
  elements.clearExcelTasksButton.disabled = tasks.length === 0;
  if (!tasks.length) {
    elements.excelTasksBody.innerHTML = '<tr><td colspan="6">尚未导入 Excel 定时任务</td></tr>';
    return;
  }
  const statusLabels = { pending: "待发送", sent: "已发送", failed: "失败", missed: "已错过" };
  const visible = tasks.slice().sort((left, right) => left.publishAt - right.publishAt).slice(0, 500);
  elements.excelTasksBody.innerHTML = visible.map((task) => `
    <tr data-excel-task-id="${escapeHtml(task.id)}">
      <td>${formatDate(task.publishAt)}</td>
      <td>${escapeHtml(task.nickname)}</td>
      <td>${escapeHtml(task.message)}</td>
      <td><span class="task-status ${escapeHtml(task.status)}" title="${escapeHtml(task.lastError || "")}">
        ${escapeHtml(statusLabels[task.status] || task.status)}
      </span></td>
      <td>${formatDate(task.sentAt)}</td>
      <td><button class="text-button danger" type="button" data-delete-excel-task>删除</button></td>
    </tr>`).join("") + (tasks.length > 500
      ? `<tr><td colspan="6">任务较多，仅显示前 500 条；全部任务仍会正常调度。</td></tr>`
      : "");
}

function renderLogs(logs) {
  if (logs.length === 0) {
    elements.logsBody.innerHTML = '<tr><td colspan="6">暂无执行记录</td></tr>';
    return;
  }
  elements.logsBody.innerHTML = logs.map((log) => `
    <tr>
      <td>${formatDate(log.createdAt)}</td>
      <td>${escapeHtml(log.segmentName)}</td>
      <td>${escapeHtml(log.nickname || "-")}</td>
      <td title="${escapeHtml(log.message || "")}">${escapeHtml(log.message || "-")}</td>
      <td class="${log.ok ? "result-ok" : "result-error"}">${log.ok ? `成功 (${log.status})` : escapeHtml(log.error || "失败")}</td>
      <td>${Number(log.durationMs) || 0} ms</td>
    </tr>`).join("");
}

function render(state) {
  currentState = state;
  renderCapture(state.capturedRequest);
  renderChat(state);
  renderSchedules(state.settings.schedules, state.runs);
  renderSchedules(
    state.settings.chat.schedules || [],
    state.chatRuns || {},
    elements.chatScheduleList,
    "还没有聊天时间段，请在左侧添加。",
    state.settings.chat.enabled
  );
  renderExcelTasks(state.excelChatTasks || []);
  renderLogs(state.logs);
}

async function refresh() {
  render(await sendMessage("getState"));
}

function resetForm() {
  const start = Date.now() + 5 * 60000;
  elements.form.reset();
  elements.scheduleId.value = crypto.randomUUID();
  elements.scheduleName.value = "";
  elements.startAt.value = toLocalInput(start);
  elements.endAt.value = toLocalInput(start + 60 * 60000);
  elements.totalRequests.value = "10";
  elements.concurrency.value = "1";
  elements.peakEnabled.checked = false;
  peakDraft = [createPeak(50, 6, 12)];
  activePeakId = peakDraft[0].id;
  elements.peakWidth.value = "12";
  elements.formTitle.textContent = "新增时间段";
  elements.cancelEditButton.classList.add("hidden");
  updatePreview();
}

function renderPeakPreview(startAt, endAt, count, calculateSchedule = true) {
  const enabled = elements.peakEnabled.checked;
  elements.peakControls.classList.toggle("hidden", !enabled);
  if (!enabled || !Number.isFinite(startAt) || !Number.isFinite(endAt) || endAt <= startAt
    || !Number.isInteger(count) || count < 1) {
    elements.peakSummary.textContent = enabled ? "等待有效输入" : "均匀分配";
    elements.peakResults.innerHTML = "";
    elements.peakScheduleResult.innerHTML = "";
    return;
  }

  if (peakDraft.length === 0) {
    peakDraft = [createPeak(50, 6, 12)];
    activePeakId = peakDraft[0].id;
  }
  const current = activePeak();
  elements.peakWidth.value = String(current.widthPercent);
  const currentMetrics = peakMetrics(startAt, endAt, current);
  elements.peakWidthLabel.textContent = `当前高峰主要影响范围：约 ${Math.max(1, Math.round(currentMetrics.durationMinutes))} 分钟`;
  const concurrency = Math.max(1, Number(elements.concurrency.value) || 1);
  const orderedPeaks = [...peakDraft].sort((left, right) => left.centerPercent - right.centerPercent);
  const results = orderedPeaks.map((peak, index) => ({
    peak,
    index,
    metrics: peakMetrics(startAt, endAt, peak)
  }));
  elements.peakSummary.textContent = `${peakDraft.length} 个高峰 · 共 ${count} 人`;
  elements.peakCountLabel.textContent = `${peakDraft.length} / 3 个高峰`;
  elements.addPeakButton.disabled = peakDraft.length >= 3;
  elements.deletePeakButton.disabled = peakDraft.length <= 1;
  elements.peakResults.innerHTML = results.map(({ peak, index, metrics }) => `
    <button class="peak-result-row${peak.id === activePeakId ? " active" : ""}" type="button" data-peak-id="${escapeHtml(peak.id)}">
      <strong>高峰 ${index + 1}${peak.id === activePeakId ? "（当前）" : ""}</strong>
      <span>时间：${formatCompactDate(metrics.centerAt)}</span>
      <span>主要影响范围：${formatCompactDate(metrics.windowStartAt)} - ${formatCompactDate(metrics.windowEndAt)}</span>
      <span>集中程度：${concentrationLabel(peak.strength)}</span>
    </button>`).join("");
  if (calculateSchedule) {
    const preview = plannedSchedulePreview(
      elements.scheduleId.value || "options-preview",
      startAt,
      endAt,
      count,
      concurrency,
      peakDraft,
      results
    );
    const peakRequestCount = preview.groups.reduce((sum, group) => sum + group.count, 0);
    elements.peakScheduleResult.innerHTML = `
    <div class="peak-schedule-heading">
      <strong>最终发送预览</strong>
      <span>高峰时段 ${peakRequestCount} 人 · 其他时段 ${preview.remainingCount} 人</span>
    </div>
    ${preview.groups.map((group) => `
      <div class="peak-schedule-row">
        <strong>${group.peakNumbers.length > 1 ? `高峰 ${group.peakNumbers.join("、")} 合并` : `高峰 ${group.peakNumbers[0]} 时段`}</strong>
        <span>${formatCompactDate(group.startAt)} - ${formatCompactDate(group.endAt)} · ${group.count} 人</span>
        <span>最高约 ${group.maxPerMinute} 人/分钟</span>
      </div>`).join("")}
    <div class="peak-schedule-row">
      <strong>其他时段</strong>
      <span>${preview.remainingCount} 人分布在上述时段之外</span>
      <span>总计 ${count} 人</span>
    </div>`;
    elements.peakRangeLabel.textContent = `以上人数按最终排程逐条统计；重叠的高峰时段已合并，不会重复计数。每批最多同时发送 ${concurrency} 人，下一批按计划时间发出，不等待上一批返回。`;
  } else {
    elements.peakScheduleResult.innerHTML = `
      <div class="peak-schedule-heading">
        <strong>最终发送预览</strong>
        <span>调整完成后更新</span>
      </div>`;
  }
  drawPeakCurve(startAt, endAt, count);
}

function updateDistributionPreview(startInput, endInput, countInput, preview, calculatePeakSchedule = true) {
  const start = new Date(startInput.value).getTime();
  const end = new Date(endInput.value).getTime();
  const count = Number(countInput.value);
  const isViewerSchedule = countInput === elements.totalRequests;
  const concurrency = isViewerSchedule ? Number(elements.concurrency.value) : 1;
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start || count < 1) {
    preview.textContent = "请输入有效的时间范围和次数。";
    if (isViewerSchedule) renderPeakPreview(start, end, count, calculatePeakSchedule);
    return;
  }
  const batches = Math.ceil(count / Math.max(1, concurrency || 1));
  const averageSeconds = (end - start) / batches / 1000;
  const readable = averageSeconds >= 60
    ? `约每 ${(averageSeconds / 60).toFixed(1)} 分钟`
    : `约每 ${averageSeconds.toFixed(1)} 秒`;
  preview.textContent = `${readable}发出 1 批，共 ${batches} 批；每批最多同时发送 ${Math.max(1, concurrency || 1)} 人。${isViewerSchedule ? "下一批按计划时间发出，不等待上一批返回。" : "实际时刻会在各批次区间内随机错开。"}`;
  if (isViewerSchedule) renderPeakPreview(start, end, count, calculatePeakSchedule);
}

function updatePreview(calculatePeakSchedule = true) {
  updateDistributionPreview(
    elements.startAt,
    elements.endAt,
    elements.totalRequests,
    elements.distributionPreview,
    calculatePeakSchedule
  );
}

function updateChatPreview() {
  updateDistributionPreview(
    elements.chatStartAt,
    elements.chatEndAt,
    elements.chatTotalRequests,
    elements.chatDistributionPreview
  );
}

function resetChatScheduleForm() {
  const start = Date.now() + 5 * 60000;
  elements.chatScheduleForm.reset();
  elements.chatScheduleId.value = "";
  elements.chatScheduleName.value = "";
  elements.chatStartAt.value = toLocalInput(start);
  elements.chatEndAt.value = toLocalInput(start + 60 * 60000);
  elements.chatTotalRequests.value = "10";
  elements.chatFormTitle.textContent = "新增聊天时间段";
  elements.cancelChatEditButton.classList.add("hidden");
  updateChatPreview();
}

async function saveSettings(settings) {
  await chrome.storage.local.set({ settings });
  render(await sendMessage("syncSchedules"));
}

function linesFrom(value) {
  return [...new Set(value.split(/\r?\n/).map((line) => line.trim()).filter(Boolean))];
}

function addPoolValues(poolName, values) {
  const existing = new Set(chatDraft[poolName]);
  let added = 0;
  for (const value of values.map((item) => item.trim()).filter(Boolean)) {
    if (existing.has(value)) continue;
    existing.add(value);
    chatDraft[poolName].push(value);
    added += 1;
  }
  if (added > 0) chatDraftDirty = true;
  renderPool(poolName);
  updateChatPanelSummary();
  return added;
}

elements.chatForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const nicknames = chatDraft.nicknames.map((item) => item.trim()).filter(Boolean);
  const messages = chatDraft.messages.map((item) => item.trim()).filter(Boolean);
  if (elements.chatEnabled.checked && (!nicknames.length || !messages.length)) {
    showToast("启用随机聊天前，请至少配置一个昵称和一条消息", true);
    return;
  }
  const chat = {
    ...currentState.settings.chat,
    enabled: elements.chatEnabled.checked,
    nicknames: [...new Set(nicknames)],
    messages: [...new Set(messages)]
  };
  chatDraft = { nicknames: [...chat.nicknames], messages: [...chat.messages] };
  loadedChatSignature = JSON.stringify([chat.nicknames, chat.messages]);
  chatDraftDirty = false;
  await saveSettings({
    ...currentState.settings,
    chat
  });
  showToast("聊天配置已保存");
});

elements.addNicknameButton.addEventListener("click", () => {
  const added = addPoolValues("nicknames", [elements.nicknameInput.value]);
  if (added) elements.nicknameInput.value = "";
  else showToast("昵称为空或已存在", true);
});

elements.addMessageButton.addEventListener("click", () => {
  const added = addPoolValues("messages", [elements.messageInput.value]);
  if (added) elements.messageInput.value = "";
  else showToast("消息为空或已存在", true);
});

elements.chatForm.addEventListener("click", (event) => {
  const deleteButton = event.target.closest("button[data-delete-pool]");
  if (deleteButton) {
    const poolName = deleteButton.dataset.deletePool;
    chatDraft[poolName].splice(Number(deleteButton.dataset.index), 1);
    chatDraftDirty = true;
    renderPool(poolName);
    updateChatPanelSummary();
    return;
  }
  const clearButton = event.target.closest("button[data-clear-pool]");
  if (clearButton) {
    chatDraft[clearButton.dataset.clearPool] = [];
    chatDraftDirty = true;
    renderPool(clearButton.dataset.clearPool);
    updateChatPanelSummary();
    return;
  }
  const importButton = event.target.closest("button[data-import-pool]");
  if (importButton) {
    const poolName = importButton.dataset.importPool;
    const textarea = poolName === "nicknames" ? elements.nicknameBulk : elements.messageBulk;
    const parsed = linesFrom(textarea.value);
    const added = addPoolValues(poolName, parsed);
    textarea.value = "";
    showToast(`已添加 ${added} 项，自动忽略重复内容`);
  }
});

elements.chatForm.addEventListener("change", (event) => {
  const input = event.target.closest("input[data-pool-input]");
  if (!input) return;
  const poolName = input.dataset.poolInput;
  const index = Number(input.dataset.index);
  const value = input.value.trim();
  if (!value) chatDraft[poolName].splice(index, 1);
  else chatDraft[poolName][index] = value;
  chatDraft[poolName] = [...new Set(chatDraft[poolName])];
  chatDraftDirty = true;
  renderPool(poolName);
  updateChatPanelSummary();
});

[elements.nicknameInput, elements.messageInput].forEach((input) => {
  input.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    (input === elements.nicknameInput ? elements.addNicknameButton : elements.addMessageButton).click();
  });
});

elements.excelFile.addEventListener("change", async () => {
  pendingExcelImport = null;
  elements.importExcelButton.disabled = true;
  elements.excelImportPreview.className = "import-preview";
  const file = elements.excelFile.files?.[0];
  if (!file) {
    elements.excelImportPreview.textContent = "请选择按照模板填写的 Excel 文件。";
    return;
  }
  if (file.size > 5 * 1024 * 1024) {
    elements.excelImportPreview.textContent = "文件超过 5 MB，无法导入。";
    elements.excelImportPreview.classList.add("error");
    return;
  }
  try {
    const bytes = await file.arrayBuffer();
    pendingExcelImport = ExcelChatImport.parseWorkbook(bytes, file.name, XLSX);
    const first = pendingExcelImport.tasks[0];
    const last = pendingExcelImport.tasks.at(-1);
    elements.excelImportPreview.textContent = `已读取 ${pendingExcelImport.tasks.length} 条 · ${formatDate(first.publishAt)} 至 ${formatDate(last.publishAt)}`;
    elements.importExcelButton.disabled = false;
  } catch (error) {
    elements.excelImportPreview.textContent = error.message;
    elements.excelImportPreview.classList.add("error");
  }
});

elements.importExcelButton.addEventListener("click", async () => {
  if (!pendingExcelImport) return;
  elements.importExcelButton.disabled = true;
  try {
    const result = await sendMessage("importExcelTasks", {
      tasks: pendingExcelImport.tasks,
      mode: elements.excelImportMode.value,
      sourceFile: pendingExcelImport.fileName
    });
    elements.excelImportPreview.className = "import-preview";
    elements.excelImportPreview.textContent = `成功导入 ${result.imported} 条，忽略重复 ${result.duplicates} 条，已错过 ${result.missed} 条。`;
    pendingExcelImport = null;
    elements.excelFile.value = "";
    await refresh();
  } catch (error) {
    elements.excelImportPreview.textContent = error.message;
    elements.excelImportPreview.classList.add("error");
    elements.importExcelButton.disabled = false;
  }
});

elements.clearExcelTasksButton.addEventListener("click", async () => {
  if (!window.confirm("确定清空全部 Excel 定时任务及其状态吗？")) return;
  await sendMessage("clearExcelTasks");
  await refresh();
  showToast("Excel 定时任务已清空");
});

elements.excelTasksBody.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-delete-excel-task]");
  if (!button) return;
  const row = button.closest("[data-excel-task-id]");
  await sendMessage("deleteExcelTask", { id: row.dataset.excelTaskId });
  await refresh();
});

elements.form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const startAt = new Date(elements.startAt.value).getTime();
  const endAt = new Date(elements.endAt.value).getTime();
  const totalRequests = Number(elements.totalRequests.value);
  const concurrency = Number(elements.concurrency.value);
  const peaks = peaksFromForm();
  if (!Number.isFinite(startAt) || !Number.isFinite(endAt) || endAt <= startAt) {
    showToast("结束时间必须晚于开始时间", true);
    return;
  }
  if (!Number.isInteger(totalRequests) || totalRequests < 1 || totalRequests > 10000) {
    showToast("请求次数必须是 1 至 10000 的整数", true);
    return;
  }
  if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 100) {
    showToast("单批并发必须是 1 至 100 的整数", true);
    return;
  }
  if (peaks.length > 3 || peaks.some((peak) => peak.centerPercent < 0 || peak.centerPercent > 100
    || peak.strength < 0 || peak.strength > 20 || peak.widthPercent < 3 || peak.widthPercent > 30)) {
    showToast("波峰位置、高度或宽度无效", true);
    return;
  }
  const batchCount = Math.ceil(totalRequests / concurrency);
  if ((endAt - startAt) / batchCount < 1000) {
    showToast("请求批次过于密集，请保证平均批次间隔不少于 1 秒", true);
    return;
  }

  const id = elements.scheduleId.value || crypto.randomUUID();
  const old = currentState.settings.schedules.find((item) => item.id === id);
  const segment = {
    id,
    name: elements.scheduleName.value.trim(),
    startAt,
    endAt,
    totalRequests,
    concurrency,
    peaks,
    enabled: old?.enabled ?? true
  };
  const schedules = currentState.settings.schedules.filter((item) => item.id !== id);
  schedules.push(segment);
  await saveSettings({ ...currentState.settings, schedules });
  resetForm();
  showToast("时间段已保存");
});

elements.chatScheduleForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const startAt = new Date(elements.chatStartAt.value).getTime();
  const endAt = new Date(elements.chatEndAt.value).getTime();
  const totalRequests = Number(elements.chatTotalRequests.value);
  if (!Number.isFinite(startAt) || !Number.isFinite(endAt) || endAt <= startAt) {
    showToast("聊天结束时间必须晚于开始时间", true);
    return;
  }
  if (!Number.isInteger(totalRequests) || totalRequests < 1 || totalRequests > 10000) {
    showToast("发送次数必须是 1 至 10000 的整数", true);
    return;
  }
  if ((endAt - startAt) / totalRequests < 1000) {
    showToast("聊天发送过于密集，请保证平均间隔不少于 1 秒", true);
    return;
  }

  const schedules = currentState.settings.chat.schedules || [];
  const id = elements.chatScheduleId.value || crypto.randomUUID();
  const old = schedules.find((item) => item.id === id);
  const segment = {
    id,
    name: elements.chatScheduleName.value.trim(),
    startAt,
    endAt,
    totalRequests,
    enabled: old?.enabled ?? true
  };
  const nextSchedules = schedules.filter((item) => item.id !== id);
  nextSchedules.push(segment);
  await saveSettings({
    ...currentState.settings,
    chat: { ...currentState.settings.chat, schedules: nextSchedules }
  });
  resetChatScheduleForm();
  showToast("聊天时间段已保存");
});

elements.scheduleList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const item = button.closest("[data-id]");
  const segment = currentState.settings.schedules.find((entry) => entry.id === item.dataset.id);
  if (!segment) return;
  if (button.dataset.action === "edit") {
    elements.scheduleId.value = segment.id;
    elements.scheduleName.value = segment.name;
    elements.startAt.value = toLocalInput(segment.startAt);
    elements.endAt.value = toLocalInput(segment.endAt);
    elements.totalRequests.value = String(segment.totalRequests);
    elements.concurrency.value = String(segment.concurrency || 1);
    peakDraft = normalizePeaks(segment);
    if (peakDraft.length === 0) peakDraft = [createPeak(50, 6, 12)];
    activePeakId = peakDraft[0].id;
    elements.peakEnabled.checked = Boolean(segment.peaks?.length || segment.peak?.enabled);
    elements.peakWidth.value = String(peakDraft[0].widthPercent);
    elements.formTitle.textContent = "编辑时间段";
    elements.cancelEditButton.classList.remove("hidden");
    updatePreview();
    elements.form.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  if (button.dataset.action === "delete") {
    const schedules = currentState.settings.schedules.filter((entry) => entry.id !== segment.id);
    await saveSettings({ ...currentState.settings, schedules });
    if (elements.scheduleId.value === segment.id) resetForm();
    showToast("时间段已删除");
  }
});

elements.scheduleList.addEventListener("change", async (event) => {
  const toggle = event.target.closest('input[data-action="toggle"]');
  if (!toggle) return;
  const id = toggle.closest("[data-id]").dataset.id;
  const schedules = currentState.settings.schedules.map((segment) =>
    segment.id === id ? { ...segment, enabled: toggle.checked } : segment
  );
  await saveSettings({ ...currentState.settings, schedules });
});

elements.chatScheduleList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const item = button.closest("[data-id]");
  const schedules = currentState.settings.chat.schedules || [];
  const segment = schedules.find((entry) => entry.id === item.dataset.id);
  if (!segment) return;
  if (button.dataset.action === "edit") {
    elements.chatScheduleId.value = segment.id;
    elements.chatScheduleName.value = segment.name;
    elements.chatStartAt.value = toLocalInput(segment.startAt);
    elements.chatEndAt.value = toLocalInput(segment.endAt);
    elements.chatTotalRequests.value = String(segment.totalRequests);
    elements.chatFormTitle.textContent = "编辑聊天时间段";
    elements.cancelChatEditButton.classList.remove("hidden");
    updateChatPreview();
    elements.chatScheduleForm.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  if (button.dataset.action === "delete") {
    const nextSchedules = schedules.filter((entry) => entry.id !== segment.id);
    await saveSettings({
      ...currentState.settings,
      chat: { ...currentState.settings.chat, schedules: nextSchedules }
    });
    if (elements.chatScheduleId.value === segment.id) resetChatScheduleForm();
    showToast("聊天时间段已删除");
  }
});

elements.chatScheduleList.addEventListener("change", async (event) => {
  const toggle = event.target.closest('input[data-action="toggle"]');
  if (!toggle) return;
  const id = toggle.closest("[data-id]").dataset.id;
  const schedules = (currentState.settings.chat.schedules || []).map((segment) =>
    segment.id === id ? { ...segment, enabled: toggle.checked } : segment
  );
  await saveSettings({
    ...currentState.settings,
    chat: { ...currentState.settings.chat, schedules }
  });
});

elements.testButton.addEventListener("click", async () => {
  elements.testButton.disabled = true;
  try {
    const result = await sendMessage("testRequest");
    showToast(result.ok ? `测试成功：HTTP ${result.status}` : `测试失败：${result.error}`, !result.ok);
    await refresh();
  } catch (error) {
    showToast(error.message, true);
  } finally {
    elements.testButton.disabled = !currentState?.capturedRequest;
  }
});

elements.testChatButton.addEventListener("click", async () => {
  if (chatDraftDirty) {
    showToast("请先保存聊天配置再进行测试", true);
    return;
  }
  elements.testChatButton.disabled = true;
  try {
    const result = await sendMessage("testChat");
    showToast(result.ok ? "随机消息发送成功" : `发送失败：${result.error}`, !result.ok);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    await refresh();
  }
});

elements.clearLogsButton.addEventListener("click", async () => {
  await sendMessage("clearLogs");
  await refresh();
  showToast("执行记录已清空");
});

elements.cancelEditButton.addEventListener("click", resetForm);
elements.cancelChatEditButton.addEventListener("click", resetChatScheduleForm);
elements.chatEnabled.addEventListener("change", () => {
  chatDraftDirty = true;
  updateChatPanelSummary();
});
[elements.startAt, elements.endAt, elements.totalRequests]
  .forEach((input) => input.addEventListener("input", () => updatePreview()));
[elements.concurrency, elements.peakEnabled]
  .forEach((input) => input.addEventListener("input", () => updatePreview()));
elements.peakWidth.addEventListener("input", () => {
  const peak = activePeak();
  if (peak) peak.widthPercent = Number(elements.peakWidth.value);
  updatePreview(false);
});
elements.peakWidth.addEventListener("change", () => updatePreview());
elements.addPeakButton.addEventListener("click", () => {
  if (peakDraft.length >= 3) return;
  const candidates = [50, 25, 75];
  const center = candidates.find((value) => peakDraft.every((peak) => Math.abs(peak.centerPercent - value) > 10))
    ?? Math.min(90, 15 + peakDraft.length * 30);
  const peak = createPeak(center, 6, 12);
  peakDraft.push(peak);
  activePeakId = peak.id;
  updatePreview();
});
elements.deletePeakButton.addEventListener("click", () => {
  if (peakDraft.length <= 1) return;
  peakDraft = peakDraft.filter((peak) => peak.id !== activePeakId);
  activePeakId = peakDraft[0].id;
  updatePreview();
});
elements.peakResults.addEventListener("click", (event) => {
  const row = event.target.closest("[data-peak-id]");
  if (!row) return;
  activePeakId = row.dataset.peakId;
  updatePreview();
});
elements.peakCanvas.addEventListener("pointerdown", (event) => {
  event.preventDefault();
  const rect = elements.peakCanvas.getBoundingClientRect();
  const pointerX = event.clientX - rect.left;
  const pointerY = event.clientY - rect.top;
  const nearest = peakDraft.map((peak) => {
    const x = 10 + peak.centerPercent / 100 * (rect.width - 20);
    const y = rect.height - 41 - Math.min(rect.height - 45, densityAtPosition(peak.centerPercent / 100) * 5);
    return { peak, distance: Math.hypot(pointerX - x, pointerY - y) };
  }).sort((left, right) => left.distance - right.distance)[0];
  if (nearest?.distance <= 18) {
    activePeakId = nearest.peak.id;
  } else if (peakDraft.length < 3) {
    const center = Math.max(0, Math.min(100, pointerX / rect.width * 100));
    const lift = Math.max(0.5, Math.min(20, (rect.height - pointerY - 25) / 5));
    const peak = createPeak(Math.round(center), Math.round(lift * 10) / 10, 12);
    peakDraft.push(peak);
    activePeakId = peak.id;
  }
  elements.peakCanvas.setPointerCapture(event.pointerId);
  peakDragState = { pointerId: event.pointerId };
  updatePeakFromPointer(event);
});
elements.peakCanvas.addEventListener("pointermove", (event) => {
  if (peakDragState?.pointerId === event.pointerId) updatePeakFromPointer(event);
});
elements.peakCanvas.addEventListener("pointerup", () => {
  peakDragState = null;
  updatePreview();
});
elements.peakCanvas.addEventListener("pointercancel", () => {
  peakDragState = null;
  updatePreview();
});
[elements.chatStartAt, elements.chatEndAt, elements.chatTotalRequests]
  .forEach((input) => input.addEventListener("input", updateChatPreview));

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.capturedRequest || changes.socketRequest || changes.socketContext
    || changes.runs || changes.chatRuns || changes.excelChatTasks || changes.logs)) {
    void refresh();
  }
});

resetForm();
resetChatScheduleForm();
refresh().catch((error) => showToast(error.message, true));

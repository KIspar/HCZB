/* Portable JSON tasks for internal room execution. */
(function (root) {
    'use strict';
    const C = root.RecruitCore || (typeof require === 'function' ? require('./core.js') : null);
    const format = 'recruitment-task-v2', own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
    const object = v => v && typeof v === 'object' && !Array.isArray(v);
    function fail(message) { throw Error('任务文件无效：' + message); }
    function list(v, max, label) { if (!Array.isArray(v) || v.length > max) fail(label + '数量或格式不正确'); return v; }
    function string(v, max, label, optional = false) {
        if (optional && (v === undefined || v === null)) return '';
        if (typeof v !== 'string' || v.length > max || (!optional && !v.trim())) fail(label + '格式不正确');
        return C.redact(v, max);
    }
    function identifier(v, label) { const id = string(v, 180, label); if (['__proto__', 'constructor', 'prototype'].includes(id)) fail(label + '不可用'); return id; }
    function finite(v, min, max, label) { if (typeof v !== 'number' || !Number.isFinite(v) || v < min || v > max) fail(label + '超出范围'); return v; }
    function normalize(raw, id, now) {
        if (!object(raw) || ![format, 'recruitment-ai-v1'].includes(raw.format)) fail('不支持此文件类型，请选择编排台导出的JSON');
        if (raw.format === format && (raw.schemaVersion !== 2 || !['public-assistant', 'internal-json'].includes(raw.execution))) fail('不支持此任务版本或执行类型');
        const companies = list(raw.companies, 1000, '企业').map(c => {
            if (!object(c)) fail('企业格式不正确');
            return { id: identifier(c.id, '企业编号'), name: string(c.name, 160, '企业名称'), jobs: list(c.jobs, 1000, '岗位').map(j => {
                if (!object(j)) fail('岗位格式不正确');
                return { title: string(j.title, 120, '岗位名称'), salary: string(j.salary, 6000, '薪资', true), sources: list(j.sources || [], 100, '资料来源').map(s => {
                    if (!object(s)) fail('资料来源格式不正确');
                    return { sheet: string(s.sheet, 180, '工作表名称'), row: finite(s.row, 1, 30001, '来源行号') };
                }) };
            }) };
        });
        if (!companies.length || companies.some(c => !c.jobs.length) || companies.reduce((n, c) => n + c.jobs.length, 0) > 30000) fail('缺少企业岗位或数量超限');
        const companyIds = new Set(companies.map(c => c.id));
        if (companyIds.size !== companies.length) fail('企业编号重复');
        const nodes = list(raw.nodes, 1000, '企业节点').map(n => {
            if (!object(n) || !companyIds.has(n.id)) fail('节点引用未知企业');
            return { id: n.id, name: companies.find(c => c.id === n.id).name, duration: finite(n.duration, 1, 86400, '节点时长'), start: 0 };
        });
        if (nodes.length !== companies.length || new Set(nodes.map(n => n.id)).size !== nodes.length) fail('企业节点不完整或重复');
        let total = 0; for (const n of nodes) { n.start = total; total += n.duration; }
        if (total > 86400) fail('总时长不能超过24小时');
        const names = new Set();
        const personas = C.roomPersonas(list(raw.personas, 500, '内容视角').map(x => {
            if (!object(x)) fail('内容视角格式不正确');
            const roleId = identifier(x.id, '视角编号');
            const nickname = string(x.nickname, 80, '内部昵称');
            if (names.has(C.norm(nickname))) fail('JSON昵称重复');
            names.add(C.norm(nickname));
            return { id: roleId, nickname,
                age: C.number(x.age, 18, 70, 22), education: string(x.education, 60, '学历', true), experience: string(x.experience, 160, '经验', true),
                tone: string(x.tone, 80, '语气', true), interests: list(x.interests || [], 10, '兴趣').map(i => string(i, 80, '兴趣')),
                participation: ['全程', '间歇', '短停'].includes(x.participation) ? x.participation : '间歇',
                emojiPreference: string(x.emojiPreference, 30, '表情偏好', true), canAnswer: x.canAnswer === true };
        }), string(raw.name, 250, '任务名称'));
        const personaIds = new Set(personas.map(x => x.id));
        if (!personas.length || personaIds.size !== personas.length) fail('内容视角缺失或编号重复');
        if (!object(raw.batches)) fail('缺少企业内容批次');
        for (const key of Object.keys(raw.batches)) if (!companyIds.has(key)) fail('内容批次引用未知企业');
        const batches = Object.create(null), eventIds = new Set(); let eventCount = 0;
        for (const node of nodes) {
            const events = list(own(raw.batches, node.id) ? raw.batches[node.id] : [], 5000, '企业内容');
            const batch = []; const company = companies.find(c => c.id === node.id);
            for (const m of events) {
                if (!object(m)) fail('消息格式不正确');
                // Running-session feedback and synthetic attendance never move to another computer.
                if (m.epoch !== undefined || m.runId !== undefined || ['enter', 'leave'].includes(m.kind)) continue;
                const messageId = identifier(m.id, '消息编号');
                if (eventIds.has(messageId)) fail('消息编号重复'); eventIds.add(messageId);
                if (!personaIds.has(m.personaId)) fail('消息引用未知内容视角');
                if (!['chat', 'reply', 'question', 'answer', 'emoji', 'sticker'].includes(m.kind)) fail('未知消息类型');
                const at = finite(m.at, 0, node.duration * 1000, '消息时间');
                const text = string(m.text, 6000, '消息文本');
                let source;
                if (m.kind === 'answer') {
                    if (object(m.source) && ['title', 'salary'].includes(m.source.field) && Number.isInteger(m.source.jobIndex) && company.jobs[m.source.jobIndex]) source = { field: m.source.field, jobIndex: m.source.jobIndex };
                    else fail('解答缺少有效岗位来源');
                }
                const sticker = m.kind === 'sticker' && C.stickers.find(s => s.id === String(m.stickerId));
                if (m.kind === 'sticker' && !sticker) fail('包含未支持的平台表情');
                batch.push(C.roomEvent({ id: messageId, personaId: m.personaId, kind: m.kind, at, text: sticker ? '[' + sticker.name + ']' : text,
                    replyTo: m.replyTo === null || m.replyTo === undefined ? null : identifier(m.replyTo, '回复引用'), ...(source ? { source } : {}), ...(sticker ? { stickerId: sticker.id } : {}) }, company));
                if (++eventCount > 200000) fail('消息总量超限');
            }
            const byId = new Map(batch.map(m => [m.id, m]));
            for (const m of batch) if (m.replyTo) { const q = byId.get(m.replyTo); if (!q || q.at >= m.at || q.personaId === m.personaId) fail('对话引用缺失或顺序不正确'); }
            if (!batch.length) fail('企业“' + node.name + '”尚无完整内容，请先完成全部批次后导出');
            batches[node.id] = batch.sort((a, b) => a.at - b.at);
        }
        const theme = object(raw.theme) ? { kind: string(raw.theme.kind, 40, '主题', true), summary: string(raw.theme.summary, 200, '主题摘要', true), audience: list(raw.theme.audience || [], 20, '主题受众').map(x => string(x, 80, '受众')) } : { kind: '综合招聘', summary: '', audience: [] };
        return { id, name: string(raw.name, 250, '任务名称'), createdAt: now, updatedAt: now, importedAt: now,
            model: string(raw.model, 120, '模型', true), config: { minutes: total / 60, personaCount: personas.length, mode: 'full', generationVersion: 2, audienceVersion: raw.config?.audienceVersion === 1 ? 1 : 0 }, theme, companies, nodes, personas, batches,
            status: 'ready', progress: '已导入 · 按JSON昵称与节点时间执行', warnings: nodes.some(n => n.duration < 10) ? ['部分企业节点不足10秒，请检查原始计划时长。'] : [] };
    }
    function importPackage(raw, id, now) { return normalize(raw, id, now); }
    function exportPackage(project) {
        const p = normalize({ ...project, format, schemaVersion: 2, execution: 'internal-json' }, project.id, project.createdAt);
        const { importedAt, assistant, liveReplies, ...portable } = p;
        portable.progress = '完整JSON任务内容';
        return { format, schemaVersion: 2, execution: 'internal-json', ...portable, completedAt: project.completedAt || project.updatedAt };
    }
    root.RecruitTasks = { importPackage, exportPackage, format };
    if (typeof module !== 'undefined') module.exports = root.RecruitTasks;
})(globalThis);

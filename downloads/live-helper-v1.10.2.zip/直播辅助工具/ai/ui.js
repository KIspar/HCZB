/* Shared native UI primitives for the workbench and isolated live-room toolbar. */
(function (root) {
    'use strict';
    const paths = {
        trash: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
        play: '<path d="m8 5 11 7-11 7Z"/>',
        pause: '<path d="M8 5v14M16 5v14"/>',
        stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
        lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
        unlock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.5-2M12 14v3"/>',
        plus: '<path d="M12 5v14M5 12h14"/>',
        clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        chevron: '<path d="m8 10 4 4 4-4"/>',
        download: '<path d="M12 3v12m-4-4 4 4 4-4M5 16v4h14v-4"/>',
        upload: '<path d="M12 16V4m-4 4 4-4 4 4M5 16v4h14v-4"/>',
        refresh: '<path d="M20 7v5h-5M4 17v-5h5M6 7a7 7 0 0 1 12-1l2 3M4 15l2 3a7 7 0 0 0 12-1"/>',
        save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2ZM7 3v6h9V3M7 21v-8h10v8"/>',
        arrowLeft: '<path d="m10 5-7 7 7 7M3 12h18"/>',
        spinner: '<path d="M12 3a9 9 0 1 1-9 9"/>',
        list: '<path d="M9 6h12M9 12h12M9 18h12M3 6h.01M3 12h.01M3 18h.01"/>',
        check: '<path d="m5 12 4 4L19 6"/>'
    };
    const styles = `
:root,:host{--ui-bg:#ffffff;--ui-fg:#193c35;--ui-muted:#566e66;--ui-border:#d7e2dc;--ui-secondary:#f1f6f3;--ui-hover:#e6efea;--ui-primary:#176b57;--ui-primary-fg:#ffffff;--ui-primary-hover:#105744;--ui-ring:#5da18a;--ui-danger:#ac3c32;--ui-danger-hover:#fbeeea;--ui-amber:#85601a;--ui-radius:8px;--ui-ease:cubic-bezier(.16,1,.3,1)}
.ui-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:36px;padding:8px 11px;border:1px solid var(--ui-border);border-radius:var(--ui-radius);font-family:inherit;font-size:12px;font-weight:600;line-height:1.25;color:var(--ui-fg);background:var(--ui-bg);white-space:nowrap;cursor:pointer;touch-action:manipulation;transition:background-color 150ms,color 150ms,border-color 150ms,transform 150ms}
.ui-btn:hover:not(:disabled){background:var(--ui-hover)}.ui-btn:active:not(:disabled){transform:translateY(1px) scale(.975);box-shadow:inset 0 2px 3px #0002;transition-duration:70ms}.ui-btn:focus-visible{outline:2px solid var(--ui-ring);outline-offset:3px}.ui-btn:disabled{opacity:.45;cursor:not-allowed}.ui-btn[hidden]{display:none!important}
.ui-btn[data-variant="primary"]{color:var(--ui-primary-fg);background:var(--ui-primary);border-color:transparent}.ui-btn[data-variant="primary"]:hover:not(:disabled){background:var(--ui-primary-hover)}
.ui-btn[data-variant="secondary"]{background:var(--ui-secondary)}.ui-btn[data-variant="secondary"]:hover:not(:disabled){background:var(--ui-hover)}
.ui-btn[data-variant="ghost"]{border-color:transparent;background:transparent}.ui-btn[data-variant="danger"]{color:var(--ui-danger);background:transparent;border-color:transparent}.ui-btn[data-variant="danger"]:hover:not(:disabled){background:var(--ui-danger-hover)}
.ui-btn[aria-pressed="true"]{border-color:var(--ui-primary);background:var(--ui-hover)}.ui-btn[aria-busy="true"]{cursor:progress}
.ui-icon{display:inline-block;flex:none;width:16px;height:16px;vertical-align:middle;pointer-events:none}.ui-icon[data-name="spinner"]{animation:ui-spin 900ms linear infinite}.ui-numeric{font-variant-numeric:tabular-nums;font-feature-settings:"tnum"}
.ui-node-heading{display:flex;align-items:center;gap:9px;min-width:0;width:100%}.ui-node-number{display:grid;place-items:center;flex:none;width:24px;height:24px;border-radius:6px;background:var(--ui-secondary);color:var(--ui-muted);font-size:10px;font-variant-numeric:tabular-nums}.active .ui-node-number{background:var(--ui-primary);color:var(--ui-primary-fg)}.ui-node-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}.ui-node-meta{display:flex;align-items:center;justify-content:flex-end;gap:5px;min-height:25px;width:100%;padding-right:1px;isolation:isolate;pointer-events:none}.ui-node-tag{flex:none;position:relative;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;font-size:10px;line-height:1.4;padding:3px 7px;border:1px solid var(--ui-border);border-radius:5px;background:var(--ui-secondary);color:var(--ui-muted);font-variant-numeric:tabular-nums}.ui-node-tag:nth-child(1){z-index:1}.ui-node-tag:nth-child(2){z-index:2}.ui-node-tag:nth-child(3){z-index:3}.ui-node-tag:not(:last-child)>*{opacity:var(--tag-open,0)}.ui-node-tag .ui-icon{width:11px;height:11px}.active .ui-node-tag:last-child{color:var(--ui-primary-fg);background:var(--ui-primary);border-color:transparent}
@keyframes ui-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.ui-btn,.ui-icon{transition:none!important;animation:none!important}.ui-btn:active:not(:disabled){transform:none}}
`;
    function icon(name) {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        for (const [key, value] of Object.entries({ viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.8', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true', focusable: 'false', 'data-icon': 'inline-start', 'data-name': name, class: 'ui-icon' })) svg.setAttribute(key, value);
        svg.innerHTML = paths[name] || paths.play;
        return svg;
    }
    function labelButton(button, name, label) {
        // Skip unchanged labels so polling never replaces focused content or resets spinners.
        const signature = name + '|' + label;
        if (button.dataset.uiLabel === signature) return;
        button.dataset.uiLabel = signature;
        const span = document.createElement('span'); span.textContent = label;
        button.replaceChildren(icon(name), span);
    }
    function formatTime(ms, ceil = false) {
        let seconds = Math.max(0, (ceil ? Math.ceil : Math.floor)((Number(ms) || 0) / 1000));
        const hours = Math.floor(seconds / 3600); seconds %= 3600;
        return (hours ? hours + ':' : '') + String(Math.floor(seconds / 60)).padStart(2, '0') + ':' + String(seconds % 60).padStart(2, '0');
    }
    function timing(run, duration, now = Date.now()) {
        const scheduled = !!run && ['scheduled', 'waiting_live'].includes(run.status);
        const remaining = scheduled ? Math.max(0, (Number(run.scheduledAt) || now) - now) : 0;
        const elapsed = Math.max(0, (Number(run?.offset) || 0) + (run?.status === 'running' && !run.hold ? Math.max(0, now - run.anchor) * (run.mode === 'rehearsal' ? (run.speed || 1) : 1) : 0));
        return { scheduled, remaining, elapsed, label: scheduled ? (remaining > 0 ? '距离开始' : '正在启动') : '节点进度', value: scheduled ? formatTime(remaining, true) : formatTime(elapsed) + ' / ' + formatTime(duration), percent: scheduled ? 0 : duration > 0 ? Math.min(100, elapsed / duration * 100) : 0 };
    }
    function controls(run, pending = false) {
        const ended = !run || ['completed', 'stopped', 'expired'].includes(run.status), scheduled = ['scheduled', 'waiting_live'].includes(run?.status);
        const paused = ['paused', 'interrupted'].includes(run?.status);
        return {
            pause: { label: '暂停', icon: 'pause', hidden: paused || scheduled, disabled: ended || pending || run.status !== 'running' },
            resume: { label: '继续', icon: 'play', hidden: !paused, disabled: ended || pending },
            hold: { label: run?.hold ? '释放节点' : '锁定节点', icon: run?.hold ? 'unlock' : 'lock', disabled: ended || pending || scheduled },
            extend: { label: '+1 分钟', icon: 'plus', disabled: ended || pending },
            stop: { label: scheduled ? '取消预约' : '结束', icon: 'stop', disabled: ended || pending }
        };
    }
    // Independent native adaptation of the stacked-label interaction referenced in DESIGN.md.
    // Exact damped spring solution: frame-rate independent and reversible without losing velocity.
    function springStep(position, velocity, target, seconds) {
        const damping = 10, frequency = Math.sqrt(75), dt = Math.max(0, seconds);
        const decay = Math.exp(-damping * dt), c = Math.cos(frequency * dt), s = Math.sin(frequency * dt), x = position - target;
        return { position: target + decay * (x * c + (velocity + damping * x) / frequency * s), velocity: decay * (velocity * c - (damping * velocity + 175 * x) / frequency * s) };
    }
    function nodeList(container) {
        const rows = new Map(), doc = container.ownerDocument, view = doc.defaultView;
        const reduced = view.matchMedia('(prefers-reduced-motion: reduce)');
        let raf = 0, previous = 0, disposed = false;
        function paint(row) {
            row.tags[0].style.transform = 'translateX(' + row.overlap[0] * (1 - row.position) + 'px)';
            row.tags[1].style.transform = 'translateX(' + row.overlap[1] * (1 - row.position) + 'px)';
            for (const tag of row.tags.slice(0, 2)) tag.style.setProperty('--tag-open', String(Math.max(0, Math.min(1, row.position))));
        }
        function measure(row) {
            const widths = row.tags.map(t => t.getBoundingClientRect().width);
            row.overlap = [Math.max(0, widths[1] + widths[2] + 10 - 24), Math.max(0, widths[2] + 5 - 12)];
            paint(row);
        }
        function snap() {
            if (raf) view.cancelAnimationFrame(raf); raf = 0; previous = 0;
            for (const row of rows.values()) { row.position = row.target; row.velocity = 0; paint(row); }
        }
        function frame(now) {
            raf = 0;
            const dt = previous ? (now - previous) / 1000 : 1 / 60; previous = now;
            let moving = false;
            for (const row of rows.values()) {
                if (row.position === row.target && !row.velocity) continue;
                const next = springStep(row.position, row.velocity, row.target, dt);
                row.position = next.position; row.velocity = next.velocity;
                if (Math.abs(row.position - row.target) < .001 && Math.abs(row.velocity) < .01) { row.position = row.target; row.velocity = 0; }
                else moving = true;
                paint(row);
            }
            if (moving) raf = view.requestAnimationFrame(frame); else previous = 0;
        }
        function target(button, hovered, focused) {
            const row = rows.get(button); if (!row) return;
            if (hovered !== undefined) row.hovered = hovered;
            if (focused !== undefined) row.focused = focused;
            row.target = row.hovered || row.focused ? 1 : 0;
            if (reduced.matches || doc.hidden) snap();
            else if (!raf) raf = view.requestAnimationFrame(frame);
        }
        function find(event) { return event.target.closest?.('.node'); }
        const over = e => { if (e.pointerType !== 'touch') target(find(e), true); };
        const out = e => { const b = find(e); if (b && !b.contains(e.relatedTarget)) target(b, false); };
        const focus = e => target(find(e), undefined, true);
        const blur = e => { const b = find(e); if (b && !b.contains(e.relatedTarget)) target(b, undefined, false); };
        const keys = e => {
            if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) return;
            const buttons = [...rows.keys()].filter(b => !b.disabled), index = buttons.indexOf(find(e)); if (index < 0) return;
            e.preventDefault();
            buttons[e.key === 'Home' ? 0 : e.key === 'End' ? buttons.length - 1 : Math.max(0, Math.min(buttons.length - 1, index + (e.key === 'ArrowDown' ? 1 : -1)))].focus();
        };
        const listeners = { pointerover: over, pointerout: out, focusin: focus, focusout: blur, keydown: keys };
        for (const [type, fn] of Object.entries(listeners)) container.addEventListener(type, fn);
        const resize = new view.ResizeObserver(() => { for (const row of rows.values()) measure(row); }); resize.observe(container);
        const visibility = () => { if (doc.hidden) snap(); };
        doc.addEventListener('visibilitychange', visibility); reduced.addEventListener('change', snap);
        doc.fonts?.ready.then(() => { if (!disposed) for (const row of rows.values()) measure(row); });
        function clear() { snap(); rows.clear(); }
        return {
            clear,
            create(button, name, index) {
                const heading = doc.createElement('span'); heading.className = 'ui-node-heading';
                const number = doc.createElement('span'); number.className = 'ui-node-number'; number.textContent = String(index + 1).padStart(2, '0');
                const label = doc.createElement('span'); label.className = 'ui-node-name'; label.textContent = name; heading.append(number, label);
                const meta = doc.createElement('span'); meta.className = 'ui-node-meta'; meta.setAttribute('aria-hidden', 'true');
                const tags = ['clock', 'list', null].map(glyph => { const tag = doc.createElement('span'); tag.className = 'ui-node-tag'; if (glyph) tag.append(icon(glyph)); const value = doc.createElement('span'); tag.append(value); meta.append(tag); return tag; });
                button.append(heading, meta);
                rows.set(button, { name, tags, values: tags.map(t => t.lastChild), position: 0, velocity: 0, target: 0, hovered: false, focused: false, overlap: [0, 0] });
            },
            update(button, duration, count, state) {
                const row = rows.get(button); if (!row) return;
                const values = [duration, count + ' 条', state], label = row.name + '，时长 ' + duration + '，消息 ' + count + ' 条，' + state;
                button.setAttribute('aria-label', label); button.title = label;
                let changed = false;
                values.forEach((v, i) => { if (row.values[i].textContent !== v) { row.values[i].textContent = v; changed = true; } });
                if (changed) measure(row);
            },
            destroy() { disposed = true; clear(); resize.disconnect(); for (const [type, fn] of Object.entries(listeners)) container.removeEventListener(type, fn); doc.removeEventListener('visibilitychange', visibility); reduced.removeEventListener('change', snap); }
        };
    }
    const api = { styles, icon, labelButton, formatTime, timing, controls, springStep, nodeList };
    root.RecruitUI = api;
    if (typeof module !== 'undefined') module.exports = api;
})(globalThis);

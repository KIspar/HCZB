'use strict';
const $ = id => document.getElementById(id), C = RecruitCore, T = RecruitTasks, S = RecruitStore, U = RecruitUI;
let draft = false, operationPending = '', currentProject = null, projectItems = [];
let selected = null, lastFeed = '', refreshing = false, generationActive = null, controlPending = '', startPending = false, clockState = null;
const uiStyle = document.createElement('style'); uiStyle.textContent = U.styles; document.head.append(uiStyle);
for (const [id, icon, label] of [['saveKey', 'save', '保存'], ['continueGeneration', 'refresh', '继续生成'], ['cancelGeneration', 'stop', '停止生成'], ['exportProject', 'download', '导出任务 JSON'], ['importTask', 'upload', '导入任务 JSON'], ['workbookLabel', 'upload', '选择招聘 Excel'], ['backLink', 'arrowLeft', '返回扩展配置']]) U.labelButton($(id), icon, label);
$('scheduleIcon').append(U.icon('clock'));
const nodeUI = U.nodeList($('nodes'));
window.addEventListener('pagehide', event => { if (!event.persisted) nodeUI.destroy(); });
const labels = { pending: '等待启动', ready: '就绪', generating: '生成中', error: '生成失败', cancelled: '已停止', running: '执行中', paused: '已暂停', scheduled: '已预约', waiting_live: '按计划执行', interrupted: '待继续', completed: '已完成', stopped: '已结束', expired: '已过期' };
async function send(type, value) { const r = await chrome.runtime.sendMessage({ type, value }); if (!r?.ok)
    throw Error(r?.error || '操作失败'); return r.value; }
let toastTimer;
function toast(text) { $('aiToast').textContent = text; $('aiToast').classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('aiToast').classList.remove('visible'), 5000); }
function task(fn) { return async (e) => { e?.preventDefault(); try {
    await fn(e);
}
catch (error) {
    if (e?.target?.type === 'file')
        e.target.value = '';
    toast(error.message);
} }; }
function text(tag, value, className) { const el = document.createElement(tag); el.textContent = value; if (className)
    el.className = className; return el; }
function time(ms) { const s = Math.max(0, Math.floor(ms / 1000)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
function config() { return { minutes: C.number($('minutes').value, 1, 1440, 60), personaCount: Math.round(C.number($('personaCount').value, 10, 500, 300)), mode: $('generationMode').value }; }
const panel = RecruitTaskPanel;
$('pickerChevron').append(U.icon('chevron')); $('keyChevron').append(U.icon('chevron'));
U.labelButton($('newTask'), 'plus', '新建');
U.labelButton($('replaceWorkbook'), 'upload', '重新上传');
const taskPicker = panel.picker($('projects'), id => { selected = id; draft = false; void refresh().catch(e => toast(e.message)); }, labels, U.icon);
function renderTaskPanel(p) {
    currentProject = p;
    const st = panel.state(p, generationActive, operationPending, draft);
    $('taskCard').dataset.state = st.phase; $('taskStage').setAttribute('aria-busy', String(st.busy));
    $('uploadPanel').hidden = st.phase !== 'empty'; $('resultPanel').hidden = st.phase === 'empty';
    $('cancelNew').hidden = !draft || !p; $('newTask').hidden = st.phase === 'empty';
    for (const id of ['workbook', 'taskJson', 'uploadWorkbook', 'minutes', 'personaCount', 'generationMode', 'newTask', 'importTask', 'replaceWorkbook', 'cancelNew']) $(id).disabled = st.busy;
    $('taskStateTitle').textContent = st.phase === 'generating' ? operationPending === 'import' ? '正在导入任务' : '正在生成' : st.phase === 'ready' ? '任务已就绪' : p?.status === 'error' ? '生成失败' : '等待继续';
    const icon = st.busy ? 'spinner' : st.phase === 'ready' ? 'check' : 'refresh';
    if ($('taskStateIcon').dataset.icon !== icon) { $('taskStateIcon').replaceChildren(U.icon(icon)); $('taskStateIcon').dataset.icon = icon; }
    $('taskStateBadge').textContent = st.busy ? '自动保存' : st.phase === 'ready' ? '已存本地' : '进度已保留';
    $('generationProgress').hidden = st.phase !== 'generating';
    $('continueGeneration').hidden = !st.canRetry && !st.canRebuild; $('continueGeneration').disabled = st.busy;
    $('continueGeneration').dataset.rebuild = String(st.canRebuild);
    U.labelButton($('continueGeneration'), 'refresh', st.canRebuild ? '更新人设并重新编排' : p?.status === 'error' ? '重试生成' : '继续生成');
    $('cancelGeneration').hidden = !generationActive; $('cancelGeneration').disabled = !!operationPending;
    $('replaceWorkbook').hidden = st.phase !== 'error'; $('exportProject').disabled = !st.canExport; $('exportProject').hidden = st.phase !== 'ready';
    $('taskDetails').hidden = draft || !p?.personas?.length;
    taskPicker.update(projectItems, selected, st.busy);
}
async function list() {
    projectItems = (await S.listMeta()).sort((a, b) => b.createdAt - a.createdAt);
    if (generationActive && projectItems.some(p => p.id === generationActive)) { selected = generationActive; draft = false; }
    if (!selected || !projectItems.some(p => p.id === selected)) selected = projectItems[0]?.id;
    return selected ? S.get(selected) : null;
}
function renderProject(p) {
    renderTaskPanel(p);
    if (!p) {
        $('projectStatus').textContent = '尚无本地任务'; $('summary').textContent = ''; $('generationProgress').value = 0;
        for (const id of ['warnings', 'personas', 'sources']) $(id).replaceChildren();
        delete $('personas').dataset.version; return;
    }
    const busy = !!generationActive || !!operationPending;
    $('projectStatus').textContent = operationPending ? (operationPending === 'cancel' ? '正在停止，已生成内容会保留…' : '正在处理，请稍候…') : (busy ? p.status === 'generating' && !p.error ? p.progress : '正在启动生成，内容将逐批保存…' : p.error || p.progress) || (p.status === 'ready' ? '已按企业顺序编排，可直接执行或导出。' : '从已保存进度继续，或重新上传资料。');
    const jobs = p.companies?.reduce((n, c) => n + c.jobs.length, 0) || 0;
    const messageTotal = p.nodes?.reduce((sum, n) => sum + (p.batches?.[n.id] || []).filter(m => !['enter', 'leave'].includes(m.kind)).length, 0) || 0;
    $('summary').hidden = busy && !p.companies?.length;
    $('summary').textContent = (p.theme?.kind || '主题识别中') + ' · ' + (p.companies?.length || 0) + ' 家企业 · ' + jobs + ' 个岗位 · ' + (p.personas?.length || 0) + ' 位用户 · ' + Object.keys(p.batches || {}).length + '/' + (p.nodes?.length || 0) + ' 批次 · JSON消息 ' + messageTotal + ' 条';
    $('generationProgress').value = p.status === 'ready' ? 100 : Math.min(95, (p.quickParts?.length || 0) * 10 + (p.personas?.length || 0) / p.config.personaCount * 30 + Object.keys(p.batches || {}).length / (p.nodes?.length || 1) * 40);
    $('warnings').replaceChildren(...(p.warnings || []).map(w => text('p', w)));
    if ($('personas').dataset.version !== String(p.updatedAt)) {
        $('personas').dataset.version = p.updatedAt;
        $('personas').replaceChildren(...(p.personas || []).map(x => text('p', x.nickname + ' · ' + x.age + '岁 · ' + x.education + ' · ' + x.experience + ' · ' + x.tone + ' · ' + x.participation + ' · 表情' + x.emojiPreference + (x.canAnswer ? ' · 资料解答视角' : ''))));
        $('sources').replaceChildren(...(p.companies || []).map(c => text('p', c.name + '：' + c.jobs.map(j => j.title + '（' + j.sources.map(s => s.sheet + '!' + s.row).join('、') + '）').join('；'))));
    }
}
function renderRun(state, p) {
    const r = state.run?.projectId === p?.id ? state.run : null, active = !!r;
    const ended = !r || ['completed', 'stopped', 'expired'].includes(r.status);
    clockState = { run: r, project: p };
    renderControls();
    $('runStatus').textContent = r ? (labels[r.status] || r.status) : '未开始';
    $('runStatus').dataset.status = r?.status || '';
    $('start').disabled = !p?.nodes?.length || p.status !== 'ready' || startPending;
    const nodes = p?.nodes || [], current = active ? nodes[r.index] : null, finished = active && r.status === 'completed';
    $('nodeLabel').textContent = finished ? '本场已完成 · ' + nodes.length + '个企业节点' : current ? current.name + (r.hold ? ' · 已锁定' : '') + (r.waitingContent ? ' · 批次生成中' : '') : '等待启动';
    updateRunClock();
    const totalMessages = nodes.reduce((sum, n) => sum + (p?.batches?.[n.id] || []).filter(m => !['enter', 'leave'].includes(m.kind)).length, 0);
    const sentMessages = Object.values(r?.nodeCounts || {}).reduce((sum, count) => sum + count, 0);
    $('counters').textContent = r ? '已处理 ' + sentMessages + '/' + totalMessages + ' · 成功 ' + r.sent + ' · 失败 ' + r.failed + ' · 跳过 ' + r.skipped + ' · 表情 ' + (r.stickerCount || 0) : '尚无执行记录';
    if (active && current) {
        const currentTotal = (p.batches?.[current.id] || []).filter(m => !['enter', 'leave'].includes(m.kind)).length;
        $('nodeLabel').textContent += ' · 消息 ' + (r.nodeCounts?.[current.id] || 0) + '/' + currentTotal;
    }
    const nodeSig = (p?.id || '') + '|' + JSON.stringify(nodes.map(n => [n.id, n.name, n.duration]));
    if ($('nodes').dataset.version !== nodeSig) {
        $('nodes').dataset.version = nodeSig; nodeUI.clear();
        $('nodes').replaceChildren(...nodes.map((n, i) => {
            const button = text('button', '', 'node');
            button.type = 'button';
            nodeUI.create(button, n.name, i);
            button.onclick = task(() => control('jump', n.id));
            return button;
        }));
    }
    [...$('nodes').children].forEach((button, i) => {
        const n = nodes[i], count = (p.batches[n.id] || []).filter(m => !['enter', 'leave'].includes(m.kind)).length;
        button.disabled = ended || !!controlPending;
        button.classList.toggle('active', active && r.index === i); button.classList.toggle('past', active && i < r.index);
        button.setAttribute('aria-current', active && r.index === i ? 'step' : 'false');
        nodeUI.update(button, time(n.duration * 1000 + (r?.extensions?.[n.id] || 0)), active ? (r.nodeCounts?.[n.id] || 0) + '/' + count : String(count), active && i === r.index ? '当前' : active && i < r.index ? '已过' : p.batches?.[n.id]?.length ? '就绪' : '待生成');
    });
    const feedSig = JSON.stringify(r?.log || []);
    if (feedSig !== lastFeed) {
        lastFeed = feedSig;
        const feed = $('feed'), bottom = feed.scrollHeight - feed.scrollTop - feed.clientHeight < 70;
        feed.replaceChildren(...(r?.log || []).slice(-100).map(m => {
            const item = text('div', '', 'message ' + m.kind), who = (m.kind === 'notice' ? '系统' : m.nickname || '未知昵称') + ' · ' + new Date(m.time).toLocaleTimeString('zh-CN');
            item.append(text('div', who, 'who'));
            const sticker = m.stickerId && C.stickers.find(s => s.id === m.stickerId);
            if (sticker) { const img = document.createElement('img'); img.src = sticker.url; img.alt = sticker.name; img.className = 'platform-sticker'; item.append(img); }
            else item.append(text('div', m.text));
            if (m.error) item.append(text('div', '发送失败 · ' + m.error));
            return item;
        }));
        if (!feed.children.length)
            feed.append(text('p', '启动后查看JSON消息的发送结果。', 'empty'));
        if (bottom)
            feed.scrollTop = feed.scrollHeight;
    }
}
function renderControls() {
    const r = clockState?.run, states = U.controls(r, !!controlPending);
    document.querySelectorAll('[data-action]').forEach(b => {
        const action = b.dataset.action, state = states[action]; b.disabled = state.disabled; b.hidden = !!state.hidden;
        b.setAttribute('aria-busy', String(controlPending === action)); if (action === 'hold') b.setAttribute('aria-pressed', String(!!r?.hold));
        U.labelButton(b, controlPending === action ? 'spinner' : state.icon, state.label);
    });
    $('nodes').querySelectorAll('button').forEach(b => { b.disabled = !!controlPending || !r || ['completed', 'stopped', 'expired'].includes(r.status); });
}
async function control(action, nodeId) {
    if (controlPending) return; controlPending = action; renderControls();
    try { await send('ai.control', { action, nodeId }); await refresh(); }
    finally { controlPending = ''; renderControls(); }
}
function updateRunClock() {
    const r = clockState?.run, p = clockState?.project, now = Date.now(), current = p?.nodes?.[r?.index], finished = r?.status === 'completed';
    const duration = finished ? p.nodes.reduce((sum, n) => sum + n.duration * 1000 + (r.extensions?.[n.id] || 0), 0) : current ? current.duration * 1000 + (r.extensions?.[current.id] || 0) : 0;
    const t = U.timing(r, duration, now), draftTime = new Date($('scheduledAt').value).getTime(), draft = (!r || ['completed', 'stopped', 'expired'].includes(r.status)) && draftTime > now;
    const panel = $('schedulePanel'); panel.hidden = !t.scheduled && !draft;
    panel.classList.toggle('draft', draft);
    if (!panel.hidden) {
        const waiting = t.scheduled && t.remaining === 0;
        $('scheduleLabel').textContent = waiting ? '已到计划时间，正在启动' : draft ? '计划开始倒计时' : '距离计划开始';
        $('countdown').textContent = draft ? U.formatTime(draftTime - now, true) : t.value;
        panel.querySelector('.schedule-badge').textContent = draft ? '待保存' : '已预约';
        $('scheduleDate').textContent = (draft ? '点击预约启动后生效 · ' : '计划开始 · ') + new Date(draft ? draftTime : r.scheduledAt).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
    }
    $('nodeTime').textContent = finished ? time(duration) + ' / ' + time(duration) : t.scheduled ? '等待开始' : t.value;
    $('nodeProgress').value = finished ? 100 : t.percent;
    const future = draftTime > now; U.labelButton($('start'), startPending ? 'spinner' : future ? 'clock' : 'play', startPending ? '保存中…' : future ? '预约启动' : '立即开始');
    $('start').setAttribute('aria-busy', String(startPending));
}
function renderKeyState({ hasKey, expired }) {
    $('keyStatus').textContent = hasKey ? '已配置 API Key' : expired ? 'API Key 已过期' : '未配置';
    if (!$('keySettings').dataset.initialized) { $('keySettings').open = !hasKey; $('keySettings').dataset.initialized = 'true'; }
    $('keyStatus').dataset.status = hasKey ? 'configured' : expired ? 'expired' : 'empty';
    $('apiKey').placeholder = hasKey ? '输入新 Key 可替换' : expired ? '请重新输入 API Key' : '输入 API Key，保存后 24 小时有效';
}
async function refresh() { if (refreshing || clearingData)
    return; refreshing = true; try {
    generationActive = (await send('ai.generationStatus')).active;
    const [p, state, keyState] = await Promise.all([list(), send('ai.snapshot'), send('ai.hasKey')]);
    renderKeyState(keyState);
    renderProject(p);
    renderRun(state, p);
}
finally {
    refreshing = false;
} }
let clearingData = false;
U.labelButton($('clearData'), 'trash', '清除全部本地数据');
U.labelButton($('confirmClear'), 'trash', '清除全部数据');
$('clearData').onclick = () => { $('taskMenu').open = false; $('clearConfirmation').value = ''; $('clearError').textContent = ''; $('confirmClear').disabled = true; $('clearDialog').showModal(); };
$('cancelClear').onclick = () => $('clearDialog').close();
$('clearConfirmation').oninput = () => { $('confirmClear').disabled = clearingData || $('clearConfirmation').value.trim() !== '确认删除'; };
$('clearDialog').addEventListener('cancel', event => { if (clearingData) event.preventDefault(); });
$('clearForm').onsubmit = async event => {
    event.preventDefault(); if (clearingData || $('clearConfirmation').value.trim() !== '确认删除') return;
    clearingData = true; $('confirmClear').disabled = true; $('cancelClear').disabled = true; $('clearConfirmation').disabled = true;
    U.labelButton($('confirmClear'), 'spinner', '正在清除…'); $('clearError').textContent = '';
    try {
        await send('ai.clearData', { confirmation: '确认删除' });
        draft = false; selected = null; lastFeed = ''; generationActive = null;
        $('importStatus').textContent = ''; $('workbook').value = ''; $('taskJson').value = ''; $('roomUrl').value = ''; $('scheduledAt').value = '';
        $('clearDialog').close(); toast('本地数据已清除，API Key 及原有效期已保留');
    } catch (error) { $('clearError').textContent = error.message; }
    finally {
        clearingData = false; $('cancelClear').disabled = false; $('clearConfirmation').disabled = false;
        $('confirmClear').disabled = $('clearConfirmation').value.trim() !== '确认删除';
        U.labelButton($('confirmClear'), 'trash', '清除全部数据');
        void refresh().catch(e => toast(e.message));
    }
};
$('keyForm').onsubmit = task(async () => { await send('ai.saveKey', { key: $('apiKey').value }); $('apiKey').value = ''; const r = await send('ai.hasKey'); renderKeyState(r); toast('API Key 已保存，24 小时内有效'); });
async function assertIdle() {
    if (clearingData) throw Error('正在清除数据');
    const active = (await send('ai.generationStatus')).active;
    if (active) { generationActive = active; throw Error('正在生成，请完成或停止后再上传'); }
}
async function withOperation(kind, fn) {
    if (operationPending || generationActive || clearingData) return;
    operationPending = kind; renderTaskPanel(currentProject);
    try { await assertIdle(); await fn(); }
    finally { operationPending = ''; await refresh(); renderTaskPanel(currentProject); }
}
function showUpload() { if (operationPending || generationActive) return; draft = true; $('importStatus').textContent = ''; renderTaskPanel(currentProject); }
$('newTask').onclick = showUpload; $('replaceWorkbook').onclick = showUpload;
$('cancelNew').onclick = () => { draft = false; renderTaskPanel(currentProject); };
$('uploadWorkbook').onclick = () => { if (!$('workbook').disabled) $('workbook').click(); };
$('importTask').onclick = () => { $('taskMenu').open = false; if (!$('taskJson').disabled) $('taskJson').click(); };
document.addEventListener('pointerdown', e => { if (!$('taskMenu').contains(e.target)) $('taskMenu').open = false; });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('taskMenu').open) { $('taskMenu').open = false; $('taskMenu').querySelector('summary').focus(); } });
$('workbook').onchange = task(async () => {
    const file = $('workbook').files[0]; if (!file) return;
    try { await withOperation('generate', async () => {
        if (file.size > 15 * 1024 * 1024) throw Error('文件超过15 MB');
        if (!(await send('ai.hasKey')).hasKey) { $('keySettings').open = true; throw Error('请先保存方舟 API Key，再选择招聘 Excel'); }
        const p = { id: crypto.randomUUID(), name: file.name, createdAt: Date.now(), updatedAt: Date.now(), config: config(), status: 'pending', buffer: await file.arrayBuffer() };
        await assertIdle(); await S.put(p); selected = p.id; draft = false;
        try { await send('ai.generate', { id: p.id }); generationActive = p.id; }
        catch (error) { p.status = 'error'; p.error = error.message; p.updatedAt = Date.now(); await S.put(p); throw error; }
        toast('已开始分析，生成过程逐批保存');
    }); } finally { $('workbook').value = ''; }
});
$('continueGeneration').onclick = task(async () => {
    const id = selected, rebuildPersonas = $('continueGeneration').dataset.rebuild === 'true';
    await withOperation('generate', async () => { await send('ai.generate', { id, rebuildPersonas }); generationActive = id; toast('已开始编排，将逐批保存'); });
});
$('cancelGeneration').onclick = task(async () => {
    if (operationPending || !generationActive) return;
    operationPending = 'cancel'; renderTaskPanel(currentProject);
    try { await send('ai.cancel'); generationActive = null; }
    finally { operationPending = ''; await refresh(); renderTaskPanel(currentProject); }
});
$('exportProject').onclick = task(async () => {
    $('taskMenu').open = false;
    const p = await S.get(selected);
    if (!p)
        throw Error('请选择任务');
    const blob = new Blob([JSON.stringify(T.exportPackage(p), null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = p.name.replace(/\.[^.]+$/, '') + '-内部任务.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
});
$('startForm').onsubmit = task(async () => {
    if (startPending) return; startPending = true; $('start').disabled = true; updateRunClock();
    try {
        await send('ai.start', { id: selected, mode: 'internal', url: $('roomUrl').value, scheduledAt: $('scheduledAt').value ? new Date($('scheduledAt').value).getTime() : null });
        toast('执行计划已保存'); await refresh();
    } finally { startPending = false; $('start').disabled = !clockState?.project?.nodes?.length || clockState.project.status !== 'ready'; updateRunClock(); }
});
document.querySelectorAll('[data-action]').forEach(b => b.onclick = task(() => control(b.dataset.action)));
$('scheduledAt').addEventListener('input', updateRunClock);
$('taskJson').onchange = task(async () => {
    const file = $('taskJson').files[0]; if (!file) return;
    try { await withOperation('import', async () => {
        $('importStatus').textContent = '正在读取任务文件…';
        if (file.size > 25 * 1024 * 1024) throw Error('任务文件超过25 MB');
        let raw;
        try { raw = JSON.parse((await file.text()).replace(/^\uFEFF/, '')); }
        catch { throw Error('无法解析JSON，请选择编排台导出的完整任务文件'); }
        const p = T.importPackage(raw, crypto.randomUUID(), Date.now());
        await assertIdle(); await S.put(p); selected = p.id; draft = false;
        $('importStatus').textContent = '导入成功 · ' + p.companies.length + '家企业 · ' + p.nodes.length + '个批次';
        toast('任务已导入，填写目标直播间即可执行');
    }); } catch (error) { $('importStatus').textContent = '导入失败：' + error.message; throw error; }
    finally { $('taskJson').value = ''; }
});
void Promise.all([refresh(), send('ai.hasKey').then(r => renderKeyState(r))]).catch(e => toast(e.message));
setInterval(() => void refresh().catch(() => { }), 1500);
setInterval(updateRunClock, 1000);

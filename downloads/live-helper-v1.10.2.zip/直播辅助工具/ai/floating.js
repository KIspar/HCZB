(function () {
    'use strict';
    const U = RecruitUI;
    let run = null, project = null, expanded = false, pending = '', nodeStamp = '', hover = false, closeTimer, refreshing = false;
    const host = document.createElement('div');
    host.id = 'recruitment-ai-progress';
    const shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = U.styles + `
:host{all:initial;position:fixed;right:20px;bottom:22px;z-index:2147483000;font:13px/1.5 "PingFang SC","Microsoft YaHei",system-ui,sans-serif;--ui-bg:#162f29;--ui-fg:#eff8f2;--ui-muted:#b0c9bc;--ui-border:#436153;--ui-secondary:#244337;--ui-hover:#315343;--ui-primary:#c5e7d1;--ui-primary-fg:#163c2b;--ui-primary-hover:#a9d9bb;--ui-ring:#b2dbbe;--ui-danger:#ffb5a8;--ui-danger-hover:#50342c;--ui-amber:#f1d89c;color:var(--ui-fg);color-scheme:dark}
*{box-sizing:border-box}button{font:inherit}button:focus-visible{outline:2px solid var(--ui-ring);outline-offset:-3px}::selection{background:var(--ui-hover);color:var(--ui-fg)}
.shell{display:flex;flex-direction:column-reverse;width:min(296px,calc(100vw - 32px));max-height:calc(100dvh - 32px);border:1px solid var(--ui-border);border-radius:28px;background:var(--ui-bg);overflow:hidden;transition:width 350ms cubic-bezier(.32,.72,0,1),border-radius 350ms cubic-bezier(.32,.72,0,1)}.shell.open{width:min(408px,calc(100vw - 32px));border-radius:20px;transition-duration:500ms;transition-timing-function:cubic-bezier(.34,1.18,.45,1)}
.compact{flex-shrink:0;width:100%;padding:13px 18px 14px;border:0;background:transparent;color:inherit;text-align:left;cursor:pointer}.title{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:600}.name{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.status-dot{width:6px;height:6px;flex:none;border-radius:50%;background:#98d9b1}.shell[data-status="scheduled"] .status-dot,.shell[data-status="waiting_live"] .status-dot{background:var(--ui-amber)}.shell[data-status="paused"] .status-dot,.shell[data-status="interrupted"] .status-dot{background:var(--ui-muted)}.disclosure{display:flex;align-items:center;gap:2px;font-size:10px;font-weight:400;color:var(--ui-muted)}.disclosure .ui-icon{width:14px;height:14px;transform:rotate(180deg);transition:transform 220ms var(--ui-ease)}.open .disclosure .ui-icon{transform:rotate(0)}
.timing{display:flex;align-items:baseline;justify-content:space-between;gap:8px;margin:9px 0 5px}.time-label{font-size:11px;color:var(--ui-muted);display:flex;align-items:center;gap:5px}.time-label .ui-icon{width:13px;height:13px}.clock{font-size:17px;font-weight:600;line-height:1.3;white-space:nowrap}.shell[data-status="scheduled"] .clock,.shell[data-status="waiting_live"] .clock{color:var(--ui-amber)}.meta{font-size:10px;color:var(--ui-muted);max-height:0;opacity:0;margin-bottom:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:max-height 350ms var(--ui-ease),margin-bottom 350ms var(--ui-ease),opacity 120ms}.open .meta{max-height:20px;opacity:1;margin-bottom:9px;transition-duration:500ms,500ms,200ms;transition-delay:0ms,0ms,80ms}.track{height:3px;background:var(--ui-border);border-radius:3px;overflow:hidden}.fill{height:100%;background:var(--ui-primary);transition:width 600ms linear}
.reveal{display:grid;grid-template-rows:0fr;opacity:0;visibility:hidden;min-height:0;transition:grid-template-rows 350ms cubic-bezier(.32,.72,0,1),opacity 150ms ease-out,visibility 350ms}.open .reveal{grid-template-rows:1fr;opacity:1;visibility:visible;transition:grid-template-rows 500ms cubic-bezier(.34,1.18,.45,1),opacity 220ms ease-out 70ms,visibility 0ms}.clip{min-height:0;overflow:hidden}.body{padding:0 14px 10px;max-height:calc(100dvh - 155px);overflow-y:auto;overscroll-behavior:contain}.actions{display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:12px 0;border-top:1px solid var(--ui-border)}.actions .ui-btn{min-height:32px;padding:7px 9px;font-size:11px}.actions .ui-btn[data-action="stop"]{margin-left:auto}.actions .ui-icon{width:14px;height:14px}.section-label{display:flex;justify-content:space-between;color:var(--ui-muted);font-size:10px;margin:2px 0 8px}.nodes{max-height:min(300px,40dvh);overflow:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:var(--ui-border) transparent;display:grid;grid-template-columns:minmax(0,1fr);gap:4px;padding-right:3px;overflow-x:hidden}.node{min-width:0;display:flex;flex-direction:column;gap:5px;width:100%;padding:9px 10px;text-align:left;background:transparent;border:1px solid transparent;border-radius:10px;color:var(--ui-fg);cursor:pointer;transition:background-color 150ms,border-color 150ms}.node:hover:not(:disabled){background:var(--ui-secondary)}.node.active{background:var(--ui-secondary);border-color:var(--ui-border)}.node:disabled{cursor:not-allowed;opacity:.5}.ui-node-name{font-size:11px}.ui-node-meta{margin-top:-2px}.tip{font-size:10px;color:var(--ui-muted);margin:10px 0 0;line-height:1.7}.error{font-size:11px;color:var(--ui-danger);margin:8px 0 0;overflow-wrap:anywhere}.error:empty{display:none}
@media(max-width:480px){:host{right:12px;bottom:12px}.shell,.shell.open{max-width:calc(100vw - 24px)}.nodes{max-height:32dvh}.actions{gap:4px}.actions .ui-btn{min-height:36px;padding:8px}.actions .ui-btn[data-action="stop"]{margin-left:0}}
@media(prefers-reduced-motion:reduce){.shell,.reveal,.meta,.disclosure .ui-icon,.fill,.node{transition:none!important}}
`;
    shadow.append(style);
    function el(tag, className, value) { const e = document.createElement(tag); if (className) e.className = className; if (value !== undefined) e.textContent = value; return e; }
    const shell = el('section', 'shell'); shell.setAttribute('aria-label', '直播进度控制'); shadow.append(shell);
    const compact = el('button', 'compact'); compact.type = 'button'; compact.setAttribute('aria-controls', 'live-progress-details'); shell.append(compact);
    const title = el('div', 'title'), dot = el('span', 'status-dot'), name = el('span', 'name'), disclosure = el('span', 'disclosure'), disclosureText = el('span', '', '展开'); dot.setAttribute('aria-hidden', 'true'); disclosure.append(disclosureText, U.icon('chevron')); title.append(dot, name, disclosure);
    const timing = el('div', 'timing'), timeLabel = el('span', 'time-label'), timeLabelText = el('span'), clock = el('strong', 'clock ui-numeric'); timeLabel.append(U.icon('clock'), timeLabelText); timing.append(timeLabel, clock);
    const meta = el('div', 'meta'), track = el('div', 'track'), fill = el('div', 'fill'); track.setAttribute('role', 'progressbar'); track.setAttribute('aria-label', '当前企业节点进度'); track.setAttribute('aria-valuemin', '0'); track.setAttribute('aria-valuemax', '100'); track.append(fill); compact.append(title, timing, meta, track);
    const reveal = el('div', 'reveal'); reveal.id = 'live-progress-details'; reveal.inert = true;
    const clip = el('div', 'clip'), body = el('div', 'body'), actions = el('div', 'actions'); actions.setAttribute('role', 'group'); actions.setAttribute('aria-label', '场次操作');
    const sectionLabel = el('div', 'section-label'), nodesTitle = el('span', '', '企业节点'), nodeCounter = el('span'); sectionLabel.append(nodesTitle, nodeCounter);
    const nodes = el('div', 'nodes'); nodes.setAttribute('aria-label', '选择企业节点');
    const nodeUI = U.nodeList(nodes);
    const tip = el('p', 'tip', '移出自动收起 · 点击节点切换 · Esc 收起');
    const error = el('p', 'error'); error.setAttribute('role', 'status');
    body.append(actions, sectionLabel, nodes, tip, error); clip.append(body); reveal.append(clip); shell.append(reveal);
    const actionButtons = new Map();
    for (const action of ['pause', 'resume', 'hold', 'extend', 'stop']) {
        const b = el('button', 'ui-btn'); b.type = 'button'; b.dataset.action = action; b.dataset.variant = action === 'resume' ? 'primary' : action === 'stop' ? 'danger' : 'secondary';
        b.onclick = () => void control(action); actions.append(b); actionButtons.set(action, b);
    }
    function setExpanded(value) {
        clearTimeout(closeTimer); expanded = value; shell.classList.toggle('open', value); reveal.inert = !value;
        compact.setAttribute('aria-expanded', String(value)); compact.setAttribute('aria-label', (value ? '收起' : '展开') + '直播进度控制');
        compact.title = value ? '点击或按 Esc 收起' : '悬停或点击展开'; disclosureText.textContent = value ? '收起' : '展开';
        if (!value && reveal.contains(shadow.activeElement)) compact.focus({ preventScroll: true });
    }
    setExpanded(false);
    shell.addEventListener('pointerenter', event => { if (event.pointerType === 'touch') return; hover = true; setExpanded(true); });
    shell.addEventListener('pointerleave', () => { hover = false; closeTimer = setTimeout(() => setExpanded(false), 240); });
    shell.addEventListener('focusin', event => { if (event.target !== compact && event.target.matches(':focus-visible')) setExpanded(true); });
    shell.addEventListener('focusout', () => { setTimeout(() => { if (!shell.contains(shadow.activeElement)) { if (!hover) setExpanded(false); } }, 0); });
    shell.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); setExpanded(false); compact.focus({ preventScroll: true }); } });
    compact.onclick = () => setExpanded(!expanded);
    async function send(type, value) { const r = await chrome.runtime.sendMessage({ type, value }); if (!r?.ok) throw Error(r?.error || '操作失败'); return r.value; }
    function renderActions() {
        const states = U.controls(run, !!pending);
        for (const [action, b] of actionButtons) { const state = states[action]; b.hidden = !!state.hidden; b.disabled = state.disabled; b.setAttribute('aria-busy', String(pending === action)); if (action === 'hold') b.setAttribute('aria-pressed', String(!!run?.hold)); U.labelButton(b, pending === action ? 'spinner' : state.icon, state.label); }
        nodes.querySelectorAll('button').forEach(b => { b.disabled = !run || !!pending || ['completed', 'stopped', 'expired'].includes(run.status); });
    }
    async function control(action, nodeId) {
        if (pending) return; pending = action; renderActions();
        try { await send('ai.control', { action, nodeId }); error.textContent = ''; await refresh(); }
        catch (e) { error.textContent = e.message; }
        finally { pending = ''; renderActions(); }
    }
    function renderClock() {
        if (!run || !project) return;
        const node = project.nodes[run.index], duration = node ? node.duration * 1000 + (run.extensions?.[node.id] || 0) : 0, t = U.timing(run, duration);
        timeLabelText.textContent = t.label; clock.textContent = t.value; fill.style.width = t.percent + '%';
        track.setAttribute('aria-valuenow', String(Math.round(t.percent))); track.setAttribute('aria-valuetext', t.scheduled ? '预约倒计时 ' + t.value : t.value);
    }
    async function refresh() {
        const s = await send('ai.snapshot'); run = s.run; project = s.project;
        if (!run || !project) { host.remove(); return; }
        if (!host.isConnected) (document.body || document.documentElement).append(host);
        shell.dataset.status = run.status;
        const node = project.nodes[run.index]; name.textContent = node?.name || '全部节点已结束'; name.title = node?.name || '';
        const statuses = { running: '执行中', scheduled: '已预约', waiting_live: '已预约', paused: '已暂停', interrupted: '待继续', completed: '已完成', stopped: '已结束', expired: '已过期' };
        meta.textContent = (statuses[run.status] || run.status) + (run.hold ? ' · 已锁定' : '') + (node ? ' · 消息 ' + (run.nodeCounts?.[node.id] || 0) + '/' + (project.messageCounts?.[node.id] || 0) : '') + ' · 成功 ' + run.sent + ' / 失败 ' + run.failed;
        nodeCounter.textContent = Math.min(run.index + 1, project.nodes.length) + ' / ' + project.nodes.length;
        const signature = project.id + '|' + JSON.stringify(project.nodes.map(n => [n.id, n.name, n.duration]));
        if (signature !== nodeStamp) {
            nodeStamp = signature; nodeUI.clear(); nodes.replaceChildren(...project.nodes.map((n, i) => {
                const b = el('button', 'node'); b.type = 'button'; nodeUI.create(b, n.name, i); b.onclick = () => void control('jump', n.id); return b;
            }));
        }
        [...nodes.children].forEach((b, i) => { const n = project.nodes[i]; b.classList.toggle('active', i === run.index); b.setAttribute('aria-current', i === run.index ? 'step' : 'false'); nodeUI.update(b, U.formatTime(n.duration * 1000 + (run.extensions?.[n.id] || 0)), (run.nodeCounts?.[n.id] || 0) + '/' + (project.messageCounts?.[n.id] || 0), i < run.index ? '已过' : i === run.index ? '当前' : project.readyNodes.includes(n.id) ? '就绪' : '待生成'); });
        renderActions(); renderClock();
    }
    const feedback = []; let lastFlush = 0, disposed = false;
    window.addEventListener('message', event => { if (event.source !== window || event.data?.source !== 'polyv-request-scheduler' || event.data.type !== 'aiAudience') return; const text = String(event.data.payload?.text || '').slice(0, 180); if (text) feedback.push(text); if (feedback.length > 30) feedback.shift(); });
    async function cycle() {
        if (refreshing || disposed) return; refreshing = true;
        try { await send('ai.presence', {}); await refresh(); if (feedback.length && Date.now() - lastFlush > 10000) { lastFlush = Date.now(); await send('ai.feedback', { texts: feedback.splice(0, 15) }); } }
        catch (e) { if (/Extension context invalidated|Receiving end does not exist/i.test(e.message)) { disposed = true; nodeUI.destroy(); host.remove(); clearInterval(pollTimer); clearInterval(clockTimer); } }
        finally { refreshing = false; }
    }
    const pollTimer = setInterval(() => void cycle(), 2500), clockTimer = setInterval(renderClock, 1000);
    window.addEventListener('pagehide', event => { if (event.persisted) return; disposed = true; clearInterval(pollTimer); clearInterval(clockTimer); clearTimeout(closeTimer); nodeUI.destroy(); });
    void cycle();
})();

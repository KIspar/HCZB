/* Task panel state and searchable, keyboard-accessible native combobox. */
(function (root) {
    'use strict';
    function state(project, active, pending = '', draft = false) {
        const busy = !!active || !!pending;
        const phase = busy ? 'generating' : draft || !project ? 'empty' : project.status === 'ready' ? 'ready' : 'error';
        return { phase, busy, canRetry: !busy && !!project && phase === 'error',
            canExport: !busy && project?.status === 'ready' && !!project.nodes?.length && project.nodes.every(n => project.batches?.[n.id]?.length > 0),
            canRebuild: !busy && phase === 'ready' && project?.config?.audienceVersion !== 1 };
    }
    function picker(host, onSelect, labels, icon) {
        const doc = host.ownerDocument, trigger = host.querySelector('button'), value = host.querySelector('[data-picker-value]'),
            popup = host.querySelector('[data-picker-popup]'), search = host.querySelector('input'), list = host.querySelector('[role="listbox"]'), count = host.querySelector('[role="status"]');
        let items = [], selected = '', signature = '', filtered = [], index = -1, isOpen = false;
        function close(focus = false) { isOpen = false; popup.hidden = true; trigger.setAttribute('aria-expanded', 'false'); search.removeAttribute('aria-activedescendant'); if (focus) trigger.focus(); }
        function highlight(next) {
            index = filtered.length ? Math.max(0, Math.min(filtered.length - 1, next)) : -1;
            [...list.children].forEach((el, i) => el.classList.toggle('highlighted', i === index));
            if (index >= 0) { search.setAttribute('aria-activedescendant', list.children[index].id); list.children[index].scrollIntoView({ block: 'nearest' }); }
            else search.removeAttribute('aria-activedescendant');
        }
        function render() {
            const query = search.value.trim().toLocaleLowerCase(); filtered = items.filter(p => p.name.toLocaleLowerCase().includes(query));
            list.replaceChildren(...filtered.map((p, i) => {
                const el = doc.createElement('div'); el.id = 'task-option-' + i; el.setAttribute('role', 'option'); el.setAttribute('aria-selected', String(p.id === selected));
                const name = doc.createElement('span'); name.textContent = p.name; name.title = p.name;
                const status = doc.createElement('small'); status.textContent = labels[p.status] || p.status;
                el.append(name, status); if (p.id === selected) el.append(icon('check'));
                el.onpointerdown = e => e.preventDefault(); el.onclick = () => choose(i); return el;
            }));
            count.textContent = filtered.length ? filtered.length + ' 个本地任务' : items.length ? '没有匹配的任务' : '暂无任务，上传 Excel 或导入 JSON';
            highlight(Math.max(0, filtered.findIndex(p => p.id === selected)));
        }
        function choose(i) { if (!filtered[i]) return; const id = filtered[i].id; close(true); onSelect(id); }
        function open() { if (trigger.disabled) return; isOpen = true; popup.hidden = false; trigger.setAttribute('aria-expanded', 'true'); search.value = ''; render(); search.focus(); }
        trigger.onclick = () => isOpen ? close() : open();
        trigger.onkeydown = e => { if (['ArrowDown', 'ArrowUp'].includes(e.key)) { e.preventDefault(); open(); if (e.key === 'ArrowUp') highlight(filtered.length - 1); } };
        search.oninput = render;
        search.onkeydown = e => {
            if (['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', 'Escape'].includes(e.key)) {
                e.preventDefault();
                if (e.key === 'Escape') close(true);
                else if (e.key === 'Enter') choose(index);
                else highlight(e.key === 'Home' ? 0 : e.key === 'End' ? filtered.length - 1 : index + (e.key === 'ArrowDown' ? 1 : -1));
            }
        };
        host.addEventListener('focusout', e => { if (!host.contains(e.relatedTarget)) close(); });
        doc.addEventListener('pointerdown', e => { if (!host.contains(e.target)) close(); });
        doc.addEventListener('keydown', e => { if (isOpen && e.key === 'Escape') { e.preventDefault(); close(true); } });
        return { update(next, id, disabled) {
            const sig = JSON.stringify(next.map(p => [p.id, p.name, p.status]));
            const changed = sig !== signature || selected !== id; items = next; signature = sig; selected = id;
            const p = items.find(x => x.id === selected); value.textContent = p?.name || '选择本地任务'; value.title = p?.name || '';
            trigger.disabled = disabled; if (disabled) close(); else if (isOpen && changed) render();
        }, close };
    }
    const api = { state, picker }; root.RecruitTaskPanel = api;
    if (typeof module !== 'undefined') module.exports = api;
})(globalThis);

/* Shared, side-effect-free recruitment planning and validation. */
(function (root) {
    'use strict';
    const clean = (v, n = 500) => String(v ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, n);
    const norm = v => clean(v, 20000).replace(/\s/g, '').toLowerCase();
    const redact = (v, n = 500) => clean(v, n).replace(/1[3-9]\d{9}/g, '[电话已隐藏]').replace(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi, '[邮箱已隐藏]');
    const number = (v, min, max, fallback) => Number.isFinite(Number(v)) ? Math.min(max, Math.max(min, Number(v))) : fallback;
    // Names and IDs from Polyv's native image picker; messages send IDs, never image HTML.
    const stickers = Object.freeze([
        ['0', '收到', 'shoudao'], ['1', '涨知识', 'zhangzhishi'], ['2', '牛', 'niu'], ['3', '满分', 'manfen'],
        ['4', '划重点', 'huazhongdian'], ['5', '比心', 'bixin'], ['6', '打call', 'dacall'], ['7', '冲冲冲', 'chong'],
        ['8', '谢谢', 'xiexie'], ['9', '难上加难', 'nanshangjianan'], ['10', '柠檬鲸', 'ningmengjing'], ['11', '打工人', 'dagongren'],
        ['12', '我爱工作', 'woaigongzuo'], ['13', '买买买', 'maimaimai'], ['14', '发红包', 'fahongbao'], ['15', '红红火火', 'honghonghuohuo']
    ].map(([id, name, file]) => Object.freeze({ id, name, url: 'https://s2.videocc.net/default-img/img-emotion/v1/' + file + '.png' })));
    const faceEmotions = Object.freeze('呲牙 大笑 害羞 可爱 偷笑 再见 惊讶 哭笑 酷 奸笑 鼓掌 大哭 敲打 吃瓜 让我看看 按脸哭 打哈欠 愤怒 难过 ok 爱心 心碎 加1 正确 错误 满分 笔记 胜利 比心 赞 蛋糕 红包 礼物 奶茶 时钟 晚安 拍手 鲜花'.split(' '));
    const emojiNames = {
        '👀': '让我看看', '👍': '赞', '🙌': '鼓掌', '👏': '鼓掌', '😄': '大笑', '😆': '大笑', '😃': '大笑', '😀': '大笑',
        '😂': '哭笑', '🤣': '哭笑', '😊': '可爱', '🙂': '可爱', '☺': '害羞', '🥰': '比心', '😍': '比心', '😘': '比心',
        '😁': '呲牙', '😎': '酷', '😉': '偷笑', '🤭': '偷笑', '🤔': '让我看看', '😭': '大哭', '😢': '难过', '😮': '惊讶',
        '😲': '惊讶', '😱': '惊讶', '🥱': '打哈欠', '😴': '晚安', '😡': '愤怒', '👋': '再见', '👌': 'ok', '✌': '胜利',
        '✅': '正确', '✔': '正确', '❌': '错误', '💯': '满分', '❤': '爱心', '💕': '比心', '💖': '比心', '💗': '比心',
        '💔': '心碎', '🫶': '比心', '🙏': '比心', '🌹': '鲜花', '🌷': '鲜花', '💐': '鲜花', '🍉': '吃瓜', '🎁': '礼物',
        '🎂': '蛋糕', '🧋': '奶茶', '📝': '笔记', '📒': '笔记', '🎉': '鼓掌', '🎊': '鼓掌', '🔥': '牛'
    };
    function platformText(value) {
        return clean(value, 6000).replace(/[\p{Extended_Pictographic}\p{Regional_Indicator}](?:[\uFE0E\uFE0F\u{1F3FB}-\u{1F3FF}]|\u200D[\p{Extended_Pictographic}\p{Regional_Indicator}])*/gu, glyph => {
            const base = glyph.replace(/[\uFE0E\uFE0F\u{1F3FB}-\u{1F3FF}]/gu, '');
            const name = emojiNames[base] || '鼓掌';
            return '[' + (faceEmotions.includes(name) ? name : '鼓掌') + ']';
        });
    }
    function chunks(sheets, limit = 14000) {
        const out = [];
        for (const sheet of sheets) {
            let rows = [], size = 0;
            const header = sheet.rows.slice(0, 8);
            for (const row of sheet.rows) {
                const len = JSON.stringify(row).length;
                if (len > limit)
                    throw Error(`单行内容过长：${sheet.name} 第 ${row.row} 行`);
                if (rows.length && (size + len > limit || rows.length >= 40)) {
                    out.push({ sheet: sheet.name, header, previous: sheet.rows.filter(r => r.row < rows[0].row).slice(-3), rows });
                    rows = [];
                    size = 0;
                }
                rows.push(row);
                size += len;
            }
            if (rows.length)
                out.push({ sheet: sheet.name, header, previous: sheet.rows.filter(r => r.row < rows[0].row).slice(-3), rows });
        }
        return out;
    }
    function normalizeExtraction(result, chunk) {
        if (!Array.isArray(result.companies))
            throw Error('AI 未返回企业数组');
        if (!Array.isArray(result.accountedRows))
            throw Error('AI 未返回行覆盖记录');
        const covered = new Set(result.accountedRows.map(Number));
        if (chunk.rows.some(r => !covered.has(r.row)))
            throw Error('AI 分析未覆盖本批次全部行');
        const rows = [...chunk.header, ...chunk.previous, ...(chunk.companyContext || []), ...chunk.rows];
        const source = rows.map(r => r.cells.join(' | ')).join('\n');
        const exists = v => !!norm(v) && norm(source).includes(norm(v));
        const resultCompanies = [];
        for (const c of result.companies) {
            const name = clean(c.name, 160);
            if (!exists(name))
                continue;
            const jobs = [];
            for (const j of (c.jobs || [])) {
                const refs = [...new Set((j.rows || []).map(Number))].filter(r => chunk.rows.some(x => x.row === r));
                const title = clean(j.title, 120);
                if (!refs.length)
                    continue;
                const evidence = rows.filter(r => refs.includes(r.row)).map(r => r.cells.join(' | ')).join('\n');
                if (!norm(title) || !norm(evidence).includes(norm(title)))
                    continue;
                const exact = key => { const s = clean(j[key], 5000); return s && norm(evidence).includes(norm(s)) ? s : ''; };
                jobs.push({ title, salary: exact('salary'), education: exact('education'), experience: exact('experience'), requirements: exact('requirements'), location: exact('location'), sources: refs.map(row => ({ sheet: chunk.sheet, row })) });
            }
            if (jobs.length)
                resultCompanies.push({ name, jobs });
        }
        return resultCompanies;
    }
    function mergeCompanies(parts) {
        const companies = [], map = new Map();
        for (const part of parts)
            for (const company of part) {
                const key = norm(company.name);
                if (!map.has(key)) {
                    const c = { id: `c${companies.length + 1}`, name: company.name, jobs: [] };
                    map.set(key, c);
                    companies.push(c);
                }
                const target = map.get(key);
                for (const job of company.jobs) {
                    const duplicate = target.jobs.find(x => norm(x.title) === norm(job.title) && x.sources.some(s => job.sources.some(t => t.sheet === s.sheet && t.row === s.row)));
                    if (!duplicate)
                        target.jobs.push(job);
                }
            }
        return companies;
    }
    // The model identifies table boundaries and semantic column positions. Copying
    // the original cells then avoids omissions from long free-form model output.
    function extractMapped(sheet, layout, minimal = false) {
        if (!Array.isArray(layout.tables)) throw Error('未返回工作表结构');
        const companies = [], byName = new Map(), seen = new Set();
        for (const table of layout.tables) {
            if (!Number.isInteger(table.companyColumn) || !Number.isInteger(table.titleColumn)
                || table.companyColumn < 0 || table.titleColumn < 0
                || table.companyColumn === table.titleColumn
                || !Number.isInteger(table.startRow) || !Number.isInteger(table.endRow))
                throw Error('工作表结构定位无效');
            let currentCompany = '';
            for (const row of sheet.rows.filter(r => r.row >= table.startRow && r.row <= table.endRow)) {
                const companyCell = clean(row.cells[table.companyColumn], 160);
                if (companyCell) currentCompany = companyCell;
                const title = clean(row.cells[table.titleColumn], 120);
                if (!currentCompany || !title || /^(合计|总计|小计|岗位名称|招聘岗位|岗位|职位)$/.test(title)) continue;
                const key = sheet.name + ':' + row.row;
                if (seen.has(key)) continue;
                seen.add(key);
                const companyKey = norm(currentCompany);
                if (!byName.has(companyKey)) {
                    const company = { name: currentCompany, jobs: [] };
                    byName.set(companyKey, company); companies.push(company);
                }
                const cell = field => Number.isInteger(table[field + 'Column']) && table[field + 'Column'] >= 0
                    ? clean(row.cells[table[field + 'Column']], 6000) : '';
                byName.get(companyKey).jobs.push(minimal ? { title, salary: cell('salary'), sources: [{ sheet: sheet.name, row: row.row }] } : { title, salary: cell('salary'), education: cell('education'),
                    experience: cell('experience'), requirements: cell('requirements'), location: cell('location'),
                    sources: [{ sheet: sheet.name, row: row.row }] });
            }
        }
        return companies;
    }
    function plan(companies, minutes) {
        const total = Math.round(number(minutes, 1, 1440, 60) * 60);
        if (!companies.length)
            throw Error('没有可编排的企业');
        const weights = companies.map(c => 1 + Math.sqrt(c.jobs.length));
        const sum = weights.reduce((a, b) => a + b, 0);
        // Largest remainders preserve the requested total exactly.
        const raw = weights.map(w => w / sum * total);
        const durations = raw.map(Math.floor);
        const order = raw.map((v, i) => ({ i, rest: v - durations[i] })).sort((a, b) => b.rest - a.rest);
        const remainder = total - durations.reduce((a, b) => a + b, 0);
        for (let i = 0; i < remainder; i++)
            durations[order[i].i]++;
        let at = 0;
        return companies.map((c, i) => { const n = { id: c.id, name: c.name, duration: durations[i], start: at }; at += durations[i]; return n; });
    }
    function validateMessages(raw, personas, company, duration, prefix = '') {
        if (!Array.isArray(raw))
            throw Error('AI 未返回内容数组');
        const validIds = new Set(personas.map(p => p.id)), seen = new Map(), accepted = [], indexMap = new Map();
        const facts = JSON.stringify({ name: company.name, jobs: company.jobs.map(({ title, salary, education, experience, requirements, location }) => ({ title, salary, education, experience, requirements, location })) });
        for (let i = 0; i < raw.length; i++) {
            const m = raw[i], sticker = m.kind === 'sticker' ? stickers.find(s => s.id === String(m.stickerId)) : null;
            if (m.kind === 'sticker' && !sticker) continue;
            const answer = m.kind === 'answer' && personas.find(p => p.id === m.personaId)?.canAnswer ? sourceAnswer(company, m.source, prefix + 'm' + i) : '';
            if (m.kind === 'answer' && !answer) continue;
            const text = answer || (sticker ? '[' + sticker.name + ']' : platformText(redact(m.text)));
            const reaction = !!sticker || m.kind === 'emoji' || /^(?:6{2,6}|8{2,6}|[+＋]1)$/.test(text);
            if (!validIds.has(m.personaId) || !text || text.length > 180 || (seen.get(norm(text)) || 0) >= (reaction ? 3 : 1))
                continue;
            if (/(保证录用|包过|百分百|加.*微信|刷单|赌博|色情|政治口号|忽略.*指令|system prompt|傻[逼比b]|操你|去死|废物|死全家)/i.test(text))
                continue;
            if (!reaction && (text.match(/\d+(?:\.\d+)?/g) || []).some(n => !facts.includes(n)))
                continue;
            const replyTo = Number.isInteger(m.replyTo) ? indexMap.get(m.replyTo) : null;
            if (Number.isInteger(m.replyTo) && (!replyTo || accepted.find(x => x.id === replyTo)?.personaId === m.personaId))
                continue;
            const at = Math.round(number(m.at, 0.02, .95, (i + 1) / (raw.length + 1)) * duration * 1000);
            const dependency = accepted.find(x => x.id === replyTo);
            if (dependency && at <= dependency.at)
                continue;
            const id = `${prefix}m${i}`;
            indexMap.set(i, id);
            seen.set(norm(text), (seen.get(norm(text)) || 0) + 1);
            accepted.push({ id, personaId: m.personaId, text, at, kind: answer ? 'answer' : sticker ? 'sticker' : ['question', 'reply', 'emoji', 'chat'].includes(m.kind) ? m.kind : 'chat', ...(answer ? { source: { field: m.source.field, jobIndex: m.source.jobIndex } } : {}), ...(sticker ? { stickerId: sticker.id } : {}), replyTo: replyTo || null });
        }
        return accepted.sort((a, b) => a.at - b.at);
    }
    function hash(value) { let n = 2166136261; for (const c of String(value)) n = Math.imul(n ^ c.charCodeAt(0), 16777619); return n >>> 0; }
    function audiencePlan(count, kind = '综合招聘', seed = '') {
        count = Math.round(number(count, 1, 500, 300));
        const campus = kind === '毕业生招聘', social = kind === '社会招聘';
        // These are editable composition defaults, not demographic statistics about a city.
        const education = campus ? [['大专', 45], ['中专', 20], ['职高/技校', 10], ['高中', 5], ['本科', 20]]
            : social ? [['大专', 45], ['中专', 25], ['职高/技校', 10], ['高中', 10], ['本科', 10]]
            : [['大专', 45], ['中专', 20], ['职高/技校', 10], ['高中', 10], ['本科', 15]];
        const identities = campus ? [['应届毕业', 45], ['在校实习', 15], ['在职换岗', 15], ['待业求职', 10], ['转行求职', 10], ['返乡求职', 5]]
            : social ? [['在职换岗', 40], ['待业求职', 30], ['转行求职', 15], ['返乡求职', 10], ['应届毕业', 5]]
            : [['在职换岗', 35], ['待业求职', 25], ['转行求职', 15], ['返乡求职', 10], ['应届毕业', 10], ['在校实习', 5]];
        function allocate(weights, total, salt) {
            const sum = weights.reduce((n, [, w]) => n + w, 0);
            const buckets = weights.map(([value, weight], i) => ({ value, n: Math.floor(total * weight / sum), remainder: total * weight / sum % 1, i }));
            let remaining = total - buckets.reduce((n, b) => n + b.n, 0);
            for (const b of [...buckets].sort((a, b) => b.remainder - a.remainder || a.i - b.i)) if (remaining-- > 0) b.n++;
            const rows = buckets.flatMap(b => Array(b.n).fill(b.value));
            for (let i = rows.length - 1; i > 0; i--) { const j = hash(seed + ':' + salt + ':' + i) % (i + 1); [rows[i], rows[j]] = [rows[j], rows[i]]; }
            return rows;
        }
        const degrees = allocate(education, count, 'education'), statuses = allocate(identities, count, 'identity');
        const adultCount = statuses.filter(s => !['应届毕业', '在校实习'].includes(s)).length;
        const adultAges = allocate([['22-29', 30], ['30-39', 40], ['40-49', 25], ['50-55', 5]], adultCount, 'age');
        let adult = 0;
        return statuses.map((status, i) => {
            const degree = degrees[i], n = hash(seed + ':person:' + i), graduationAge = degree === '本科' ? 22 : degree === '大专' ? 20 : 18;
            let age, experience;
            if (status === '在校实习') { const min = degree === '本科' ? 20 : degree === '大专' ? 19 : 18, max = degree === '本科' ? 23 : degree === '大专' ? 22 : 20; age = min + n % (max - min + 1); experience = '在校实习'; }
            else if (status === '应届毕业') { const max = degree === '本科' ? 24 : degree === '大专' ? 23 : degree === '高中' ? 20 : 21; age = graduationAge + n % (max - graduationAge + 1); experience = '应届毕业·首次求职'; }
            else {
                const [low, high] = adultAges[adult++].split('-').map(Number), min = Math.max(low, graduationAge + 1);
                age = min + n % (high - min + 1);
                const years = Math.max(1, age - graduationAge - n % 3);
                experience = status + '·工作' + years + '年';
            }
            const tones = ['简短直接', '温和细致', '随和健谈', '谨慎简洁', '轻松有分寸', '慢热少话'];
            return { age, education: degree, experience, tone: tones[n % tones.length] };
        });
    }
    const surnames = '陈 林 李 张 黄 吴 刘 王 周 许 郑 杨 何 罗 谢 梁 宋 叶 苏 潘 方 江 程 曾 余'.split(' ');
    const givenNames = '乐 明 凯 晨 静 宁 辰 睿 秋 俊 帆 斌 涛 亮 萍 燕 华 丽 强 勇 晶 玲 超 雯 晓宇 文静 佳宁 子涵 一帆 文斌 秋月 嘉琪 昕悦 俊杰 嘉言 子轩 宇航 佳欣 晓东 海燕 志强 明辉 文浩 佳怡 晓敏 丽娟 建华 志远 晓彤 泽宇 文慧 志鹏 思琪 明轩 海峰 丽娜 志伟 建明 宇轩 佳乐 永康 惠玲 玉梅 启明 雨桐 宏伟 文龙'.split(' ');
    const everydayNames = '粥粥 山茶 木木 晚风 栗子 不加糖 阿白 柠檬水 海盐 小满 云朵 红豆 沙丁鱼 没带伞 竹子 星星 荷包蛋 阿呆 橘猫 小面包 春天见 泡泡 叶子 一碗面 晴天 白开水 落日 西柚 纸飞机 阿七 发呆中 风好大 老吴 小陈 大林 小周 阿华 阿梅 阿强 老许 明仔 阿雄 阿芬 小燕 建哥 老黄 志哥 小郑 老李 东东 大勇 小敏 阿娟 乐乐 石头 豆豆 洋洋 安安 七七 南瓜 土豆 饭团 山竹 花生 书签 春芽 路人甲 小丁 铁蛋 四月 北北 大海 嘟嘟 小贝 阿荣 阿康'.split(' ');
    const phraseNames = '今天早点睡 下班去散步 没想好名字 吃个橙子 听听就好 微辣就好 去吹吹风 可乐去冰 不要香菜 饭要趁热 认真干饭 河边走走 想喝椰汁 一点点慢慢来 懒得起名 想吃烧烤 走走停停 普通周二 明天再说 等饭中 先歇一下 电量不足 有空再聊 路过一下 想回家 今天有点困 刚下班 随便看看 拿杯水先 忘了带钥匙 还没吃饭 一会就走 先不改名 是我没错 慢慢来吧 等公交 再睡五分钟 橙子有点酸 去买个菜 打包带走'.split(' ');
    const englishNames = 'momo June linlin wei Kiki echo Nina Alex May seven Ming Leo zzz anna Rui coco Sam jay ivy Q Qiu sunny Teddy Tim Amy cici Frank xixi 小鱼Yu'.split(' ');
    const singleNames = '宁 乐 安 南 东 秋 雨 明 云 海'.split(' ');
    const fallbackNicknames = [...surnames.flatMap(s => givenNames.map(g => s + g)), ...everydayNames, ...phraseNames, ...englishNames, ...singleNames];
    const nicknameBase = value => norm(value).replace(/[。~._-]/g, '');
    function nicknameShape(value) { return /^[a-z0-9 ._-]+$/i.test(value) ? 'latin' : [...value].length >= 5 ? 'long' : String([...value].length); }
    const nicknameAllowed = value => !!value && [...value].length <= 12 && !/AI|测试|模拟|自动招聘助手|^(求职|招聘|应聘|职场|观众|用户|访客)|[·_-]\d{2,}$|[\r\n<>]/i.test(value);
    function nicknameFits(value, used) {
        if (!nicknameAllowed(value)) return false;
        const base = nicknameBase(value), names = [...used];
        if (names.some(x => nicknameBase(x) === base)) return false;
        if (/^[小阿]/.test(value) && names.filter(x => x[0] === value[0]).length >= 24) return false;
        const shape = nicknameShape(value), limits = { '1': .08, '2': .5, '3': .5, '4': .25, long: .2, latin: .15 };
        if (names.filter(x => nicknameShape(x) === shape).length >= Math.max(2, Math.floor((used.size + 1) * (limits[shape] || .2)))) return false;
        if (base.length >= 2 && names.filter(x => nicknameBase(x).slice(0, 2) === base.slice(0, 2)).length >= 4) return false;
        if (base.length >= 3 && names.filter(x => nicknameBase(x).slice(-2) === base.slice(-2)).length >= 4) return false;
        return true;
    }
    function nicknameText(value) {
        return redact(value, 80)
            .replace(/[#*0-9]\uFE0F?\u20E3|[\p{Extended_Pictographic}\p{Regional_Indicator}](?:[\uFE0E\uFE0F\u{1F3FB}-\u{1F3FF}\u{E0020}-\u{E007F}]|\u200D[\p{Extended_Pictographic}\p{Regional_Indicator}])*/gu, '')
            .replace(/[\u200D\uFE0E\uFE0F\u{1F3FB}-\u{1F3FF}\u{E0020}-\u{E007F}]/gu, '')
            .replace(/\[([^\]]+)\]/g, (code, name) => faceEmotions.includes(name) || stickers.some(s => s.name === name) ? '' : code).trim();
    }
    function naturalNickname(candidate, used, seed) {
        let nickname = nicknameText(candidate);
        for (let i = 0; !nicknameFits(nickname, used); i++) {
            if (i >= 128) {
                const offset = hash(seed) % fallbackNicknames.length;
                nickname = Array.from({ length: fallbackNicknames.length }, (_, j) => fallbackNicknames[(offset + j) % fallbackNicknames.length]).find(value => nicknameFits(value, used));
                if (!nickname) throw Error('无法分配不重复的昵称，请重试生成人设');
                break;
            }
            const n = hash(seed + ':value:' + i), style = (hash(seed + ':style:' + i) >>> 16) % 12;
            if (style < 5) nickname = surnames[n % surnames.length] + givenNames[Math.floor(n / 37) % givenNames.length];
            else if (style < 8) nickname = everydayNames[n % everydayNames.length];
            else if (style < 10) nickname = phraseNames[n % phraseNames.length];
            else if (style === 10) nickname = englishNames[n % englishNames.length];
            else nickname = singleNames[n % singleNames.length];
        }
        used.add(norm(nickname)); return nickname;
    }
    function roomPersonas(personas, seed) {
        // Keep distinct existing names; repair only crowded patterns in larger legacy rosters.
        const maxFour = Math.max(2, Math.floor(personas.length * .25)), stems = new Map(), tails = new Map(), reserved = new Set();
        let four = 0;
        const keep = personas.map(p => {
            const value = nicknameText(p.nickname), base = nicknameBase(value), stem = base.slice(0, 2), tail = base.slice(-2);
            if (!nicknameAllowed(value) || value !== p.nickname || reserved.has(base)) return false;
            if (personas.length >= 20 && (nicknameShape(value) === '4' && four >= maxFour || (stems.get(stem) || 0) >= 4 || base.length >= 3 && (tails.get(tail) || 0) >= 4)) return false;
            reserved.add(base); if (nicknameShape(value) === '4') four++;
            stems.set(stem, (stems.get(stem) || 0) + 1); tails.set(tail, (tails.get(tail) || 0) + 1); return true;
        });
        // Reserve preserved names before replacing any so cleaning emoji cannot steal a name.
        const used = new Set(personas.filter((p, i) => keep[i]).map(p => norm(p.nickname)));
        return personas.map((p, i) => keep[i] ? p : { ...p, nickname: naturalNickname(p.nickname === nicknameText(p.nickname) ? '' : p.nickname, used, seed + ':' + p.id) });
    }
    function isQuestion(text) { return /[?？]|(?:吗|么|什么|多少|怎么|哪[里个些儿]|能否|有没有|是不是|能不能|是否|想问|问一下|请问|求解|何时|为啥)/.test(String(text)); }
    function sourceAnswer(company, source, variant = 0) {
        if (!company?.jobs || !source || !['salary', 'title'].includes(source.field) || !Number.isInteger(source.jobIndex)) return '';
        const job = company.jobs[source.jobIndex]; if (!job) return '';
        const index = hash(String(variant) + ':' + company.id + ':' + source.field) % 4;
        if (source.field === 'salary') {
            if (!job.salary) return ['这个工资还不清楚', job.title + '工资我也不清楚', '工资这块得问一下企业', '这个岗多少钱还不确定'][index];
            // Salary may be a range, negotiable or a piece rate: keep its text and units verbatim.
            return [job.title + '是' + job.salary, job.title + '，' + job.salary, job.title + '这岗是' + job.salary, job.title + '工资' + job.salary][index];
        }
        const titles = company.jobs.slice(0, 3).map(j => j.title).join('、');
        return ['有' + titles + (company.jobs.length > 3 ? '这些，还有别的岗' : '这几个岗'), '这家招' + titles + (company.jobs.length > 3 ? '这些' : ''), titles + (company.jobs.length > 3 ? '都有招，还有其他的' : '都有招'), '在招' + titles + (company.jobs.length > 3 ? '这些岗' : '')][index];
    }
    function roomEvent(event, company) {
        let text = clean(event.text, 6000);
        // Upgrade legacy boilerplate once; keep IDs, timing and reply links intact.
        if (event.kind === 'answer' && /(?:我看)?(?:表里|表上|资料上|资料里)|薪资原文|(?:具体|详细|安排).{0,12}(?:为准|企业介绍|企业说明)|以企业.{0,8}为准/.test(text)) {
            text = sourceAnswer(company, event.source, event.id) || text;
        }
        text = text.replace(/表上薪资怎么写的呀[？?]?/g, '薪资是多少呀？')
            .replace(/^(?:我看)?(?:表里|表上|资料上|资料里)列了/, '这家在招')
            .replace(/^(?:我看)?(?:表里|表上这份岗位信息里|资料上|资料里)(?=.+(?:薪资|岗位))/, '')
            .replace(/的薪资写的是/g, '的薪资是');
        const sticker = event.kind === 'sticker' && stickers.find(s => s.id === String(event.stickerId));
        return { ...event, text: sticker ? '[' + sticker.name + ']' : platformText(text), ...(sticker ? { stickerId: sticker.id } : {}) };
    }
    const casualLines = '我先听一会儿|刚进来|边吃饭边看|声音听得清|慢慢看不着急|我也是|今天人还挺多|先收藏一下|哈哈哈哈|等下回来|这场信息挺多|朋友也在看|我刚忙完|认真听着呢|路过看看|这个岗位我记一下|一起加油呀|先不聊了听介绍|嗯嗯|记下来了|刚好赶上|我回来啦|继续听|这会儿不忙|下班路上看一会儿|我也来凑个热闹|今天风好大|在呢在呢|已经拿本子了|还好没有错过'.split('|');
    function conversation(spec, personas, company, duration, prefix, questionBudget = 2, seed = '') {
        const n = hash(seed), total = Math.min(24, Math.max(10, Math.round(duration / 4)));
        const ordinary = (Array.isArray(spec.messages) ? spec.messages : []).slice(0, 30).map(m => {
            if (!m || !personas.some(p => p.id === m.personaId)) return {};
            const t = clean(m.text);
            // Questions and factual answers have a separate, source-bound path.
            if (['question', 'answer'].includes(m.kind) || isQuestion(t) || /表里|表上|资料上|资料里|Excel|文档|薪资|工资|待遇|包吃|包住|住宿|食宿|社保|五险|双休|加班|补贴|学历|经验要求|录用|入职|我司|我们公司|内部员工|保底|面试|工作地点|地址|招聘人数|年龄限制|招聘要求|试用期|小时|元|薪/i.test(t)) return {};
            return { ...m, kind: ['chat', 'reply', 'emoji', 'sticker'].includes(m.kind) ? m.kind : 'chat' };
        });
        for (let i = 0; i < 60 && validateMessages(ordinary, personas, company, duration).length < total - 4; i++) {
            const persona = personas[(n + i * 7) % personas.length];
            const emoji = i % 3 === 0;
            ordinary.push({ personaId: persona.id, kind: emoji ? 'emoji' : 'chat', text: emoji ? ['[让我看看]', '[赞]', '[鼓掌]', '[大笑]', '[满分]', '[鲜花]'][(n + i) % 6] : casualLines[(n + i * 11) % casualLines.length], at: (i + 1) / (total + 4) });
        }
        const desired = Math.min(questionBudget, company.jobs.some(j => j.salary) && company.jobs.length > 1 ? 2 : 1);
        const exchanges = Array.isArray(spec.exchanges) ? spec.exchanges : [], helpers = personas.filter(p => p.canAnswer), usedTopics = new Set();
        for (let i = 0; i < desired; i++) {
            const x = exchanges[i] || {}, asker = personas.find(p => p.id === x.askerId) || personas[(n + i) % personas.length];
            const helper = helpers.find(p => p.id === x.helperId && p.id !== asker.id) || helpers.find(p => p.id !== asker.id);
            const jobIndex = Number.isInteger(x.jobIndex) && company.jobs[x.jobIndex] ? x.jobIndex : 0;
            let topic = x.topic === 'salary' && company.jobs[jobIndex].salary ? 'salary' : 'title';
            if (usedTopics.has(topic)) topic = topic === 'title' && company.jobs[jobIndex].salary ? 'salary' : 'title';
            if (usedTopics.has(topic)) continue;
            usedTopics.add(topic);
            const at = .2 + i * .4, questionIndex = ordinary.length, title = company.jobs[jobIndex].title;
            const text = topic === 'salary' ? title + ['薪资是多少呀？', '这个岗工资多少呀？', '的薪资能再说一下吗？'][n % 3] : ['刚进来，这家有哪些岗位呀？', '这家主要招什么岗位呢？', '这家在招哪些岗位呀？'][n % 3];
            ordinary.push({ personaId: asker.id, kind: 'question', text, at });
            if (helper) ordinary.push({ personaId: helper.id, kind: 'answer', source: { field: topic, jobIndex }, at: at + Math.min(.08, 3 / duration), replyTo: questionIndex });
        }
        return validateMessages(ordinary, personas, company, duration, prefix);
    }
    function lifecycle(messages, personas, duration) {
        const used = new Set(messages.map(m => m.personaId)), events = [...messages];
        for (const p of personas.filter(p => used.has(p.id))) {
            const own = messages.filter(m => m.personaId === p.id);
            events.push({ id: own[0].id + '-' + p.id + '-enter', personaId: p.id, kind: 'enter', at: Math.max(0, own[0].at - 1500), text: '进入本地演练' });
            if (p.participation === '间歇' && own.length >= 2) {
                let gap = 0, boundary = 0;
                for (let i = 1; i < own.length; i++)
                    if (own[i].at - own[i - 1].at > gap) {
                        gap = own[i].at - own[i - 1].at;
                        boundary = i;
                    }
                if (gap > 10000) {
                    events.push({ id: own[0].id + '-' + p.id + '-break', personaId: p.id, kind: 'leave', at: own[boundary - 1].at + 2000, text: '暂时离开本地演练' });
                    events.push({ id: own[0].id + '-' + p.id + '-return', personaId: p.id, kind: 'enter', at: own[boundary].at - 2000, text: '返回本地演练' });
                }
            }
            if (p.participation !== '全程')
                events.push({ id: own[0].id + '-' + p.id + '-leave', personaId: p.id, kind: 'leave', at: Math.min(duration * 1000 - 1, own.at(-1).at + 1500), text: '离开本地演练' });
        }
        return events.sort((a, b) => a.at - b.at);
    }
    // Silent viewers also have a local lifecycle. No attendance event is public.
    function attendance(project) {
        const batches = structuredClone(project.batches), nodes = project.nodes;
        if (!nodes.length) return batches;
        const entered = new Set(Object.values(batches).flat().filter(e => e.kind === 'enter').map(e => e.personaId));
        project.personas.forEach((p, i) => {
            if (entered.has(p.id) && p.participation !== '全程') return;
            const node = nodes[p.participation === '全程' ? 0 : i % nodes.length];
            if (!batches[node.id]) return;
            const enterId = 'attendance-' + p.id + '-enter';
            if (!batches[node.id].some(e => e.id === enterId)) batches[node.id].push({ id: enterId, personaId: p.id, kind: 'enter', at: 0, text: '进入本地演练（静默观看）' });
            if (p.participation !== '全程') batches[node.id].push({ id: 'attendance-' + p.id + '-leave', personaId: p.id, kind: 'leave', at: node.duration * 1000 - 1, text: '离开本地演练' });
        });
        const last = nodes.at(-1);
        if (batches[last.id]) for (const p of project.personas.filter(p => p.participation === '全程')) {
            const id = 'attendance-' + p.id + '-end';
            if (!batches[last.id].some(e => e.id === id)) batches[last.id].push({ id, personaId: p.id, kind: 'leave', at: last.duration * 1000 - 1, text: '本场观看结束' });
        }
        for (const events of Object.values(batches)) events.sort((a, b) => a.at - b.at);
        return batches;
    }
    function finalizeLocal(project) {
        project.personas = roomPersonas(project.personas, project.id);
        const names = new Set();
        for (const p of project.personas) {
            const base = clean(p.nickname, 40) || '访客'; let nickname = base, n = 1;
            while (names.has(nickname)) nickname = base.slice(0, 24) + '·' + p.id.replace(/^p/, '') + (n++ > 1 ? '-' + n : '');
            p.nickname = nickname; names.add(nickname);
        }
        if (project.config.mode === 'full') for (const [i, node] of project.nodes.entries()) {
            if (!project.batches[node.id]?.length) continue;
            const messages = project.batches[node.id].filter(e => !['enter', 'leave'].includes(e.kind));
            if (messages.length && !messages.some(e => e.kind === 'sticker')) {
                const sticker = stickers[i % stickers.length], speaker = messages.find(e => project.personas.find(p => p.id === e.personaId)?.emojiPreference === '常用') || messages[0];
                messages.push({ id: node.id + '-platform-sticker', personaId: speaker.personaId, kind: 'sticker', stickerId: sticker.id, text: '[' + sticker.name + ']', at: Math.min(node.duration * 1000 - 2000, speaker.at + 1000), replyTo: null });
            }
            messages.sort((a, b) => a.at - b.at);
            project.batches[node.id] = lifecycle(messages, project.personas, node.duration);
        }
        project.batches = attendance(project);
        return project;
    }
    function elapsed(run, now) { return run.offset + (run.status === 'running' && !run.hold ? Math.max(0, now - run.anchor) * (run.mode === 'rehearsal' ? (run.speed || 1) : 1) : 0); }
    function skipNode(run, project, node) {
        run.seen ||= {};
        run.nodeCounts ||= {};
        for (const event of project.batches[node.id] || []) {
            if (['enter', 'leave'].includes(event.kind) || run.seen[event.id]) continue;
            if (event.epoch !== undefined && (event.epoch !== run.epoch || event.runId !== run.id)) continue;
            run.seen[event.id] = 'skipped';
            run.skipped = (run.skipped || 0) + 1;
            run.nodeCounts[node.id] = (run.nodeCounts[node.id] || 0) + 1;
        }
    }
    function transition(run, project, action, value, now) {
        const next = structuredClone(run), nodes = project.nodes;
        if (!['jump', 'pause', 'resume', 'hold', 'extend', 'stop'].includes(action))
            throw Error('未知控制操作');
        if (['completed', 'stopped', 'expired'].includes(run.status) && action !== 'stop')
            throw Error('本场已结束，请重新启动计划');
        if (action === 'jump') {
            const index = nodes.findIndex(n => n.id === value);
            if (index < 0)
                throw Error('节点不存在');
            for (let i = next.index; i < index; i++) skipNode(next, project, nodes[i]);
            next.index = index;
            next.offset = 0;
            next.anchor = now;
            next.epoch++;
            // Keep handled message IDs when revisiting a node to avoid duplicates.
            next.presence = {};
            next.hold = false;
        }
        else if (action === 'pause') {
            next.offset = elapsed(next, now);
            next.status = 'paused';
            next.epoch++;
        }
        else if (action === 'resume') {
            if (!['paused', 'interrupted'].includes(next.status))
                throw Error('当前状态不能继续');
            next.anchor = now;
            next.status = 'running';
            next.epoch++;
        }
        else if (action === 'hold') {
            next.offset = elapsed(next, now);
            next.anchor = now;
            next.hold = !next.hold;
            next.epoch++;
        }
        else if (action === 'extend') {
            if (!nodes[next.index])
                throw Error('没有当前节点');
            next.extensions[nodes[next.index].id] = (next.extensions[nodes[next.index].id] || 0) + 60000;
            next.epoch++;
        }
        else if (action === 'stop') {
            next.status = 'stopped';
            next.epoch++;
        }
        return next;
    }
    function due(run, project, now) {
        const node = project.nodes[run.index];
        if (run.status !== 'running' || !node || run.hold)
            return [];
        const t = elapsed(run, now);
        return (project.batches[node.id] || []).filter(e => (e.epoch === undefined || (e.epoch === run.epoch && e.runId === run.id)) && !run.seen[e.id] && e.at <= t).map(e => ({ ...e, missed: t - e.at > 12000 * (run.mode === 'rehearsal' ? (run.speed || 1) : 1) }));
    }
    const api = { clean, norm, redact, number, stickers, faceEmotions, platformText, roomEvent, chunks, normalizeExtraction, mergeCompanies, extractMapped, plan, validateMessages, hash, audiencePlan, nicknameText, naturalNickname, roomPersonas, isQuestion, sourceAnswer, conversation, lifecycle, attendance, finalizeLocal, elapsed, skipNode, transition, due };
    if (typeof module !== 'undefined')
        module.exports = api;
    root.RecruitCore = api;
})(globalThis);

/* Loaded by the service worker. AI messages are isolated from legacy schedules. */
(function () {
    'use strict';
    const C = RecruitCore, T = RecruitTasks, S = RecruitStore, alarm = 'recruitment-ai-tick';
    let tickPending = false;
    let queue = Promise.resolve(), stateQueue = Promise.resolve(), creating = null, session = crypto.randomUUID();
    const locked = fn => { const p = stateQueue.then(fn, fn); stateQueue = p.catch(() => { }); return p; };
    const tickOnce = () => { if (tickPending)
        return Promise.resolve(); tickPending = true; return serial(tick).finally(() => { tickPending = false; }); };
    const serial = fn => { const result = queue.then(fn, fn); queue = result.catch(() => { }); return result; };
    const extSender = sender => sender.id === chrome.runtime.id && String(sender.url || '').startsWith(chrome.runtime.getURL('')) && !sender.url.endsWith('/ai/offscreen.html');
    const liveSender = sender => sender.id === chrome.runtime.id && sender.tab && /^https:\/\/[a-z0-9.-]+\.live\.plvideo\.net\/watch\//i.test(sender.url || '');
    let keyQueue = Promise.resolve();
    const keyTask = fn => { const result = keyQueue.then(fn, fn); keyQueue = result.catch(() => {}); return result; };
    const keyLifetime = 24 * 60 * 60 * 1000;
    const loadKey = () => keyTask(async () => {
        const stored = await chrome.storage.local.get(['aiKey', 'aiKeyExpiresAt', 'aiKeyExpired']);
        const expiresAt = Number(stored.aiKeyExpiresAt);
        if (stored.aiKey && Number.isFinite(expiresAt) && expiresAt > Date.now())
            return { key: stored.aiKey, hasKey: true, expired: false, expiresAt };
        const legacy = (await chrome.storage.session.get('aiKey')).aiKey;
        const expired = !!(stored.aiKey || legacy || stored.aiKeyExpired);
        if (stored.aiKey || legacy) {
            await chrome.storage.local.remove(['aiKey', 'aiKeyExpiresAt']);
            await chrome.storage.session.remove('aiKey');
            await chrome.storage.local.set({ aiKeyExpired: true });
        }
        return { key: '', hasKey: false, expired, expiresAt: null };
    });
    let clearing = false;
    const activeOperations = new Set();
    async function clearData() {
        if (clearing) throw Error('正在清除本地数据');
        clearing = true;
        const pending = [...activeOperations];
        try {
            const stopped = await locked(async () => {
                const r = await read();
                if (!r) return null;
                r.status = 'stopped'; r.epoch++; await chrome.storage.local.set({ aiRun: r }); return r;
            });
            if (stopped) await invalidate(stopped);
            const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [chrome.runtime.getURL('ai/offscreen.html')] });
            if (contexts.length) await chrome.offscreen.closeDocument();
            await Promise.allSettled(pending);
            // An operation already in progress may have recreated the offscreen document.
            const remainingContexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [chrome.runtime.getURL('ai/offscreen.html')] });
            if (remainingContexts.length) await chrome.offscreen.closeDocument();
            await serial(() => enqueue(async () => {
                await chrome.alarms.clearAll();
                await chrome.storage.local.set({ settings: { schedules: [], chat: { enabled: false, schedules: [] } }, excelChatTasks: [] });
                await Promise.allSettled([...activeViewerRequests]);
                await S.clear();
                await keyTask(async () => {
                    const all = await chrome.storage.local.get(null);
                    const keep = new Set(['aiKey', 'aiKeyExpiresAt', 'aiKeyExpired']);
                    await chrome.storage.local.remove(Object.keys(all).filter(k => !keep.has(k)));
                    await chrome.storage.session.clear();
                });
                await chrome.alarms.clearAll();
            }));
            return { cleared: true };
        } finally { clearing = false; }
    }
    const roomURL = v => { try {
        const u = new URL(v);
        return /^https:$/.test(u.protocol) && /^[a-z0-9.-]+\.live\.plvideo\.net$/.test(u.hostname) && /^\/watch\/[^/]+/.test(u.pathname) ? u.origin + u.pathname.replace(/\/$/, '') : null;
    }
    catch {
        return null;
    } };
    async function ensureOffscreen() {
        if (creating)
            return creating;
        creating = (async () => { const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [chrome.runtime.getURL('ai/offscreen.html')] }); if (!contexts.length)
            await chrome.offscreen.createDocument({ url: 'ai/offscreen.html', reasons: ['WORKERS'], justification: '在独立Worker中解析Excel并分批生成，关闭设置页后继续保存任务' }); })();
        try {
            await creating;
        }
        finally {
            creating = null;
        }
    }
    async function workerStatus() { await ensureOffscreen(); return (await chrome.runtime.sendMessage({ target: 'recruitment-offscreen', type: 'ai.offscreenStatus' }))?.value?.active; }
    async function generate(id, refill, rebuildPersonas = false) {
        if (rebuildPersonas) { const r = await read(); if (r?.projectId === id && !['stopped', 'completed', 'expired'].includes(r.status)) throw Error('请先结束当前场次，再更新人设'); }
        if (await workerStatus())
            throw Error('已有生成任务在运行，请稍后或停止当前生成');
        const credential = await loadKey();
        if (!credential.hasKey)
            throw Error(credential.expired ? 'API Key 已过期，请重新输入并保存' : '请先保存方舟 API Key');
        const p = await S.get(id);
        if (!p)
            throw Error('任务不存在');
        const response = await chrome.runtime.sendMessage({ target: 'recruitment-offscreen', type: 'ai.generateWorker', value: { id, key: credential.key, keyExpiresAt: credential.expiresAt, refill, rebuildPersonas } });
        if (!response?.ok)
            throw Error(response?.error || '启动生成失败');
        return { id };
    }
    async function read() { return (await chrome.storage.local.get('aiRun')).aiRun || null; }
    async function write(run, force = false) { return locked(async () => { const latest = await read(); const expected = run.baseEpoch ?? run.epoch; if (!force && latest && (latest.id !== run.id || latest.epoch !== expected))
        return false; delete run.baseEpoch; await chrome.storage.local.set({ aiRun: run }); return true; }); }
    async function invalidate(run) {
        const latest = await read();
        if (!latest || latest.id !== run?.id || latest.epoch !== run?.epoch)
            return;
        if (run?.tabId)
            try {
                await chrome.tabs.sendMessage(run.tabId, { type: 'ai.guard', value: { epoch: run.epoch } });
            }
            catch { }
    }
    async function snapshot() {
        const run = await read();
        if (!run || !['public', 'internal'].includes(run.mode))
            return { run: null };
        const p = await S.get(run.projectId);
        if (!p)
            return { run: null };
        const messageCounts = Object.fromEntries(p.nodes.map(n => [n.id, (p.batches?.[n.id] || []).filter(m => !['enter', 'leave'].includes(m.kind)).length]));
        return { run: { ...run, log: run.log.slice(-100), seen: undefined }, project: { id: p.id, name: p.name, theme: p.theme, nodes: p.nodes, messageCounts, readyNodes: Object.keys(p.batches || {}), warnings: p.warnings || [] }, elapsed: C.elapsed(run, Date.now()) };
    }
    async function start(value) {
        const p = await S.get(value.id);
        if (!p?.nodes?.length || !p.personas?.length)
            throw Error('请先完成资料分析和人设生成');
        let upgraded = upgradeNicknames(p);
        for (const node of p.nodes) {
            const company = p.companies.find(c => c.id === node.id);
            p.batches[node.id] = (p.batches[node.id] || []).map(event => {
                const next = C.roomEvent(event, company);
                if (next.text !== event.text || next.stickerId !== event.stickerId) upgraded = true;
                return next;
            });
        }
        if (upgraded) { p.updatedAt = Date.now(); await S.put(p); }
        const mode = 'internal', url = roomURL(value.url);
        if (!url) throw Error('请填写有效的保利威直播间地址');
        const legacy = await getState();
        if (legacy.settings.chat.enabled || legacy.excelChatTasks.some(t => t.status === 'pending'))
            throw Error('请先停用旧随机聊天并清空旧Excel待发任务，避免身份和内容混用');
        const speed = 1;
        const scheduledAt = value.scheduledAt ? Number(value.scheduledAt) : Date.now();
        if (!Number.isFinite(scheduledAt))
            throw Error('开播时间无效');
        const tabs = url ? await chrome.tabs.query({ url: 'https://*.live.plvideo.net/*' }) : [];
        const tab = tabs.find(t => roomURL(t.url) === url);
        const old = await read();
        if (old) {
            old.epoch++;
            await invalidate(old);
        }
        const run = { id: crypto.randomUUID(), projectId: p.id, mode, speed, url, waitForLive: false, tabId: tab?.id || null, status: scheduledAt > Date.now() ? 'scheduled' : 'running', scheduledAt, index: 0, offset: 0, anchor: Date.now(), epoch: (old?.epoch || 0) + 1, seen: {}, nodeCounts: {}, presence: {}, extensions: {}, hold: false, log: [], sent: 0, failed: 0, skipped: 0, session, lastTick: Date.now() };
        await write(run, true);
        await invalidate(run);
        await ensureOffscreen();
        await chrome.alarms.create(alarm, { periodInMinutes: 0.5 });
        return snapshot();
    }
    function upgradeNicknames(p) {
        const personas = C.roomPersonas(p.personas, p.id);
        const changed = personas.some((persona, i) => persona.nickname !== p.personas[i].nickname);
        if (changed) p.personas = personas;
        return changed;
    }
    function log(run, event) { run.log.push({ ...event, time: Date.now(), nodeId: event.nodeId || null }); run.log = run.log.slice(-400); }
    async function refill(p, run) {
        if (p.config.mode !== 'adaptive' || p.status === 'generating')
            return;
        let candidate = p.nodes.slice(run.index, run.index + 3).find(n => !p.batches[n.id]?.length);
        if (await workerStatus())
            return;
        const stored = await chrome.storage.local.get('aiFeedback');
        const feedback = (stored.aiFeedback || []).filter(x => x.url === run.url && Date.now() - x.time < 180000).slice(-30).map(x => x.text);
        let extra = {};
        if (!candidate) {
            const current = p.nodes[run.index], t = C.elapsed(run, Date.now());
            const latest = (stored.aiFeedback || []).filter(x => x.url === run.url && x.time > (run.feedbackAt || 0) && Date.now() - x.time < 90000);
            if (!current || run.hold || latest.length < 2 || Date.now() - (run.lastRefill || 0) < 45000 || current.duration * 1000 - t < 30000)
                return;
            candidate = current;
            extra = { append: true, epoch: run.epoch, runId: run.id, offset: t, startedAt: Date.now() };
            run.feedbackAt = Date.now();
            run.lastRefill = Date.now();
        }
        try {
            await generate(p.id, { nodeId: candidate.id, feedback, ...extra });
        }
        catch (e) {
            if (run.refillError !== e.message) {
                run.refillError = e.message;
                log(run, { kind: 'notice', text: '补充生成：' + e.message });
            }
        }
    }
    async function tick() {
        let run = await read();
        if (!run || !['scheduled', 'waiting_live', 'running'].includes(run.status))
            return;
        const now = Date.now(), p = await S.get(run.projectId);
        if (!p)
            return;
        if (upgradeNicknames(p)) { p.updatedAt = now; await S.put(p); }
        run.baseEpoch = run.epoch;
        // Browser restarts and long suspension never replay a backlog.
        if (run.session !== session || now - run.lastTick > 45000) {
            run.offset = C.elapsed(run, Math.min(now, run.lastTick + 1000));
            run.status = 'interrupted';
            run.epoch++;
            log(run, { kind: 'notice', text: '执行已中断，保留进度；点击继续，不补发离线期间内容' });
            if (await write(run))
                await invalidate(run);
            return;
        }
        run.lastTick = now;
        if (run.status === 'scheduled' && now >= run.scheduledAt) {
            run.status = 'running';
            run.anchor = now;
        }
        // Older saved tasks may still use waiting_live. They follow the same
        // schedule now; the room's video status never blocks chat execution.
        if (run.status === 'waiting_live' && now >= run.scheduledAt) {
            run.waitForLive = false;
            run.status = 'running';
            run.anchor = now;
        }
        if (run.status !== 'running') {
            await write(run);
            return;
        }
        if (run.mode === 'public' || run.mode === 'internal') {
            let presence = (await chrome.storage.local.get('aiPresence')).aiPresence;
            if ((!presence || presence.url !== run.url || now - presence.time > 12000) && run.tabId) {
                // Hidden tabs can throttle their heartbeat timer. An extension
                // message checks the actual page without relying on that timer.
                try {
                    const probe = await chrome.tabs.sendMessage(run.tabId, { type: 'ai.ping' });
                    if (probe?.ok && roomURL(probe.url) === run.url) {
                        presence = { url: run.url, tabId: run.tabId, time: now };
                        await chrome.storage.local.set({ aiPresence: presence });
                    }
                } catch { }
            }
            if (!presence || presence.url !== run.url || now - presence.time > 12000) {
                run.offset = C.elapsed(run, now);
                run.status = 'paused';
                run.epoch++;
                log(run, { kind: 'notice', text: '直播页面连接不可用，已暂停；与开播或结束状态无关' });
                if (await write(run))
                    await invalidate(run);
                return;
            }
        }
        if (run.mode === 'public' || run.mode === 'internal') {
            const presence = (await chrome.storage.local.get('aiPresence')).aiPresence;
            run.tabId = presence.tabId;
        }
        let node = p.nodes[run.index];
        while (node && !run.hold && C.elapsed(run, now) >= node.duration * 1000 + (run.extensions[node.id] || 0)) {
            const remainder = Math.max(0, C.elapsed(run, now) - node.duration * 1000 - (run.extensions[node.id] || 0));
            C.skipNode(run, p, node);
            run.index++;
            run.offset = remainder;
            run.anchor = now;
            run.epoch++;
            node = p.nodes[run.index];
        }
        if (!node) {
            run.status = 'completed';
            log(run, { kind: 'notice', text: '本场全部节点已完成' });
            await write(run);
            return;
        }
        run.waitingContent = !p.batches[node.id]?.length;
        if (!run.hold && now - (run.lastSendAt || 0) >= 2500) {
            const pending = C.due(run, p, now).filter(e => !['enter', 'leave'].includes(e.kind));
            for (const event of pending) if (event.missed || (event.replyTo && ['failed', 'missed', 'skipped'].includes(run.seen[event.replyTo]))) {
                run.seen[event.id] = 'skipped'; run.skipped++;
                run.nodeCounts ||= {}; run.nodeCounts[node.id] = (run.nodeCounts[node.id] || 0) + 1;
            }
            const candidate = pending.find(x => !run.seen[x.id]
                && (!x.replyTo || run.seen[x.replyTo] === 'sent'));
            if (candidate) {
                const event = C.roomEvent(candidate, p.companies.find(c => c.id === node.id));
                const id = event.id, persona = p.personas.find(x => x.id === event.personaId);
                const messageText = event.text;
                const card = messageText || '';
                run.seen[id] = 'attempted';
                run.lastSendAt = now;
                if (!await write(run))
                    return;
                const state = await getState();
                if (state.settings.chat.enabled || state.excelChatTasks.some(t => t.status === 'pending')) {
                    run.offset = C.elapsed(run, Date.now());
                    run.status = 'paused';
                    run.baseEpoch = run.epoch;
                    run.epoch++;
                    log(run, { kind: 'notice', text: '其他聊天计划已启用，当前内部场次已暂停' });
                    if (await write(run))
                        await invalidate(run);
                    return;
                }
                const reason = socketReadiness(state) || (!state.capturedRequest?.protectedParams?.xSessdata ? '缺少观看会话' : null);
                let result = { ok: false, error: reason || '直播间会话不匹配' };
                if (!reason && state.socketRequest?.tabId === run.tabId) {
                    try {
                        if (!persona?.nickname) throw Error('JSON消息缺少对应昵称');
                        await setNickname(state.capturedRequest, state.socketContext.channelId, persona.nickname, 15000);
                        const latest = await read();
                        if (latest.epoch !== run.epoch || latest.id !== run.id || latest.status !== 'running')
                            return;
                        await invalidate(run);
                        result = await chrome.tabs.sendMessage(run.tabId, { type: 'sendChat', value: { url: state.socketRequest.url, nick: persona.nickname, ...(event.stickerId ? { stickerId: event.stickerId } : { message: card }), context: state.socketContext, aiEpoch: run.epoch } });
                    }
                    catch {
                        result = { ok: false, error: '发送失败或ACK超时；未自动重发，避免重复' };
                    }
                }
                run.seen[id] = result?.ok ? 'sent' : 'failed';
                run.nodeCounts ||= {}; run.nodeCounts[node.id] = (run.nodeCounts[node.id] || 0) + 1;
                if (result?.ok) {
                    run.sent++;
                    if (event.stickerId) run.stickerCount = (run.stickerCount || 0) + 1;
                }
                else
                    run.failed++;
                log(run, { kind: result?.ok ? 'sent' : 'failed', text: card, stickerId: event.stickerId, contentKind: event.kind, personaId: event.personaId, nickname: persona?.nickname, nodeId: node.id, error: result?.ok ? '' : C.clean(result?.error, 150) });
            }
        }
        if (!await write(run))
            return;
        await invalidate(run);
        await refill(p, run);
        await write(run);
    }
    async function handle(message, sender) {
        const type = message.type, v = message.value || {};
        if (clearing && !['ai.hasKey', 'ai.saveKey'].includes(type)) throw Error('正在清除本地数据，请稍后');
        if (type === 'ai.workerEvent') {
            if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('ai/offscreen.html'))
                throw Error('来源无效');
            if (v.type === 'crash' && v.id) {
                const p = await S.get(v.id);
                if (p) {
                    p.status = 'error';
                    p.error = v.error;
                    await S.put(p);
                }
            }
            return { stored: true };
        }
        if (type === 'ai.tick') {
            if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('ai/offscreen.html'))
                throw Error('来源无效');
            await tick();
            return {};
        }
        if (type === 'ai.presence' || type === 'ai.feedback') {
            if (!liveSender(sender))
                throw Error('来源无效');
            const url = roomURL(sender.url);
            if (!url)
                throw Error('直播地址无效');
            if (type === 'ai.presence') {
                const active = await read();
                if (active?.url && active.url !== url)
                    return {};
                await chrome.storage.local.set({ aiPresence: { url, tabId: sender.tab.id, time: Date.now(), live: v.live === true } });
                return {};
            }
            const run = await read();
            if (!run || run.url !== url || run.tabId !== sender.tab.id || run.status !== 'running')
                return {};
            const texts = Array.isArray(v.texts) ? v.texts.slice(-15) : [];
            const { aiFeedback = [] } = await chrome.storage.local.get('aiFeedback');
            for (const input of texts) {
                const text = C.redact(input).slice(0, 180);
                if (text && !run.log.some(x => x.kind === 'sent' && x.text?.slice(0, 180) === text) && !aiFeedback.some(x => x.url === url && x.text === text))
                    aiFeedback.push({ url, text, time: Date.now() });
            }
            await chrome.storage.local.set({ aiFeedback: aiFeedback.filter(x => Date.now() - x.time < 600000).slice(-120) });
            return {};
        }
        if (type === 'ai.snapshot') {
            if (!extSender(sender) && !liveSender(sender))
                throw Error('来源无效');
            const s = await snapshot();
            if (liveSender(sender) && s.run?.url !== roomURL(sender.url))
                return { run: null };
            return s;
        }
        if (type === 'ai.control') {
            const next = await locked(async () => { const r = await read(); if (!r)
                throw Error('还没有执行任务'); if (!extSender(sender) && !(liveSender(sender) && r.url === roomURL(sender.url)))
                throw Error('来源无效'); if (!['public', 'internal'].includes(r.mode) && v.action !== 'stop') throw Error('旧场次已停用，请重新启动任务'); const p = await S.get(r.projectId); const n = C.transition(r, p, v.action, v.nodeId, Date.now()); n.lastTick = Date.now(); n.session = session; await chrome.storage.local.set({ aiRun: n }); return n; });
            await invalidate(next);
            await ensureOffscreen();
            return snapshot();
        }
        if (!extSender(sender))
            throw Error('此操作只能在扩展配置页执行');
        if (type === 'ai.clearData') {
            if (v.confirmation !== '确认删除') throw Error('请输入“确认删除”后再清除');
            return clearData();
        }
        if (type === 'ai.saveKey') {
            const key = C.clean(v.key, 300);
            if (!key) throw Error('请输入 API Key');
            await keyTask(async () => { await chrome.storage.local.set({ aiKey: key, aiKeyExpiresAt: Date.now() + keyLifetime, aiKeyExpired: false }); await chrome.storage.session.remove('aiKey'); });
            return { saved: true };
        }
        if (type === 'ai.generationStatus') {
            const active = await workerStatus();
            for (const meta of await (S.listMeta ? S.listMeta() : S.list()))
                if (meta.status === 'generating' && meta.id !== active) {
                    const p = await S.get(meta.id);
                    p.status = 'interrupted';
                    p.progress = '生成已中断，可从保存批次继续';
                    p.updatedAt = Date.now();
                    await S.put(p);
                }
            return { active };
        }
        if (type === 'ai.hasKey') {
            const { hasKey, expired, expiresAt } = await loadKey(); return { hasKey, expired, expiresAt };
        }
        if (type === 'ai.generate')
            return generate(v.id, undefined, v.rebuildPersonas === true);
        if (type === 'ai.cancel') {
            const active = await workerStatus();
            if (active) {
                await chrome.runtime.sendMessage({ target: 'recruitment-offscreen', type: 'ai.cancelWorker' });
                const p = await S.get(active);
                if (p) {
                    p.status = 'cancelled';
                    p.error = '';
                    p.progress = '已停止生成，可从已保存批次继续';
                    await S.put(p);
                }
            }
            return {};
        }
        if (type === 'ai.start')
            return start(v);
        throw Error('未知AI操作');
    }
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
        if (!message?.type?.startsWith('ai.') || message.target)
            return false;
        // Manual control must invalidate a currently awaiting network send immediately.
        const immediate = ['ai.clearData', 'ai.control', 'ai.snapshot', 'ai.generationStatus', 'ai.hasKey', 'ai.saveKey', 'ai.presence', 'ai.feedback', 'ai.workerEvent'].includes(message.type);
        const promise = message.type === 'ai.tick' ? (sender.id === chrome.runtime.id && sender.url === chrome.runtime.getURL('ai/offscreen.html') ? tickOnce() : Promise.reject(Error('来源无效'))) : immediate ? handle(message, sender) : serial(() => handle(message, sender));
        activeOperations.add(promise);
        promise.then(() => activeOperations.delete(promise), () => activeOperations.delete(promise));
        promise.then(value => reply({ ok: true, value }), e => reply({ ok: false, error: C.clean(e.message, 300) }));
        return true;
    });
    chrome.alarms.onAlarm.addListener(a => { if (a.name === alarm)
        void tickOnce().catch(() => { }); });
    chrome.runtime.onStartup.addListener(() => { void serial(async () => { const r = await read(); if (r && ['running', 'scheduled', 'waiting_live'].includes(r.status)) {
        r.status = 'interrupted';
        r.baseEpoch = r.epoch;
        r.epoch++;
        await write(r);
    } await chrome.storage.local.remove('aiPresence'); }); });
})();

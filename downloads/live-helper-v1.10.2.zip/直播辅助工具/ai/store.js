(function (root) {
    'use strict';
    let dbPromise;
    function metadata(p) { return { id: p.id, name: p.name, createdAt: p.createdAt, updatedAt: p.updatedAt, status: p.status }; }
    function db() {
        return dbPromise ||= new Promise((resolve, reject) => {
            const request = indexedDB.open('recruitment-ai-v1', 2);
            request.onupgradeneeded = () => {
                const database = request.result;
                if (!database.objectStoreNames.contains('projects'))
                    database.createObjectStore('projects', { keyPath: 'id' });
                if (!database.objectStoreNames.contains('metadata')) {
                    const meta = database.createObjectStore('metadata', { keyPath: 'id' });
                    const cursor = request.transaction.objectStore('projects').openCursor();
                    cursor.onsuccess = () => { if (cursor.result) {
                        meta.put(metadata(cursor.result.value));
                        cursor.result.continue();
                    } };
                }
            };
            request.onsuccess = () => { request.result.onversionchange = () => { request.result.close(); dbPromise = null; }; resolve(request.result); };
            request.onerror = () => reject(request.error);
        });
    }
    async function transaction(mode, stores, fn) {
        const database = await db();
        return new Promise((resolve, reject) => {
            const tx = database.transaction(stores, mode);
            let value;
            const request = fn(tx);
            request.onsuccess = () => { value = request.result; };
            tx.oncomplete = () => resolve(value);
            tx.onerror = () => reject(tx.error || Error('本地存储失败'));
            tx.onabort = () => reject(tx.error || Error('本地存储已中止'));
        });
    }
    root.RecruitStore = {
        get: id => transaction('readonly', ['projects'], tx => tx.objectStore('projects').get(id)),
        list: () => transaction('readonly', ['projects'], tx => tx.objectStore('projects').getAll()),
        listMeta: () => transaction('readonly', ['metadata'], tx => tx.objectStore('metadata').getAll()),
        put: p => transaction('readwrite', ['projects', 'metadata'], tx => { tx.objectStore('metadata').put(metadata(p)); return tx.objectStore('projects').put(p); }),
        clear: () => transaction('readwrite', ['projects', 'metadata'], tx => { tx.objectStore('metadata').clear(); return tx.objectStore('projects').clear(); }),
        remove: id => transaction('readwrite', ['projects', 'metadata'], tx => { tx.objectStore('metadata').delete(id); return tx.objectStore('projects').delete(id); })
    };
})(globalThis);

'use strict';
let worker, active = null;
function createWorker() {
    worker = new Worker('worker.js');
    worker.onmessage = event => { if (event.data.type === 'idle')
        active = null; void chrome.runtime.sendMessage({ type: 'ai.workerEvent', value: event.data }).catch(() => { }); };
    worker.onerror = () => { const id = active; active = null; worker.terminate(); createWorker(); void chrome.runtime.sendMessage({ type: 'ai.workerEvent', value: { type: 'crash', id, error: '生成进程中断，可从已保存批次继续' } }).catch(() => { }); };
}
createWorker();
chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || sender.tab || (sender.url && sender.url !== chrome.runtime.getURL('background.js')))
        return false;
    if (message.target !== 'recruitment-offscreen')
        return;
    if (message.type === 'ai.offscreenStatus')
        return reply({ ok: true, value: { active } });
    if (message.type === 'ai.cancelWorker') {
        worker.terminate();
        active = null;
        createWorker();
        reply({ ok: true });
        return;
    }
    if (message.type === 'ai.generateWorker') {
        if (active)
            return reply({ ok: false, error: '已有生成任务正在执行' });
        active = message.value.id;
        worker.postMessage(message.value);
        reply({ ok: true, value: { active } });
    }
});
setInterval(() => { void chrome.runtime.sendMessage({ type: 'ai.tick' }).catch(() => { }); }, 1000);

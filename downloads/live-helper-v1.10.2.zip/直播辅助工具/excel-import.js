(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.ExcelChatImport = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const EXPECTED_HEADERS = ["发布时间", "昵称", "消息内容"];
  const MAX_ROWS = 5000;

  function localDate(year, month, day, hour, minute, second) {
    const date = new Date(year, month - 1, day, hour, minute, second, 0);
    if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day
      || date.getHours() !== hour || date.getMinutes() !== minute || date.getSeconds() !== second) {
      return null;
    }
    return date;
  }

  function parsePublishTime(value, XLSX) {
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
      return localDate(
        value.getFullYear(), value.getMonth() + 1, value.getDate(),
        value.getHours(), value.getMinutes(), value.getSeconds()
      )?.getTime() ?? null;
    }
    if (typeof value === "number" && Number.isFinite(value)) {
      const parts = XLSX.SSF.parse_date_code(value);
      if (!parts) return null;
      const base = localDate(parts.y, parts.m, parts.d, 0, 0, 0);
      if (!base) return null;
      const secondsInDay = Math.round((parts.H * 3600) + (parts.M * 60) + parts.S);
      return base.getTime() + secondsInDay * 1000;
    }
    if (typeof value !== "string") return null;
    const match = value.trim().match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})[ T](\d{1,2}):(\d{2}):(\d{2})$/);
    if (!match) return null;
    return localDate(...match.slice(1).map(Number))?.getTime() ?? null;
  }

  function parseWorkbook(arrayBuffer, fileName, XLSX) {
    if (!XLSX?.read || !XLSX?.utils?.sheet_to_json || !XLSX?.SSF?.parse_date_code) {
      throw new Error("Excel 解析库未正确加载");
    }
    const workbook = XLSX.read(arrayBuffer, { type: "array", cellDates: false });
    const sheetName = workbook.SheetNames[0];
    if (!sheetName) throw new Error("Excel 文件中没有工作表");
    const rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
      header: 1,
      raw: true,
      defval: "",
      blankrows: false
    });
    if (!rows.length) throw new Error("Excel 工作表为空");
    const headers = rows[0].slice(0, 3).map((value) => String(value).trim());
    if (EXPECTED_HEADERS.some((header, index) => headers[index] !== header)) {
      throw new Error(`表头必须依次为：${EXPECTED_HEADERS.join("、")}`);
    }

    const tasks = [];
    const errors = [];
    for (let index = 1; index < rows.length; index += 1) {
      const row = rows[index];
      const values = row.slice(0, 3);
      if (values.every((value) => value === "" || value === null || value === undefined)) continue;
      const publishAt = parsePublishTime(values[0], XLSX);
      const nickname = String(values[1] ?? "").trim();
      const message = String(values[2] ?? "").trim();
      const rowErrors = [];
      if (!publishAt) rowErrors.push("发布时间无效，应精确到秒");
      if (!nickname) rowErrors.push("昵称为空");
      if (!message) rowErrors.push("消息内容为空");
      if (nickname.length > 40) rowErrors.push("昵称超过 40 字");
      if (message.length > 500) rowErrors.push("消息内容超过 500 字");
      if (rowErrors.length) errors.push(`第 ${index + 1} 行：${rowErrors.join("，")}`);
      else tasks.push({ publishAt, nickname, message });
      if (tasks.length > MAX_ROWS) throw new Error(`单次最多导入 ${MAX_ROWS} 条任务`);
    }
    if (errors.length) {
      const visible = errors.slice(0, 12).join("\n");
      const suffix = errors.length > 12 ? `\n另有 ${errors.length - 12} 行错误` : "";
      throw new Error(`${visible}${suffix}`);
    }
    if (!tasks.length) throw new Error("Excel 中没有可导入的数据行");
    tasks.sort((left, right) => left.publishAt - right.publishAt);
    return { fileName, sheetName, tasks };
  }

  return { EXPECTED_HEADERS, MAX_ROWS, parsePublishTime, parseWorkbook };
});

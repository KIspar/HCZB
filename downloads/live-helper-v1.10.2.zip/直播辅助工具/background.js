/* global RequestPlanner */
"use strict";

importScripts("scheduler.js", "ai/core.js", "ai/tasks.js", "ai/store.js");

const API_PATTERN = "https://watch-api.polyv.cn/v3/common/channel/viewer*";
const API_HOST = "watch-api.polyv.cn";
const API_PATH = "/v3/common/channel/viewer";
const LIVE_PAGE_PATTERN = /^https:\/\/[a-z0-9.-]+\.live\.plvideo\.net\/watch\/[^/?#]+/i;
const ALARM_PREFIX = "request-segment:";
const CHAT_ALARM_PREFIX = "chat-segment:";
const EXCEL_CHAT_ALARM = "excel-chat-next";
const EXCEL_LATE_TOLERANCE_MS = 5 * 60 * 1000;
const LOG_LIMIT = 200;
const DEFAULT_SETTINGS = {
  schedules: [],
  requestTimeoutMs: 15000,
  chat: {
    enabled: false,
    nicknames: [],
    messages: [],
    schedules: []
  }
};

let operationQueue = Promise.resolve();
const activeViewerRequests = new Set();

function enqueue(operation) {
  operationQueue = operationQueue.then(operation, operation);
  return operationQueue;
}

function trackViewerRequest(promise) {
  activeViewerRequests.add(promise);
  promise.finally(() => activeViewerRequests.delete(promise));
}

async function getState() {
  const stored = await chrome.storage.local.get([
    "settings", "capturedRequest", "socketRequest", "socketContext", "runs", "chatRuns",
    "excelChatTasks", "logs"
  ]);
  const storedSettings = stored.settings || {};
  const storedChat = storedSettings.chat || {};
  const socketContext = removeGeneratedIdentity(stored.socketContext || {});
  const migratedNicknames = Array.isArray(storedChat.nicknames)
    ? storedChat.nicknames
    : (storedChat.nickname ? [storedChat.nickname] : []);
  return {
    settings: {
      ...DEFAULT_SETTINGS,
      ...storedSettings,
      chat: { ...DEFAULT_SETTINGS.chat, ...storedChat, nicknames: migratedNicknames }
    },
    capturedRequest: stored.capturedRequest || null,
    socketRequest: stored.socketRequest || null,
    socketContext,
    runs: stored.runs || {},
    chatRuns: stored.chatRuns || {},
    excelChatTasks: stored.excelChatTasks || [],
    logs: stored.logs || []
  };
}

function isExpectedApiUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return url.protocol === "https:" && url.hostname === API_HOST && url.pathname === API_PATH;
  } catch {
    return false;
  }
}

function validateCapturedUrl(rawUrl) {
  if (!isExpectedApiUrl(rawUrl)) return false;
  const url = new URL(rawUrl);
  return ["channelId", "clientVersion", "xSessdata", "clientId"].every((key) => url.searchParams.has(key));
}

async function captureRequest(details) {
  if (!validateCapturedUrl(details.url) || details.tabId < 0) return;

  let tab;
  try {
    tab = await chrome.tabs.get(details.tabId);
  } catch {
    return;
  }
  if (!tab.url || !LIVE_PAGE_PATTERN.test(tab.url)) return;

  const url = new URL(details.url);
  const capturedRequest = {
    url: details.url,
    pageUrl: tab.url,
    channelId: url.searchParams.get("channelId"),
    capturedAt: Date.now(),
    protectedParams: {
      clientVersion: url.searchParams.get("clientVersion"),
      xSessdata: url.searchParams.get("xSessdata"),
      clientId: url.searchParams.get("clientId")
    }
  };
  const pageHost = new URL(tab.url).hostname;
  const stored = await chrome.storage.local.get("socketContext");
  const previousContext = stored.socketContext || {};
  const sameChannel = previousContext.channelId === url.searchParams.get("channelId");
  const socketContext = {
    ...(sameChannel ? removeGeneratedIdentity(previousContext) : {}),
    roomId: url.searchParams.get("channelId"),
    channelId: url.searchParams.get("channelId"),
    accountId: pageHost.split(".")[0]
  };
  await chrome.storage.local.set({ capturedRequest, socketContext });
  await enqueue(reconcileAllSchedules);
}

function isExpectedSocketUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return url.protocol === "wss:" && url.hostname === "chat.polyv.net" && url.pathname === "/socket.io/"
      && url.searchParams.has("token") && url.searchParams.get("EIO") === "3"
      && url.searchParams.get("transport") === "websocket";
  } catch {
    return false;
  }
}

function mergeCapturedIdentity(context, observedContext) {
  const next = { ...context, ...observedContext };
  if (observedContext.userId) next.userIdSource = "captured";
  if (observedContext.sessionId) next.sessionIdSource = "captured";
  return next;
}

function channelContext(context) {
  return {
    roomId: context?.roomId,
    channelId: context?.channelId,
    accountId: context?.accountId
  };
}

function removeGeneratedIdentity(context) {
  const next = { ...context };
  if (next.userIdSource === "generated") {
    delete next.userId;
    delete next.userIdSource;
  }
  if (next.sessionIdSource === "generated") {
    delete next.sessionId;
    delete next.sessionIdSource;
  }
  return next;
}

async function storeSocketObservation(value, sender) {
  if (!value || !isExpectedSocketUrl(value.url) || !Number.isInteger(sender.tab?.id)
    || !LIVE_PAGE_PATTERN.test(sender.tab.url || "")) {
    return;
  }
  const stored = await chrome.storage.local.get(["socketContext", "socketRequest"]);
  const previousContext = stored.socketContext || {};
  const sameSocket = stored.socketRequest?.url === value.url;
  const baseContext = sameSocket ? removeGeneratedIdentity(previousContext) : channelContext(previousContext);
  const socketContext = mergeCapturedIdentity(baseContext, value.context || {});
  await chrome.storage.local.set({
    socketRequest: {
      url: value.url,
      tabId: sender.tab.id,
      pageUrl: sender.tab.url,
      capturedAt: Date.now()
    },
    socketContext
  });
  await reconcileAllSchedules();
}

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    void captureRequest(details);
  },
  { urls: [API_PATTERN] }
);

function requestUrlForRun(capturedRequest) {
  const url = new URL(capturedRequest.url);
  if (url.searchParams.has("r")) {
    url.searchParams.set("r", Math.random().toString().slice(2));
  }
  return url.toString();
}

async function appendLog(entry, existingLogs) {
  const logs = [entry, ...existingLogs].slice(0, LOG_LIMIT);
  await chrome.storage.local.set({ logs });
  return logs;
}

async function performRequest(capturedRequest, timeoutMs) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const startedAt = Date.now();
  try {
    const response = await fetch(requestUrlForRun(capturedRequest), {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      redirect: "follow",
      headers: { Accept: "application/json, text/plain, */*" },
      signal: controller.signal
    });
    return {
      ok: response.ok,
      status: response.status,
      durationMs: Date.now() - startedAt,
      error: response.ok ? null : `HTTP ${response.status}`
    };
  } catch (error) {
    return {
      ok: false,
      status: null,
      durationMs: Date.now() - startedAt,
      error: error.name === "AbortError" ? "请求超时" : String(error.message || error)
    };
  } finally {
    clearTimeout(timeoutId);
  }
}

function socketReadiness(state) {
  if (!state.socketRequest || !isExpectedSocketUrl(state.socketRequest.url)) return "尚未捕获聊天套接字";
  const missing = ["roomId", "channelId", "accountId", "sessionId"]
    .filter((key) => !state.socketContext[key]);
  if (missing.length) return `尚未捕获会话字段：${missing.join(", ")}`;
  return null;
}

function chatReadiness(state) {
  if (!state.settings.chat.nicknames.length) return "尚未配置聊天昵称";
  if (!state.settings.chat.messages.length) return "尚未配置随机消息";
  if (!state.capturedRequest?.protectedParams?.xSessdata) return "尚未捕获观看会话 xSessdata";
  return socketReadiness(state);
}

async function setNickname(capturedRequest, channelId, nickname, timeoutMs = 15000) {
  const xSessdata = capturedRequest?.protectedParams?.xSessdata;
  if (!xSessdata || !channelId) throw new Error("缺少设置昵称所需的观看会话参数");

  const url = new URL("https://watch-api.polyv.cn/v3/watch/channel/viewer/set-nickname");
  url.searchParams.set("xSessdata", xSessdata);
  url.searchParams.set("channelId", channelId);
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", Accept: "application/json, text/plain, */*" },
      body: new URLSearchParams({ nickname }),
      signal: controller.signal
    });
    let result = null;
    try {
      result = await response.json();
    } catch {
      result = null;
    }
    if (!response.ok) throw new Error(`设置昵称失败：HTTP ${response.status}`);
    if (!result?.success && result?.status !== "success" && result?.code !== 200) {
      throw new Error(result?.message || result?.msg || "设置昵称失败");
    }
    return result;
  } catch (error) {
    if (error.name === "AbortError") throw new Error("设置昵称请求超时");
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function performChat(state, nickname, message) {
  const startedAt = Date.now();
  try {
    await setNickname(
      state.capturedRequest,
      state.socketContext.channelId || state.capturedRequest.channelId,
      nickname,
      state.settings.requestTimeoutMs
    );
    const response = await chrome.tabs.sendMessage(state.socketRequest.tabId, {
      type: "sendChat",
      value: {
        url: state.socketRequest.url,
        nick: nickname,
        message,
        context: state.socketContext
      }
    });
    if (!response?.ok) throw new Error(response?.error || "聊天发送失败");
    return { ok: true, durationMs: Date.now() - startedAt, error: null };
  } catch (error) {
    return {
      ok: false,
      durationMs: Date.now() - startedAt,
      error: String(error.message || error)
    };
  }
}

async function clearSegmentAlarm(segmentId) {
  await chrome.alarms.clear(`${ALARM_PREFIX}${segmentId}`);
}

async function scheduleNext(segment, run, now = Date.now()) {
  await clearSegmentAlarm(segment.id);
  if (!segment.enabled || run.status === "completed" || run.status === "expired") return;
  if (run.status === "waiting_for_capture") {
    const when = Math.min(now + 30000, segment.endAt - 1);
    if (when > now) {
      await chrome.alarms.create(`${ALARM_PREFIX}${segment.id}`, { when });
    }
    return;
  }
  const when = RequestPlanner.nextRunAt(segment, run.sentCount, now);
  if (when !== null) {
    await chrome.alarms.create(`${ALARM_PREFIX}${segment.id}`, { when: Math.max(when, now + 250) });
  }
}

function createRun(segment) {
  return {
    revision: RequestPlanner.segmentRevision(segment),
    sentCount: 0,
    successCount: 0,
    failureCount: 0,
    inFlightCount: 0,
    status: "waiting",
    lastRunAt: null,
    lastError: null
  };
}

async function recordRequestResults(segment, revision, capturedRequest, startedAt, results) {
  await enqueue(async () => {
    const latest = await getState();
    const run = latest.runs[segment.id];
    if (run?.revision === revision) {
      run.successCount += results.filter((result) => result.ok).length;
      run.failureCount += results.filter((result) => !result.ok).length;
      run.inFlightCount = Math.max(0, Number(run.inFlightCount || 0) - results.length);
      run.lastError = results.find((result) => !result.ok)?.error || null;
      latest.runs[segment.id] = run;
    }
    const resultLogs = results.map((result) => ({
        id: crypto.randomUUID(),
        segmentId: segment.id,
        segmentName: segment.name,
        channelId: capturedRequest.channelId,
        createdAt: startedAt,
        ...result
      }));
    latest.logs = [...resultLogs, ...latest.logs].slice(0, LOG_LIMIT);
    await chrome.storage.local.set({ runs: latest.runs, logs: latest.logs });
  });
}

async function reconcileSchedules() {
  const state = await getState();
  const activeIds = new Set();
  const configuredIds = new Set(state.settings.schedules.map((segment) => segment.id));
  const now = Date.now();

  for (const segment of state.settings.schedules) {
    const errors = RequestPlanner.validateSegment(segment);
    if (errors.length > 0 || !segment.enabled) {
      await clearSegmentAlarm(segment.id);
      continue;
    }

    activeIds.add(segment.id);
    let run = state.runs[segment.id];
    if (!run || run.revision !== RequestPlanner.segmentRevision(segment)) {
      run = createRun(segment);
      state.runs[segment.id] = run;
    }
    if (run.sentCount >= segment.totalRequests) run.status = "completed";
    else if (now >= segment.endAt) run.status = "expired";
    else if (now >= segment.startAt) run.status = "running";
    else run.status = "waiting";
    await scheduleNext(segment, run, now);
  }

  for (const segmentId of Object.keys(state.runs)) {
    if (!configuredIds.has(segmentId)) {
      await clearSegmentAlarm(segmentId);
      delete state.runs[segmentId];
    }
  }
  const alarms = await chrome.alarms.getAll();
  for (const alarm of alarms) {
    if (alarm.name.startsWith(ALARM_PREFIX)) {
      const segmentId = alarm.name.slice(ALARM_PREFIX.length);
      if (!activeIds.has(segmentId)) await chrome.alarms.clear(alarm.name);
    }
  }
  await chrome.storage.local.set({ runs: state.runs });
}

async function runSegment(segmentId) {
  const state = await getState();
  const segment = state.settings.schedules.find((item) => item.id === segmentId);
  if (!segment || !segment.enabled) {
    await clearSegmentAlarm(segmentId);
    return;
  }

  let run = state.runs[segmentId];
  if (!run || run.revision !== RequestPlanner.segmentRevision(segment)) {
    run = createRun(segment);
  }
  const now = Date.now();
  if (run.sentCount >= segment.totalRequests) {
    run.status = "completed";
  } else if (now >= segment.endAt) {
    run.status = "expired";
    run.lastError = "时间段已结束，未在段外补发";
  } else if (now < segment.startAt) {
    run.status = "waiting";
  } else if (!state.capturedRequest || !validateCapturedUrl(state.capturedRequest.url)) {
    run.status = "waiting_for_capture";
    run.lastError = "尚未捕获到有效的观看请求";
  } else {
    run.status = "running";
    const batchSize = RequestPlanner.nextBatchSize(segment, run.sentCount);
    const revision = run.revision;
    const startedAt = Date.now();
    run.sentCount += batchSize;
    run.inFlightCount = Number(run.inFlightCount || 0) + batchSize;
    run.lastRunAt = startedAt;
    run.lastError = null;
    if (run.sentCount >= segment.totalRequests) run.status = "completed";
    state.runs[segmentId] = run;
    await chrome.storage.local.set({ runs: state.runs });
    await scheduleNext(segment, run, Date.now());

    const requestBatch = Promise.all(
      Array.from({ length: batchSize }, () => performRequest(
        state.capturedRequest,
        state.settings.requestTimeoutMs
      ))
    ).then((results) => recordRequestResults(
      segment,
      revision,
      state.capturedRequest,
      startedAt,
      results
    )).catch((error) => console.error("观看请求结果记录失败", error));
    trackViewerRequest(requestBatch);
    return;
  }

  state.runs[segmentId] = run;
  await chrome.storage.local.set({ runs: state.runs });
  await scheduleNext(segment, run, Date.now());
}

async function clearChatAlarm(segmentId) {
  await chrome.alarms.clear(`${CHAT_ALARM_PREFIX}${segmentId}`);
}

async function scheduleNextChat(segment, run, now = Date.now()) {
  await clearChatAlarm(segment.id);
  if (!segment.enabled || run.status === "completed" || run.status === "expired") return;
  if (run.status === "waiting_for_capture") {
    const when = Math.min(now + 30000, segment.endAt - 1);
    if (when > now) await chrome.alarms.create(`${CHAT_ALARM_PREFIX}${segment.id}`, { when });
    return;
  }
  const when = RequestPlanner.nextRunAt(segment, run.sentCount, now);
  if (when !== null) {
    await chrome.alarms.create(`${CHAT_ALARM_PREFIX}${segment.id}`, { when: Math.max(when, now + 250) });
  }
}

function createChatRun(segment) {
  return {
    revision: RequestPlanner.segmentRevision(segment),
    sentCount: 0,
    successCount: 0,
    failureCount: 0,
    status: "waiting",
    nicknameBag: null,
    messageBag: null,
    lastRunAt: null,
    lastError: null
  };
}

async function reconcileChatSchedules() {
  const state = await getState();
  const schedules = state.settings.chat.schedules || [];
  const activeIds = new Set();
  const configuredIds = new Set(schedules.map((segment) => segment.id));
  const now = Date.now();

  for (const segment of schedules) {
    const errors = RequestPlanner.validateSegment(segment);
    if (errors.length > 0 || !segment.enabled || !state.settings.chat.enabled) {
      await clearChatAlarm(segment.id);
      continue;
    }
    activeIds.add(segment.id);
    let run = state.chatRuns[segment.id];
    if (!run || run.revision !== RequestPlanner.segmentRevision(segment)) {
      run = createChatRun(segment);
      state.chatRuns[segment.id] = run;
    }
    if (run.sentCount >= segment.totalRequests) run.status = "completed";
    else if (now >= segment.endAt) run.status = "expired";
    else if (now >= segment.startAt) run.status = "running";
    else run.status = "waiting";
    await scheduleNextChat(segment, run, now);
  }

  for (const segmentId of Object.keys(state.chatRuns)) {
    if (!configuredIds.has(segmentId)) {
      await clearChatAlarm(segmentId);
      delete state.chatRuns[segmentId];
    }
  }
  const alarms = await chrome.alarms.getAll();
  for (const alarm of alarms) {
    if (!alarm.name.startsWith(CHAT_ALARM_PREFIX)) continue;
    const segmentId = alarm.name.slice(CHAT_ALARM_PREFIX.length);
    if (!activeIds.has(segmentId)) await chrome.alarms.clear(alarm.name);
  }
  await chrome.storage.local.set({ chatRuns: state.chatRuns });
}

function excelTaskKey(task) {
  return `${task.publishAt}\u0000${task.nickname}\u0000${task.message}`;
}

function createExcelTask(task, sourceFile, now = Date.now()) {
  const publishAt = Number(task.publishAt);
  const missed = publishAt < now - EXCEL_LATE_TOLERANCE_MS;
  return {
    id: crypto.randomUUID(),
    publishAt,
    nickname: String(task.nickname).trim(),
    message: String(task.message).trim(),
    sourceFile,
    importedAt: now,
    status: missed ? "missed" : "pending",
    sentAt: null,
    lastError: missed ? "导入时已超过允许的 5 分钟延迟" : null,
    retryAt: null
  };
}

async function reconcileExcelTasks() {
  const state = await getState();
  const now = Date.now();
  let changed = false;
  const socketReady = !socketReadiness(state);
  for (const task of state.excelChatTasks) {
    if (task.status === "pending" && task.publishAt < now - EXCEL_LATE_TOLERANCE_MS) {
      task.status = "missed";
      task.lastError = "超过计划时间 5 分钟，未补发";
      task.retryAt = null;
      changed = true;
    }
    if (socketReady && task.status === "pending" && task.retryAt) {
      task.retryAt = null;
      changed = true;
    }
  }
  await chrome.alarms.clear(EXCEL_CHAT_ALARM);
  const next = state.excelChatTasks
    .filter((task) => task.status === "pending")
    .sort((left, right) =>
      Math.max(left.publishAt, Number(left.retryAt) || 0)
      - Math.max(right.publishAt, Number(right.retryAt) || 0)
    )[0];
  if (next) {
    const when = Math.max(now + 250, next.publishAt, Number(next.retryAt) || 0);
    await chrome.alarms.create(EXCEL_CHAT_ALARM, { when });
  }
  if (changed) await chrome.storage.local.set({ excelChatTasks: state.excelChatTasks });
}

async function importExcelTasks(tasks, mode, sourceFile) {
  if (!Array.isArray(tasks) || tasks.length === 0 || tasks.length > 5000) {
    throw new Error("导入任务数量无效");
  }
  const normalized = tasks.map((task, index) => {
    const publishAt = Number(task.publishAt);
    const nickname = String(task.nickname || "").trim();
    const message = String(task.message || "").trim();
    if (!Number.isFinite(publishAt) || !nickname || !message || nickname.length > 40 || message.length > 500) {
      throw new Error(`第 ${index + 2} 行任务数据无效`);
    }
    return { publishAt, nickname, message };
  });

  const state = await getState();
  const existing = mode === "replace" ? [] : state.excelChatTasks;
  const keys = new Set(existing.map(excelTaskKey));
  const now = Date.now();
  let duplicates = 0;
  const imported = [];
  for (const task of normalized) {
    if (keys.has(excelTaskKey(task))) {
      duplicates += 1;
      continue;
    }
    keys.add(excelTaskKey(task));
    imported.push(createExcelTask(task, sourceFile, now));
  }
  const excelChatTasks = [...existing, ...imported].sort((left, right) => left.publishAt - right.publishAt);
  await chrome.storage.local.set({ excelChatTasks });
  await reconcileExcelTasks();
  return {
    imported: imported.length,
    duplicates,
    missed: imported.filter((task) => task.status === "missed").length,
    total: excelChatTasks.length
  };
}

async function runExcelChatTasks() {
  const state = await getState();
  const now = Date.now();
  const due = state.excelChatTasks
    .filter((task) => task.status === "pending" && task.publishAt <= now)
    .sort((left, right) => left.publishAt - right.publishAt);

  const notReady = socketReadiness(state);
  if (notReady && due.length) {
    for (const task of due) {
      if (task.publishAt < now - EXCEL_LATE_TOLERANCE_MS) {
        task.status = "missed";
        task.lastError = "套接字未就绪且已超过计划时间 5 分钟";
        task.retryAt = null;
      } else {
        task.lastError = notReady;
        task.retryAt = now + 30000;
      }
    }
    await chrome.storage.local.set({ excelChatTasks: state.excelChatTasks });
    await reconcileExcelTasks();
    return;
  }

  for (const task of due) {
    if (task.publishAt < Date.now() - EXCEL_LATE_TOLERANCE_MS) {
      task.status = "missed";
      task.lastError = "超过计划时间 5 分钟，未补发";
      task.retryAt = null;
      continue;
    }
    const result = await performChat(state, task.nickname, task.message);
    task.status = result.ok ? "sent" : "failed";
    task.sentAt = Date.now();
    task.lastError = result.error;
    task.retryAt = null;
    state.logs = await appendLog({
      id: crypto.randomUUID(),
      segmentId: "excel-chat",
      segmentName: "Excel 定时聊天",
      channelId: state.socketContext.channelId,
      nickname: task.nickname,
      message: task.message,
      status: "WS",
      createdAt: task.sentAt,
      ...result
    }, state.logs);
  }
  await chrome.storage.local.set({ excelChatTasks: state.excelChatTasks });
  await reconcileExcelTasks();
}

async function reconcileAllSchedules() {
  await reconcileSchedules();
  await reconcileChatSchedules();
  await reconcileExcelTasks();
}

async function runChatSegment(segmentId) {
  const state = await getState();
  const segment = (state.settings.chat.schedules || []).find((item) => item.id === segmentId);
  if (!state.settings.chat.enabled || !segment?.enabled) {
    await clearChatAlarm(segmentId);
    return;
  }

  let run = state.chatRuns[segmentId];
  if (!run || run.revision !== RequestPlanner.segmentRevision(segment)) run = createChatRun(segment);
  const now = Date.now();
  const notReady = chatReadiness(state);
  if (run.sentCount >= segment.totalRequests) {
    run.status = "completed";
  } else if (now >= segment.endAt) {
    run.status = "expired";
    run.lastError = "聊天时间段已结束，未在段外补发";
  } else if (now < segment.startAt) {
    run.status = "waiting";
  } else if (notReady) {
    run.status = "waiting_for_capture";
    run.lastError = notReady;
  } else {
    run.status = "running";
    const nicknameDraw = RequestPlanner.drawFromBag(
      state.settings.chat.nicknames,
      run.nicknameBag,
      Math.random
    );
    const messageDraw = RequestPlanner.drawFromBag(
      state.settings.chat.messages,
      run.messageBag,
      Math.random
    );
    run.nicknameBag = nicknameDraw.bagState;
    run.messageBag = messageDraw.bagState;
    const result = await performChat(state, nicknameDraw.value, messageDraw.value);
    run.sentCount += 1;
    run.successCount += result.ok ? 1 : 0;
    run.failureCount += result.ok ? 0 : 1;
    run.lastRunAt = Date.now();
    run.lastError = result.error;
    await appendLog({
      id: crypto.randomUUID(),
      segmentId,
      segmentName: segment.name,
      channelId: state.socketContext.channelId,
      nickname: nicknameDraw.value,
      message: messageDraw.value,
      status: "WS",
      createdAt: run.lastRunAt,
      ...result
    }, state.logs);
    if (run.sentCount >= segment.totalRequests) run.status = "completed";
  }

  state.chatRuns[segmentId] = run;
  await chrome.storage.local.set({ chatRuns: state.chatRuns });
  await scheduleNextChat(segment, run, Date.now());
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === EXCEL_CHAT_ALARM) {
    void enqueue(runExcelChatTasks);
    return;
  }
  if (alarm.name.startsWith(CHAT_ALARM_PREFIX)) {
    const segmentId = alarm.name.slice(CHAT_ALARM_PREFIX.length);
    void enqueue(() => runChatSegment(segmentId));
    return;
  }
  if (alarm.name.startsWith(ALARM_PREFIX)) {
    const segmentId = alarm.name.slice(ALARM_PREFIX.length);
    // Only the launch transaction is serialized; network responses never block later batches.
    void enqueue(() => runSegment(segmentId));
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void (async () => {
    const stored = await chrome.storage.local.get(["socketRequest", "socketContext"]);
    if (stored.socketRequest?.tabId !== tabId) return;
    const context = stored.socketContext || {};
    delete context.userId;
    delete context.sessionId;
    delete context.userIdSource;
    delete context.sessionIdSource;
    await chrome.storage.local.set({ socketRequest: null, socketContext: context });
  })();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type?.startsWith("ai.")) return false;
  const respond = async () => {
    if (message?.type === "socketObserved") {
      await enqueue(() => storeSocketObservation(message.value, sender));
      return { stored: true };
    }
    if (message?.type === "getState") return getState();
    if (message?.type === "syncSchedules") {
      await enqueue(reconcileAllSchedules);
      return getState();
    }
    if (message?.type === "testRequest") {
      const state = await getState();
      if (!state.capturedRequest) throw new Error("尚未捕获到观看请求");
      const result = await performRequest(state.capturedRequest, state.settings.requestTimeoutMs);
      await appendLog({
        id: crypto.randomUUID(),
        segmentId: "manual",
        segmentName: "手动测试",
        channelId: state.capturedRequest.channelId,
        createdAt: Date.now(),
        ...result
      }, state.logs);
      return result;
    }
    if (message?.type === "testChat") {
      const state = await getState();
      const notReady = chatReadiness(state);
      if (notReady) throw new Error(notReady);
      const selectedNick = RequestPlanner.chooseMessage(state.settings.chat.nicknames, -1, Math.random());
      const selected = RequestPlanner.chooseMessage(state.settings.chat.messages, -1, Math.random());
      const result = await performChat(state, selectedNick.message, selected.message);
      await appendLog({
        id: crypto.randomUUID(),
        segmentId: "manual-chat",
        segmentName: "聊天测试",
        channelId: state.capturedRequest?.channelId,
        nickname: selectedNick.message,
        message: selected.message,
        status: "WS",
        createdAt: Date.now(),
        ...result
      }, state.logs);
      return result;
    }
    if (message?.type === "importExcelTasks") {
      return enqueue(() => importExcelTasks(
        message.value?.tasks,
        message.value?.mode === "append" ? "append" : "replace",
        String(message.value?.sourceFile || "Excel 导入")
      ));
    }
    if (message?.type === "clearExcelTasks") {
      await enqueue(async () => {
        await chrome.alarms.clear(EXCEL_CHAT_ALARM);
        await chrome.storage.local.set({ excelChatTasks: [] });
      });
      return { cleared: true };
    }
    if (message?.type === "deleteExcelTask") {
      await enqueue(async () => {
        const state = await getState();
        const excelChatTasks = state.excelChatTasks.filter((task) => task.id !== message.value?.id);
        await chrome.storage.local.set({ excelChatTasks });
        await reconcileExcelTasks();
      });
      return { deleted: true };
    }
    if (message?.type === "clearLogs") {
      await chrome.storage.local.set({ logs: [] });
      return { ok: true };
    }
    throw new Error("未知操作");
  };

  respond().then(
    (value) => sendResponse({ ok: true, value }),
    (error) => sendResponse({ ok: false, error: String(error.message || error) })
  );
  return true;
});

chrome.runtime.onInstalled.addListener(() => {
  void enqueue(reconcileAllSchedules);
});

chrome.runtime.onStartup.addListener(() => {
  void enqueue(reconcileAllSchedules);
});

void enqueue(reconcileAllSchedules);

importScripts("ai/runtime.js");

(function () {
  "use strict";

  const BRIDGE_SOURCE = "polyv-request-scheduler";
  const CHAT_SOCKET_PATTERN = /^wss:\/\/chat\.polyv\.net\/socket\.io\//i;
  const NativeWebSocket = window.WebSocket;
  const observedContext = {};
  const observedSockets = new Set();
  const socketContexts = new WeakMap();
  let latestSocketUrl = null;
  let client = null;
  let aiEpoch = null;

  window.__polyvChatSockets = observedSockets;

  function post(type, payload, requestId = null) {
    window.postMessage({ source: BRIDGE_SOURCE, type, payload, requestId }, "*");
  }

  function parseSocketEvent(data) {
    if (typeof data !== "string" || !data.startsWith("42")) return null;
    const bracketIndex = data.indexOf("[");
    if (bracketIndex < 0) return null;
    try {
      const packet = JSON.parse(data.slice(bracketIndex));
      if (!["message", "emotion"].includes(packet[0]) || typeof packet[1] !== "string") return null;
      const payload = JSON.parse(packet[1]);
      return payload && typeof payload === "object" ? { eventName: packet[0], payload } : null;
    } catch {
      return null;
    }
  }

  function parseBusinessFrame(data) {
    const event = parseSocketEvent(data);
    return event?.eventName === "message" ? event.payload : null;
  }

  function businessMessageMatches(payload, command) {
    if (!payload || payload.EVENT !== "SPEAK") return false;
    const values = Array.isArray(payload.values) ? payload.values : [];
    return String(values[0] ?? "") === String(command.message ?? "")
      && (!command.context?.roomId || String(payload.roomId ?? "") === String(command.context.roomId));
  }

  function dispatchLocalMessage(socket, payload, eventName = "message") {
    const frame = `42${JSON.stringify([eventName, JSON.stringify(payload)])}`;
    const event = typeof MessageEvent === "function"
      ? new MessageEvent("message", { data: frame })
      : { data: frame };
    if (typeof socket.dispatchEvent !== "function") return false;
    return socket.dispatchEvent(event);
  }

  function observeFrame(socketUrl, data, socket) {
    if (!CHAT_SOCKET_PATTERN.test(socketUrl)) return;
    latestSocketUrl = socketUrl;
    const payload = parseBusinessFrame(data);
    if (!payload) return;
    const context = socketContexts.get(socket) || observedContext;

    if (payload.EVENT === "SET_NICK") {
      if (payload.roomId) context.roomId = String(payload.roomId);
      if (payload.userId) context.userId = String(payload.userId);
    }
    if (payload.EVENT === "LOGIN") {
      for (const key of ["roomId", "channelId", "sessionId", "groupId"]) {
        if (payload[key]) context[key] = String(payload[key]);
      }
      if (payload.values?.[2] !== undefined && String(payload.values[2])) context.userId = String(payload.values[2]);
      if (payload.values?.[1]) context.pic = String(payload.values[1]);
      if (payload.type) context.userType = String(payload.type);
    }
    if (payload.EVENT === "SPEAK") {
      for (const key of ["roomId", "channelId", "accountId", "sessionId"]) {
        if (payload[key]) context[key] = String(payload[key]);
      }
    }
    Object.assign(observedContext, context);
    post("socketObserved", { url: socketUrl, context: { ...context } });
  }

  function parseSocketUrl(rawUrl) {
    try {
      return new URL(rawUrl);
    } catch {
      return null;
    }
  }

  class ObservedWebSocket extends NativeWebSocket {
    constructor(url, protocols) {
      if (protocols === undefined) super(url);
      else super(url, protocols);
      const socketUrl = String(url);
      if (CHAT_SOCKET_PATTERN.test(socketUrl)) {
        socketContexts.set(this, {});
        observedSockets.add(this);
        this.addEventListener("message", (event) => {
          if (!event.isTrusted) return;
          const payload = parseBusinessFrame(event.data);
          if (payload?.EVENT === "SPEAK") {
            post("aiAudience", { text: String(payload.values?.[0] || "").slice(0,180) });
          }
        });
        this.addEventListener("close", () => observedSockets.delete(this), { once: true });
        latestSocketUrl = socketUrl;
        post("socketObserved", { url: socketUrl, context: { ...observedContext } });
      }
    }

    send(data) {
      observeFrame(this.url || latestSocketUrl || "", data, this);
      return super.send(data);
    }
  }

  Object.defineProperties(ObservedWebSocket, {
    CONNECTING: { value: NativeWebSocket.CONNECTING },
    OPEN: { value: NativeWebSocket.OPEN },
    CLOSING: { value: NativeWebSocket.CLOSING },
    CLOSED: { value: NativeWebSocket.CLOSED }
  });
  window.WebSocket = ObservedWebSocket;

  function parseAck(frame) {
    const match = /^43(\d+)(.*)$/.exec(frame);
    if (!match) return null;
    let args = [];
    try {
      args = match[2] ? JSON.parse(match[2]) : [];
    } catch {
      args = [];
    }
    return { id: Number(match[1]), args };
  }

  function knownServerError(value) {
    if (typeof value !== "string") return null;
    const text = value.trim();
    if (!text) return null;
    return /用户不存在|user\s*(?:does\s*not\s*)?exist|user\s*not\s*found|未登录|未授权|无权限|权限不足|token|session|forbidden|unauthori[sz]ed|失败|error/i.test(text)
      ? text
      : null;
  }

  function ackError(value, allowPlainSuccess = false) {
    if (value === null || value === undefined || value === "") return null;
    if (typeof value === "object") {
      if (value.status === "success" || value.status === "ok" || value.ok === true) return null;
      return value.message || value.error || value.msg || "服务器拒绝了请求";
    }
    if (typeof value === "boolean") return value ? null : "服务器拒绝了请求";
    if (typeof value !== "string") return String(value);
    const text = value.trim();
    if (!text) return null;
    try {
      const parsed = JSON.parse(text);
      if (typeof parsed === "string" && parsed !== text) return ackError(parsed, allowPlainSuccess);
      if (parsed && typeof parsed === "object") return ackError(parsed, allowPlainSuccess);
    } catch {
      // Some deployments return a plain text success or error message.
    }
    if (allowPlainSuccess && /^(success|ok|true)$/i.test(text)) return null;
    return text;
  }

  function emotionReceipt(args) {
    if (!args.length) throw new Error("服务器未确认表情发送");
    if (args.length > 1) {
      const error = ackError(args[1], true);
      if (error) throw new Error(error);
    }
    let value = args[0];
    for (let i = 0; i < 3 && typeof value === "string"; i++) {
      try { value = JSON.parse(value); } catch { break; }
    }
    if (value && typeof value === "object") {
      // PolyvSocket.emitSocket unwraps {code:200,data:{messageId}} for its sender.
      // This bridge receives the raw callback instead of that unwrapped value.
      if (typeof value.code === "number") {
        if (value.code !== 200) throw new Error(value.message || value.error || value.msg || "服务器拒绝了表情请求");
        value = value.data;
      }
      if (value && typeof value === "object") {
        if (value.status === "error" || value.ok === false || value.error)
          throw new Error(value.message || value.error || value.msg || "服务器拒绝了表情请求");
        if (["string", "number"].includes(typeof value.messageId) && String(value.messageId)) return String(value.messageId);
      }
      throw new Error("表情确认缺少消息编号");
    }
    const error = ackError(value, true);
    if (error) throw new Error(error);
    if (value !== true && !/^(success|ok|true)$/i.test(String(value))) throw new Error("服务器未确认表情发送");
    return null; // Older servers only acknowledge success; there is no history ID.
  }

  function checkLoginAck(args) {
    if (args.length > 1) {
      const error = ackError(args[1], true);
      if (error) throw new Error("聊天昵称同步失败：" + error);
    }
    let code = args[0];
    if (typeof code === "string") { try { code = JSON.parse(code); } catch { } }
    if (code === true || /^(?:2\d{2,}|success|ok)$/i.test(String(code))) return;
    throw new Error("聊天昵称同步失败：" + (knownServerError(code) || "服务器未确认登录，请刷新直播页面"));
  }

  function emotionMatches(entry, command, messageId, startedAt) {
    const { payload } = entry;
    if (entry.eventName !== "emotion" || entry.receivedAt < startedAt || String(payload.id) !== String(command.stickerId)) return false;
    if (messageId) return String(payload.messageId) === messageId;
    return command.context?.userId ? String(payload.user?.userId) === String(command.context.userId) : payload.user?.nick === command.nick;
  }

  class ChatSocketClient {
    constructor(socket) {
      this.socket = socket;
      this.url = socket.url;
      this.pendingAcks = new Map();
      this.nextAckId = 1000000;
      this.queue = Promise.resolve();
      this.recentInbound = [];
      this.echoWaiters = new Set();
      this.onMessage = (event) => this.handleFrame(event.data);
      this.onClose = () => {
        this.rejectPending(new Error("直播页面套接字已断开"));
        for (const waiter of this.echoWaiters) waiter.finish(false);
      };
      socket.addEventListener("message", this.onMessage);
      socket.addEventListener("close", this.onClose);
    }

    isOpen() {
      return this.socket?.readyState === NativeWebSocket.OPEN;
    }

    connect() {
      if (!this.isOpen()) throw new Error("直播页面套接字未连接");
      return Promise.resolve();
    }

    rejectPending(error) {
      for (const pending of this.pendingAcks.values()) {
        clearTimeout(pending.timeoutId);
        pending.reject(error);
      }
      this.pendingAcks.clear();
    }

    handleFrame(frame) {
      if (typeof frame !== "string") return;
      const event = parseSocketEvent(frame);
      if (event) {
        const entry = { ...event, receivedAt: Date.now() };
        this.recentInbound.push(entry);
        if (this.recentInbound.length > 30) this.recentInbound.shift();
        for (const waiter of this.echoWaiters) if (waiter.matches(entry)) waiter.finish(true);
      }
      const ack = parseAck(frame);
      if (!ack) return;
      const pending = this.pendingAcks.get(ack.id);
      if (!pending) return;
      clearTimeout(pending.timeoutId);
      this.pendingAcks.delete(ack.id);
      pending.resolve(ack.args);
    }

    waitForEmotionEcho(command, messageId, startedAt) {
      const matches = entry => emotionMatches(entry, command, messageId, startedAt);
      if (this.recentInbound.some(matches)) return Promise.resolve(true);
      return new Promise(resolve => {
        const waiter = { matches, finish: echoed => {
          clearTimeout(timer);
          this.echoWaiters.delete(waiter);
          resolve(echoed);
        } };
        const timer = setTimeout(() => waiter.finish(false), 250);
        this.echoWaiters.add(waiter);
      });
    }

    async emitMessage(payload, eventName = "message") {
      await this.connect();
      const ackId = this.nextAckId;
      this.nextAckId += 1;
      const frame = `42${ackId}${JSON.stringify([eventName, JSON.stringify(payload)])}`;
      return new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
          this.pendingAcks.delete(ackId);
          reject(new Error(`等待 ACK ${ackId} 超时`));
        }, 10000);
        this.pendingAcks.set(ackId, { resolve, reject, timeoutId });
        this.socket.send(frame);
      });
    }

    async sendChatCommand(command) {
      const { nick, message } = command;
      const captured = socketContexts.get(this.socket) || {};
      const context = { ...captured, ...command.context, userId: captured.userId || command.context?.userId };
      const startedAt = Date.now();
      await this.connect();
      if (command.aiEpoch !== undefined && command.aiEpoch !== aiEpoch) throw new Error("节点已切换，旧发送任务已取消");
      if (!nick || /自动招聘助手|[\p{Extended_Pictographic}\p{Regional_Indicator}\uFE0F\u20E3]/u.test(nick)) throw new Error("昵称未清理，请重新启动任务");
      if (command.stickerId !== undefined && !/^(?:[0-9]|1[0-5])$/.test(String(command.stickerId))) throw new Error("表情编号无效");
      if (!context.userId) throw new Error("尚未捕获观看用户身份，请刷新直播页面后重试");
      // The viewer profile API does not guarantee that an existing chat socket
      // adopts its nickname. Rebind that socket with the captured viewer ID.
      const loginAck = await this.emitMessage({
        EVENT: "LOGIN",
        values: [nick, context.pic || "https://s1.videocc.net/default-img/avatar/viewer.png", String(context.userId)],
        channelId: context.channelId, roomId: context.roomId,
        type: context.userType || "student", sessionId: context.sessionId,
        ...(context.groupId ? { groupId: context.groupId } : {})
      });
      checkLoginAck(loginAck);
      if (command.aiEpoch !== undefined && command.aiEpoch !== aiEpoch) throw new Error("节点已切换，旧发送任务已取消");
      if (command.stickerId !== undefined) {
        const ack = await this.emitMessage({ id: String(command.stickerId) }, "emotion");
        const messageId = emotionReceipt(ack);
        const echoed = await this.waitForEmotionEcho(command, messageId, startedAt);
        if (!echoed && this.isOpen() && (command.aiEpoch === undefined || command.aiEpoch === aiEpoch)) {
          // Like the native sender's local message, only display after success.
          // Use the native emotion event, not a SPEAK message or custom image HTML.
          dispatchLocalMessage(this.socket, {
            id: String(command.stickerId),
            messageId: messageId || `local-emotion-${Date.now()}-${this.nextAckId}`,
            time: Date.now(),
            user: { userId: context?.userId || observedContext.userId || "", nick,
              pic: "https://s1.videocc.net/default-img/avatar/viewer.png", userType: "student",
              ...(context?.groupId ? { groupId: context.groupId } : {}) },
            roomId: context?.roomId,
            channelId: context?.channelId
          }, "emotion");
        }
        return { ack, stickerId: String(command.stickerId), messageId };
      }
      const speakAck = await this.emitMessage({
        EVENT: "SPEAK",
        values: [message],
        roomId: context.roomId,
        channelId: context.channelId,
        accountId: context.accountId,
        sessionId: context.sessionId,
        needIdCallback: 1
      });
      const speakError = speakAck.length > 1
        ? ackError(speakAck[1])
        : knownServerError(speakAck[0]);
      if (speakError) throw new Error(speakError);

      // Some Polyv rooms acknowledge SPEAK without echoing it to the socket
      // that sent the message. Keep the page's own chat list in sync in that case.
      const echoed = this.recentInbound.some((entry) =>
        businessMessageMatches(entry.payload, command)
        && entry.receivedAt >= startedAt
      );
      if (!echoed) {
        const messageId = speakAck[0] || `local-${Date.now()}`;
        dispatchLocalMessage(this.socket, {
          EVENT: "SPEAK",
          id: String(messageId),
          time: Date.now(),
          user: {
            userId: context.userId || String(messageId),
            nick,
            pic: "https://s1.videocc.net/default-img/avatar/viewer.png",
            userType: "student"
          },
          values: [command.message],
          roomId: context.roomId,
          channelId: context.channelId,
          accountId: context.accountId,
          sessionId: context.sessionId,
          type: "student"
        });
      }
      return { ack: speakAck };
    }

    sendChat(command) {
      const task = this.queue.then(() => this.sendChatCommand(command));
      this.queue = task.catch(() => undefined);
      return task;
    }

    close() {
      this.socket?.removeEventListener("message", this.onMessage);
      this.socket?.removeEventListener("close", this.onClose);
      this.rejectPending(new Error("聊天发送已取消"));
      for (const waiter of this.echoWaiters) waiter.finish(false);
      this.socket = null;
    }
  }

  window.addEventListener("message", async (event) => {
    const message = event.data;
    if (event.source !== window || message?.source !== BRIDGE_SOURCE) return;
    if (message.type === "aiGuard") { aiEpoch = message.payload?.epoch; return; }
    if (message.type !== "sendChat") return;
    try {
      const command = message.payload;
      if (!command?.url || !CHAT_SOCKET_PATTERN.test(command.url)) throw new Error("套接字地址无效");
      const socketUrl = parseSocketUrl(command.url);
      const liveSocket = Array.from(window.__polyvChatSockets || [])
        .find((socket) => socketUrl
          && parseSocketUrl(socket.url)?.href === socketUrl.href
          && socket.readyState === NativeWebSocket.OPEN);
      if (!liveSocket) throw new Error("直播页面套接字未连接，请刷新直播页面后重试");
      if (!client || client.socket !== liveSocket) {
        client?.close();
        client = new ChatSocketClient(liveSocket);
      }
      const result = await client.sendChat(command);
      post("sendChatResult", { ok: true, result }, message.requestId);
    } catch (error) {
      post("sendChatResult", { ok: false, error: String(error.message || error) }, message.requestId);
    }
  });
})();

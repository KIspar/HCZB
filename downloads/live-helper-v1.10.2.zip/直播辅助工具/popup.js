"use strict";

function formatDate(timestamp) {
  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false
  }).format(new Date(timestamp));
}

async function load() {
  const response = await chrome.runtime.sendMessage({ type: "getState" });
  if (!response?.ok) throw new Error(response?.error || "读取失败");
  const state = response.value;
  const captured = state.capturedRequest;
  document.querySelector("#captureDot").classList.toggle("ready", Boolean(captured));
  document.querySelector("#captureText").textContent = captured
    ? `已捕获频道 ${captured.channelId}`
    : "尚未捕获观看请求";
  const requestSchedules = state.settings.schedules.map((item) => ({ ...item, kind: "API" }));
  const chatSchedules = state.settings.chat.enabled
    ? (state.settings.chat.schedules || []).map((item) => ({ ...item, kind: "聊天" }))
    : [];
  document.querySelector("#activeCount").textContent = [...requestSchedules, ...chatSchedules]
    .filter((item) => item.enabled).length;
  const runs = [...Object.values(state.runs), ...Object.values(state.chatRuns || {})];
  const excelTasks = state.excelChatTasks || [];
  document.querySelector("#sentCount").textContent = runs.reduce((sum, run) => sum + run.sentCount, 0)
    + excelTasks.filter((task) => task.status === "sent").length;
  document.querySelector("#failedCount").textContent = runs.reduce((sum, run) => sum + run.failureCount, 0)
    + excelTasks.filter((task) => task.status === "failed" || task.status === "missed").length;

  const excelSchedules = excelTasks
    .filter((task) => task.status === "pending")
    .map((task) => ({ name: task.nickname, kind: "Excel", startAt: task.publishAt, endAt: task.publishAt + 1, enabled: true }));
  const next = [...requestSchedules, ...chatSchedules, ...excelSchedules]
    .filter((segment) => segment.enabled && segment.endAt > Date.now())
    .sort((a, b) => a.startAt - b.startAt)[0];
  document.querySelector("#nextRun").textContent = next
    ? `下一时间段：${next.kind} · ${next.name} · ${formatDate(next.startAt)}`
    : "没有待执行的时间段";
}

document.querySelector("#openOptions").addEventListener("click", () => chrome.runtime.openOptionsPage());
load().catch((error) => { document.querySelector("#captureText").textContent = error.message; });

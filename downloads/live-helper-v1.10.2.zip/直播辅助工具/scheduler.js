(function (root, factory) {
  const planner = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = planner;
  }
  root.RequestPlanner = planner;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const MIN_REQUEST_GAP_MS = 1000;
  const MAX_CONCURRENCY = 100;
  const DEFAULT_PEAK_WIDTH_PERCENT = 12;
  const MAX_PEAK_STRENGTH = 20;
  const MAX_PEAKS = 3;

  function hashString(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index += 1) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function pseudoRandom(seed) {
    let value = seed >>> 0;
    value ^= value << 13;
    value ^= value >>> 17;
    value ^= value << 5;
    return (value >>> 0) / 4294967296;
  }

  function segmentRevision(segment) {
    const baseRevision = [segment.id, segment.startAt, segment.endAt, segment.totalRequests].join(":");
    const concurrency = getConcurrency(segment);
    const peaks = getPeaks(segment);
    if (concurrency === 1 && peaks.length === 0) return baseRevision;
    return [baseRevision, concurrency, JSON.stringify(peaks)].join(":");
  }

  function getConcurrency(segment) {
    const concurrency = Number(segment?.concurrency ?? 1);
    return Number.isInteger(concurrency) && concurrency >= 1 ? concurrency : 1;
  }

  function normalizePeak(peak) {
    if (!peak) return null;
    const centerPercent = Number(peak.centerPercent);
    const strength = Number(peak.strength);
    const widthPercent = Number(peak.widthPercent ?? DEFAULT_PEAK_WIDTH_PERCENT);
    if (Number.isFinite(centerPercent) && Number.isFinite(strength) && Number.isFinite(widthPercent)) {
      return { centerPercent, strength, widthPercent };
    }
    // Preserve older interval-based settings while they are edited.
    const startPercent = Number(peak.startPercent);
    const endPercent = Number(peak.endPercent);
    const share = Number(peak.share);
    if (!Number.isFinite(startPercent) || !Number.isFinite(endPercent) || !Number.isFinite(share)) {
      return null;
    }
    return {
      centerPercent: (startPercent + endPercent) / 2,
      strength: Math.min(MAX_PEAK_STRENGTH, Math.max(0.5, share / Math.max(1, endPercent - startPercent))),
      widthPercent: Math.max(3, Math.min(30, (endPercent - startPercent) / 3))
    };
  }

  function getPeaks(segment) {
    if (Array.isArray(segment?.peaks)) {
      return segment.peaks.slice(0, MAX_PEAKS).map(normalizePeak).filter(Boolean);
    }
    if (!segment?.peak?.enabled) return [];
    const peak = normalizePeak(segment.peak);
    return peak ? [peak] : [];
  }

  function getPeak(segment) {
    return getPeaks(segment)[0] || null;
  }

  function erf(value) {
    const sign = value < 0 ? -1 : 1;
    const x = Math.abs(value);
    const t = 1 / (1 + 0.3275911 * x);
    const polynomial = (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t
      - 0.284496736) * t + 0.254829592) * t;
    return sign * (1 - polynomial * Math.exp(-x * x));
  }

  function normalCdf(value) {
    return 0.5 * (1 + erf(value / Math.SQRT2));
  }

  function curveDensityAt(peaks, position) {
    return peaks.reduce((area, peak) => {
      const center = peak.centerPercent / 100;
      const width = peak.widthPercent / 100;
      const gaussian = width * Math.sqrt(2 * Math.PI) * (
        normalCdf((position - center) / width) - normalCdf(-center / width)
      );
      return area + peak.strength * gaussian;
    }, position);
  }

  function curvePositionForFraction(peaks, fraction) {
    const totalDensity = curveDensityAt(peaks, 1);
    let lower = 0;
    let upper = 1;
    for (let index = 0; index < 32; index += 1) {
      const middle = (lower + upper) / 2;
      if (curveDensityAt(peaks, middle) / totalDensity < fraction) lower = middle;
      else upper = middle;
    }
    return (lower + upper) / 2;
  }

  function timeAtDistributionPosition(segment, position) {
    const startAt = Number(segment.startAt);
    const endAt = Number(segment.endAt);
    const duration = endAt - startAt;
    const peaks = getPeaks(segment);
    if (peaks.length === 0) return startAt + duration * position;

    return startAt + duration * curvePositionForFraction(peaks, position);
  }

  function plannedTime(segment, requestIndex) {
    const startAt = Number(segment.startAt);
    const endAt = Number(segment.endAt);
    const total = Number(segment.totalRequests);
    if (!Number.isFinite(startAt) || !Number.isFinite(endAt) || total < 1) {
      return null;
    }

    const duration = endAt - startAt;
    if (duration <= 0 || requestIndex < 0 || requestIndex >= total) {
      return null;
    }

    const concurrency = getConcurrency(segment);
    const totalBatches = Math.ceil(total / concurrency);
    const batchIndex = Math.floor(requestIndex / concurrency);
    const seed = hashString(`${segmentRevision(segment)}:${batchIndex}`);
    const positionInBucket = 0.25 + pseudoRandom(seed) * 0.5;
    const distributionPosition = (batchIndex + positionInBucket) / totalBatches;
    return Math.floor(timeAtDistributionPosition(segment, distributionPosition));
  }

  function nextBatchSize(segment, sentCount) {
    const remaining = Math.max(0, Number(segment.totalRequests) - Number(sentCount));
    return Math.min(getConcurrency(segment), remaining);
  }

  function nextRunAt(segment, sentCount, now = Date.now()) {
    if (sentCount >= segment.totalRequests || now >= segment.endAt) {
      return null;
    }

    const target = plannedTime(segment, sentCount);
    if (target === null) {
      return null;
    }

    if (target > now) {
      return target;
    }

    const remaining = segment.totalRequests - sentCount;
    const remainingTime = segment.endAt - now;
    const remainingBatches = Math.ceil(remaining / getConcurrency(segment));
    if (remainingBatches <= 1) {
      return Math.min(now + MIN_REQUEST_GAP_MS, segment.endAt - 1);
    }

    // A delayed service worker catches up gradually while preserving room for later calls.
    const recoveryGap = Math.max(
      MIN_REQUEST_GAP_MS,
      Math.min(5000, Math.floor(remainingTime / remainingBatches / 3))
    );
    return Math.min(now + recoveryGap, segment.endAt - 1);
  }

  function validateSegment(segment) {
    const errors = [];
    if (!segment || typeof segment !== "object") {
      return ["时间段格式无效"];
    }
    if (!Number.isFinite(Number(segment.startAt))) errors.push("开始时间无效");
    if (!Number.isFinite(Number(segment.endAt))) errors.push("结束时间无效");
    if (Number(segment.endAt) <= Number(segment.startAt)) errors.push("结束时间必须晚于开始时间");
    if (!Number.isInteger(Number(segment.totalRequests)) || Number(segment.totalRequests) < 1) {
      errors.push("请求次数必须是正整数");
    }
    const concurrency = Number(segment.concurrency ?? 1);
    if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > MAX_CONCURRENCY) {
      errors.push(`并发数必须是 1 至 ${MAX_CONCURRENCY} 的整数`);
    }
    const peaks = getPeaks(segment);
    if (Array.isArray(segment.peaks) && segment.peaks.length > MAX_PEAKS) {
      errors.push(`最多配置 ${MAX_PEAKS} 个波峰`);
    }
    for (const peak of peaks) {
        if (peak.centerPercent < 0 || peak.centerPercent > 100) errors.push("波峰位置必须位于时间段内");
        if (peak.strength < 0 || peak.strength > MAX_PEAK_STRENGTH) {
          errors.push(`波峰高度必须是 0 至 ${MAX_PEAK_STRENGTH}`);
        }
        if (peak.widthPercent < 3 || peak.widthPercent > 30) errors.push("波峰宽度必须是 3% 至 30%");
    }
    return errors;
  }

  function chooseMessage(messages, lastIndex = -1, randomValue = Math.random()) {
    if (!Array.isArray(messages) || messages.length === 0) return null;
    if (messages.length === 1) return { message: messages[0], index: 0 };
    const safeRandom = Math.max(0, Math.min(0.999999999, Number(randomValue) || 0));
    let index = Math.floor(safeRandom * (messages.length - 1));
    if (index >= lastIndex) index += 1;
    return { message: messages[index], index };
  }

  function poolSignature(items) {
    return JSON.stringify(items);
  }

  function drawFromBag(items, bagState, random = Math.random) {
    if (!Array.isArray(items) || items.length === 0) return null;
    const signature = poolSignature(items);
    let remaining = bagState?.signature === signature && Array.isArray(bagState.remaining)
      ? bagState.remaining.filter((index) => Number.isInteger(index) && index >= 0 && index < items.length)
      : [];
    const lastIndex = bagState?.signature === signature ? bagState.lastIndex : -1;

    if (remaining.length === 0) {
      remaining = items.map((_item, index) => index);
      for (let index = remaining.length - 1; index > 0; index -= 1) {
        const randomValue = Math.max(0, Math.min(0.999999999, Number(random()) || 0));
        const swapIndex = Math.floor(randomValue * (index + 1));
        [remaining[index], remaining[swapIndex]] = [remaining[swapIndex], remaining[index]];
      }
      if (remaining.length > 1 && remaining[0] === lastIndex) {
        [remaining[0], remaining[1]] = [remaining[1], remaining[0]];
      }
    }

    const index = remaining.shift();
    return {
      value: items[index],
      index,
      bagState: { signature, remaining, lastIndex: index }
    };
  }

  return {
    MIN_REQUEST_GAP_MS,
    MAX_CONCURRENCY,
    DEFAULT_PEAK_WIDTH_PERCENT,
    MAX_PEAK_STRENGTH,
    MAX_PEAKS,
    getConcurrency,
    getPeak,
    getPeaks,
    nextBatchSize,
    nextRunAt,
    plannedTime,
    segmentRevision,
    chooseMessage,
    drawFromBag,
    validateSegment
  };
});

"use strict";

const BRIDGE_SOURCE = "polyv-request-scheduler";
const pendingCommands = new Map();

window.addEventListener("message", (event) => {
  const message = event.data;
  if (event.source !== window || message?.source !== BRIDGE_SOURCE) return;
  if (message.type === "socketObserved") {
    void chrome.runtime.sendMessage({ type: "socketObserved", value: message.payload });
    return;
  }
  if (message.type === "sendChatResult" && pendingCommands.has(message.requestId)) {
    const sendResponse = pendingCommands.get(message.requestId);
    pendingCommands.delete(message.requestId);
    sendResponse(message.payload);
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "ai.ping" && _sender.id === chrome.runtime.id) {
    sendResponse({ ok: true, url: window.location.href });
    return false;
  }
  if (message?.type === "ai.guard") { window.postMessage({source: BRIDGE_SOURCE,type:"aiGuard",payload:message.value}, "*"); sendResponse({ok:true}); return false; }
  if (message?.type !== "sendChat") return false;
  const requestId = crypto.randomUUID();
  const timeoutId = setTimeout(() => {
    if (!pendingCommands.has(requestId)) return;
    pendingCommands.delete(requestId);
    sendResponse({ ok: false, error: "页面套接字执行超时" });
  }, 25000);
  pendingCommands.set(requestId, (response) => {
    clearTimeout(timeoutId);
    sendResponse(response);
  });
  window.postMessage({
    source: BRIDGE_SOURCE,
    type: "sendChat",
    requestId,
    payload: message.value
  }, "*");
  return true;
});

/* Portable task workbooks: company node names, no source records or credentials. */
(function (root) {
    'use strict';
    const C = root.RecruitCore || (typeof require === 'function' ? require('./core.js') : null);
    const headers = ['节点', '昵称', '身份信息', '时间节点', '弹幕'];
    const metadataName = '执行信息';
    const metadataHeaders = ['主表行号', '节点', '昵称', '时间节点', '消息编号', '类型', '回复编号', '表情编号'];
    const day = 86400000, maxMessages = 200000;
    function fail(message) { throw Error('任务 Excel 无效：' + message); }
    function text(value, max, label, optional = false) {
        if (value === undefined || value === null) value = '';
        if (typeof value !== 'string' || value.length > max || (!optional && !value.trim())) fail(label + '格式不正确');
        return C.redact(value, max);
    }
    function clock(ms) {
        const whole = Math.floor(ms / 1000);
        return [Math.floor(whole / 3600), Math.floor(whole / 60) % 60, whole % 60].map(n => String(n).padStart(2, '0')).join(':') + '.' + String(ms % 1000).padStart(3, '0');
    }
    function parseTime(value) {
        if (typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1) return Math.round(value * day);
        const m = String(value ?? '').trim().match(/^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?$/);
        if (!m || +m[2] > 59 || +m[3] > 59) fail('时间应为从本场开始计算的 HH:MM:SS.毫秒');
        const ms = ((+(m[1] || 0) * 60 + +m[2]) * 60 + +m[3]) * 1000 + +(m[4] || '').padEnd(3, '0');
        if (ms > day) fail('时间不能超过24小时');
        return ms;
    }
    function identity(person) {
        if (typeof person.identityText === 'string') return person.identityText;
        return [['年龄', person.age ? person.age + '岁' : ''], ['学历', person.education], ['身份', person.experience], ['语气', person.tone],
            ['兴趣', (person.interests || []).join('、')], ['参与', person.participation], ['表情', person.emojiPreference], ['解答', person.canAnswer ? '是' : '否']]
            .filter(([, v]) => v).map(([k, v]) => k + '：' + String(v).replace(/[\r\n]/g, ' ')).join('\n');
    }
    function persona(nickname, description, id) {
        const fields = Object.create(null);
        for (const line of description.split('\n')) { const m = line.match(/^([^：:]+)[：:](.*)$/); if (m) fields[m[1].trim()] = m[2].trim(); }
        return { id, nickname, identityText: description, age: C.number(parseInt(fields.年龄, 10), 18, 70, 22), education: fields.学历 || '',
            experience: fields.身份 || description, tone: fields.语气 || '', interests: (fields.兴趣 || '').split('、').filter(Boolean),
            participation: ['全程', '间歇', '短停'].includes(fields.参与) ? fields.参与 : '间歇', emojiPreference: fields.表情 || '', canAnswer: fields.解答 === '是' };
    }
    function sheet(X, rows, widths) {
        const s = X.utils.aoa_to_sheet(rows);
        s['!cols'] = widths.map(wch => ({ wch }));
        s['!autofilter'] = { ref: X.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: rows.length - 1, c: rows[0].length - 1 } }) };
        return s;
    }
    function toWorkbook(project, X) {
        if (project.status !== 'ready' || !project.nodes?.length || project.nodes.length > 1000) fail('请先完成全部节点内容');
        if (!project.companies?.length) {
            project = { ...project, nodes: project.nodes.map(n => ({ ...n })), batches: { ...project.batches } };
            C.repairTaskNodes(project);
        }
        const profiles = C.roomPersonas(project.personas || [], project.id);
        if (!profiles.length || profiles.length > 500) fail('人设数量应为1到500');
        const byId = new Map(profiles.map(p => [p.id, p]));
        const rows = [headers], ranges = [['节点', '时间节点']], metadata = [metadataHeaders], groups = [], names = new Set();
        let start = 0, messageNumber = 0;
        for (const [i, node] of project.nodes.entries()) {
            const company = project.companies?.find(c => c.id === node.id);
            const label = text(C.companyName(company?.name || node.name), 180, '企业节点名称'), duration = Math.round(node.duration * 1000);
            if (names.has(label)) fail('企业节点名称重复：' + label); names.add(label);
            if (!Number.isFinite(duration) || duration < 1000 || start + duration > day) fail('节点时长无效或总时长超过24小时');
            ranges.push([label, clock(start) + ' - ' + clock(start + duration)]);
            const events = C.safeEvents((project.batches?.[node.id] || []).filter(m => !['enter', 'leave'].includes(m.kind) && m.epoch === undefined && m.runId === undefined), company).sort((a, b) => a.at - b.at);
            if (!events.length) fail('节点 ' + (i + 1) + ' 尚无可用弹幕（公司简介、过长内容及其关联回复不导出）');
            const ids = new Map(events.map(e => [e.id, 'm' + (++messageNumber)]));
            const first = rows.length;
            for (const event of events) {
                const p = byId.get(event.personaId);
                if (!p) fail('弹幕缺少对应昵称');
                if (!Number.isFinite(event.at) || event.at < 0 || event.at > duration) fail('弹幕时间超出节点范围');
                const m = C.roomEvent(event, company);
                rows.push([label, p.nickname, identity(p), (start + Math.round(m.at)) / day, text(m.text, 6000, '弹幕')]);
                // Execution metadata stays on a hidden sheet, never in cell comments.
                metadata.push([rows.length, label, p.nickname, (start + Math.round(m.at)) / day, ids.get(m.id), m.kind, ids.get(m.replyTo) || '', m.stickerId ?? '']);
                if (rows.length > maxMessages + 1) fail('弹幕超过20万条');
            }
            groups.push({ first, last: rows.length - 1 });
            start += duration;
        }
        const wb = X.utils.book_new(), messages = sheet(X, rows, [40, 20, 42, 22, 60]);
        rows.slice(1).forEach((_, i) => {
            messages['D' + (i + 2)].z = '[h]:mm:ss.000';
        });
        const merge = (first, last, c) => {
            if (first === last) return;
            (messages['!merges'] ||= []).push({ s: { r: first, c }, e: { r: last, c } });
            for (let r = first + 1; r <= last; r++) delete messages[X.utils.encode_cell({ r, c })];
        };
        for (const { first, last } of groups) {
            merge(first, last, 0);
            // Only merge identity fields for consecutive messages from the same person.
            let at = first;
            while (at <= last) {
                let end = at;
                while (end < last && rows[end + 1][1] === rows[at][1] && rows[end + 1][2] === rows[at][2]) end++;
                merge(at, end, 1); if (rows[at][2]) merge(at, end, 2); at = end + 1;
            }
        }
        // Excel filtering a vertically merged group would hide rows independently of its label.
        delete messages['!autofilter'];
        X.utils.book_append_sheet(wb, messages, '弹幕任务');
        X.utils.book_append_sheet(wb, sheet(X, ranges, [40, 40]), '节点时段');
        X.utils.book_append_sheet(wb, sheet(X, [['昵称', '身份信息'], ...profiles.map(p => [p.nickname, identity(p)])], [20, 55]), '用户人设');
        X.utils.book_append_sheet(wb, sheet(X, metadata, [12, 40, 20, 22, 20, 12, 20, 12]), metadataName);
        wb.Workbook = { Sheets: wb.SheetNames.map(name => ({ name, Hidden: name === metadataName ? 1 : 0 })) };
        return wb;
    }
    function readRows(wb, name, expected, max, X, mergeFields = []) {
        const s = wb.Sheets[name]; if (!s?.['!ref']) fail('缺少“' + name + '”工作表');
        const range = X.utils.decode_range(s['!ref']);
        if (range.e.r > max || range.e.c >= expected.length) fail(name + '行数或列数超过上限');
        const rawHeaders = Array.from({ length: expected.length }, (_, c) => String(s[X.utils.encode_cell({ r: 0, c })]?.v || '').trim());
        if (new Set(rawHeaders).size !== expected.length || expected.some(h => !rawHeaders.includes(h))) fail(name + '表头应为：' + expected.join('、'));
        const columns = expected.map(h => rawHeaders.indexOf(h)), rows = [], merged = new Map();
        const mergeColumns = new Set(mergeFields.map(h => rawHeaders.indexOf(h)));
        for (const m of s['!merges'] || []) {
            if (!m?.s || !m.e || ![m.s.r, m.s.c, m.e.r, m.e.c].every(Number.isInteger)
                || m.s.c !== m.e.c || !mergeColumns.has(m.s.c) || m.s.r < 1 || m.e.r < m.s.r || m.e.r > range.e.r)
                fail(name + '仅支持节点、昵称和身份信息列内合并，不能跨列或合并表头、时间和弹幕');
            const list = merged.get(m.s.c) || []; list.push(m); merged.set(m.s.c, list);
        }
        for (const list of merged.values()) {
            list.sort((a, b) => a.s.r - b.s.r);
            for (let i = 1; i < list.length; i++) if (list[i].s.r <= list[i - 1].e.r) fail(name + '合并区域重叠');
        }
        const pointers = new Map();
        for (let r = 1; r <= range.e.r; r++) {
            const cells = columns.map(c => s[X.utils.encode_cell({ r, c })]);
            if (cells.every(c => c?.v === undefined || c.v === '')) continue;
            if (cells.some(c => c?.f || c?.t === 'e')) fail(name + '第' + (r + 1) + '行包含公式或错误单元格，请改为值');
            columns.forEach((c, index) => {
                const list = merged.get(c); if (!list) return;
                let at = pointers.get(c) || 0; while (at < list.length && list[at].e.r < r) at++; pointers.set(c, at);
                const m = list[at]; if (!m || m.s.r > r) return;
                const anchor = s[X.utils.encode_cell(m.s)];
                if (!anchor || anchor.f || anchor.t === 'e') fail(name + '合并区域缺少有效内容');
                if (cells[index]?.v !== undefined && cells[index].v !== '' && cells[index].v !== anchor.v) fail(name + '合并区域包含不一致的内容');
                cells[index] = anchor;
            });
            rows.push({ values: cells.map(c => c?.v ?? ''), cells, row: r + 1 });
        }
        return rows;
    }
    function fromWorkbook(wb, filename, id, now, X) {
        const rows = readRows(wb, '弹幕任务', headers, maxMessages, X, ['节点', '昵称', '身份信息']);
        if (!rows.length) fail('没有弹幕');
        const nodes = [], nodeMap = new Map(), people = [], peopleMap = new Map(), batches = Object.create(null), warnings = [];
        function addPerson(nick, info) {
            nick = text(nick, 80, '昵称'); info = text(info, 6000, '身份信息', true);
            if (C.nicknameText(nick) !== nick || /自动招聘助手/.test(nick)) fail('昵称请使用纯文字，不能带表情或旧统一身份名称');
            const key = C.norm(nick), known = peopleMap.get(key);
            if (known) {
                if (info && known.identityText && info !== known.identityText) fail('昵称“' + nick + '”的身份信息不一致');
                if (info && !known.identityText) Object.assign(known, persona(nick, info, known.id));
                return known;
            }
            if (people.length >= 500) fail('人设超过500个');
            const p = persona(nick, info, 'p' + (people.length + 1)); people.push(p); peopleMap.set(key, p); return p;
        }
        if (wb.Sheets['用户人设']) for (const r of readRows(wb, '用户人设', ['昵称', '身份信息'], 500, X)) {
            if (peopleMap.has(C.norm(r.values[0]))) fail('用户人设表昵称重复'); addPerson(...r.values);
        }
        let end = 0;
        if (wb.Sheets['节点时段']) for (const r of readRows(wb, '节点时段', ['节点', '时间节点'], 1000, X)) {
            const name = text(r.values[0], 180, '节点'), parts = String(r.values[1]).split(/\s+-\s+/);
            if (parts.length !== 2) fail('节点时段应为 HH:MM:SS.毫秒 - HH:MM:SS.毫秒');
            const start = parseTime(parts[0]), stop = parseTime(parts[1]);
            if (start !== end || stop - start < 1000 || nodeMap.has(name)) fail('节点时段必须从零连续排列，不能重叠、重复或小于1秒');
            const n = { id: 'n' + (nodes.length + 1), name, start: start / 1000, duration: (stop - start) / 1000 };
            nodes.push(n); nodeMap.set(name, n); batches[n.id] = []; end = stop;
        }
        const prepared = rows.map(r => {
            const [label, nick, info, time, content] = r.values;
            return { ...r, label: text(label, 180, '节点'), person: addPerson(nick, info), time: parseTime(time), content: text(content, 6000, '弹幕') };
        });
        const metaKey = (label, nick, time) => JSON.stringify([label, nick, time]);
        const preparedKeys = new Set(prepared.map(r => metaKey(r.label, r.person.nickname, r.time)));
        const metadataByRow = new Map(), metadataByKey = new Map(), usedMetadata = new Set();
        if (wb.Sheets[metadataName]) for (const r of readRows(wb, metadataName, metadataHeaders, maxMessages, X)) {
            const [row, label, nick, time, id, kind, replyTo, stickerId] = r.values;
            if (!Number.isInteger(row) || row < 2 || row > maxMessages + 1 || metadataByRow.has(row)) fail('执行信息的主表行号无效或重复');
            if (!['chat', 'reply', 'question', 'answer', 'emoji', 'sticker'].includes(kind)) fail('执行信息的消息类型无效');
            const meta = { id: text(id, 180, '消息编号'), kind, replyTo: text(replyTo, 180, '回复编号', true),
                ...(stickerId !== '' ? { stickerId: String(stickerId) } : {}), key: metaKey(text(label, 180, '节点'), text(nick, 80, '昵称'), parseTime(time)) };
            if (kind === 'sticker' && !C.stickers.some(s => s.id === meta.stickerId)) fail('执行信息的图片表情编号不可用');
            metadataByRow.set(row, meta);
            const matches = metadataByKey.get(meta.key) || []; matches.push(meta); metadataByKey.set(meta.key, matches);
        }
        function takeMetadata(r) {
            const key = metaKey(r.label, r.person.nickname, r.time), atRow = metadataByRow.get(r.row);
            if (atRow?.key === key && !usedMetadata.has(atRow)) { usedMetadata.add(atRow); return atRow; }
            // A reordered/inserted row can still locate its own metadata by node, nickname and time.
            const matches = (metadataByKey.get(key) || []).filter(m => !usedMetadata.has(m));
            if (matches.length > 1) fail('第' + r.row + '行存在相同节点、昵称和时间，无法匹配执行信息');
            if (matches.length) { usedMetadata.add(matches[0]); return matches[0]; }
            // Keep references when only the timestamp was edited in place.
            if (atRow && !usedMetadata.has(atRow) && !preparedKeys.has(atRow.key)) {
                const [label, nick] = JSON.parse(atRow.key);
                if (label === r.label && nick === r.person.nickname) { usedMetadata.add(atRow); return atRow; }
            }
            return null;
        }
        if (!nodes.length) {
            // Plain five-column workbooks are accepted; exported workbooks carry exact ranges.
            const bounds = new Map(); let latest = 0;
            for (const r of prepared) { bounds.set(r.label, Math.min(bounds.get(r.label) ?? Infinity, r.time)); latest = Math.max(latest, r.time); }
            const labels = [...bounds.keys()];
            if (labels.length > 1000) fail('节点超过1000个');
            for (const [i, name] of labels.entries()) {
                const start = i ? bounds.get(name) : 0;
                const stop = i + 1 < labels.length ? bounds.get(labels[i + 1]) : latest + 1000;
                if (stop - start < 1000 || stop > day) fail('无法推算节点时段，请补充节点时段工作表');
                const n = { id: 'n' + (i + 1), name, start: start / 1000, duration: (stop - start) / 1000 }; nodes.push(n); nodeMap.set(name, n); batches[n.id] = []; end = stop;
            }
            warnings.push('此文件未提供节点时段，已按各节点首条弹幕推算边界，最后一条弹幕后1秒结束。');
        }
        const ids = new Set();
        for (const r of prepared) {
            const node = nodeMap.get(r.label);
            if (!node || r.time < node.start * 1000 || r.time > (node.start + node.duration) * 1000) fail('第' + r.row + '行时间不在对应节点时段内');
            let meta = takeMetadata(r);
            const note = r.cells[4]?.c?.find(c => c.a === 'HCZB' && c.t?.startsWith('HCZB消息：'));
            // Read old comment-based workbooks, but never create comments in new exports.
            if (!meta && note) { try { meta = JSON.parse(note.t.slice('HCZB消息：'.length)); } catch { fail('第' + r.row + '行消息标注损坏'); } }
            meta ||= {};
            if (!meta || typeof meta !== 'object') fail('消息标注格式错误');
            const messageId = text(meta.id || 'row-' + r.row, 180, '消息编号');
            if (ids.has(messageId)) fail('消息编号重复，请检查复制行或执行信息中的编号'); ids.add(messageId);
            const explicitSticker = r.content.match(/^\[图片表情:(\d+)\]$/);
            const sticker = C.stickers.find(s => meta.kind === 'sticker' && s.id === String(meta.stickerId) && r.content === '[' + s.name + ']'
                || explicitSticker && s.id === explicitSticker[1]
                || !meta.id && !note && !C.faceEmotions.includes(s.name) && r.content === '[' + s.name + ']');
            if (explicitSticker && !sticker) fail('第' + r.row + '行图片表情编号不可用');
            const kind = sticker ? 'sticker' : ['chat', 'reply', 'question', 'answer', 'emoji'].includes(meta.kind) ? meta.kind : C.isQuestion(r.content) ? 'question' : 'chat';
            batches[node.id].push({ id: messageId, personaId: r.person.id, kind, text: sticker ? '[' + sticker.name + ']' : C.platformText(r.content), at: r.time - Math.round(node.start * 1000),
                replyTo: meta.replyTo ? text(meta.replyTo, 180, '回复编号') : null, ...(sticker ? { stickerId: sticker.id } : {}) });
        }
        for (const n of nodes) {
            const batch = batches[n.id]; if (!batch.length) fail(n.name + '没有弹幕'); batch.sort((a, b) => a.at - b.at);
            const byId = new Map(batch.map(m => [m.id, m]));
            for (const m of batch) if (m.replyTo) {
                const q = byId.get(m.replyTo); if (!q || q.at >= m.at || q.personaId === m.personaId) fail('回复关系不完整或时间顺序不正确，请同步调整回复弹幕');
            }
            const blocked = batch.length - C.safeEvents(batch).length;
            if (blocked) warnings.push(n.name + '有' + blocked + '条公司简介、过长内容或关联回复，执行时自动跳过。');
        }
        const project = { id, name: C.clean(filename, 250), createdAt: now, updatedAt: now, importedAt: now, taskOnly: true, companies: [], nodes, personas: people, batches,
            config: { minutes: end / 60000, personaCount: people.length, mode: 'full', generationVersion: 2, audienceVersion: 1 }, theme: { kind: '弹幕任务', summary: '', audience: [] },
            status: 'ready', progress: '已导入 · 按表格昵称、节点与时间执行', warnings };
        const repaired = C.repairTaskNodes(project);
        if (repaired.renamed || repaired.merged) warnings.push('已清理企业节点名称，合并' + repaired.merged + '个重复简介/串场节点；整场时长与弹幕绝对时间保持不变。');
        return project;
    }
    function read(buffer, filename, id, now, X) {
        let wb; try { wb = X.read(buffer, { type: 'array', cellHTML: false, cellDates: false, bookVBA: false }); } catch { fail('无法读取 XLSX 文件'); }
        return fromWorkbook(wb, filename, id, now, X);
    }
    const api = { headers, identity, clock, parseTime, toWorkbook, fromWorkbook, read };
    root.RecruitTaskWorkbook = api;
    if (typeof module !== 'undefined') module.exports = api;
})(globalThis);
